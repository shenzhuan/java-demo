package com.ruoyi.flowable.domain.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author 魔金
 * @date 2021/4/21 20:55
 */
@Data
public class FlowViewerDto implements Serializable {

    private String key;
    private boolean completed;
}
