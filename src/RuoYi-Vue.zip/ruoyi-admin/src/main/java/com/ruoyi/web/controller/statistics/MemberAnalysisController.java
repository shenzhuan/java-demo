/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:MemberAnalysisController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.statistics;


import com.ruoyi.order.vo.CustomerConsumption;
import com.ruoyi.order.vo.CustomerOrderAmount;
import com.ruoyi.statistics.service.StatisticsServiceApi;
import com.ruoyi.util.BaseResponse;
import com.ruoyi.util.PageHelper;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author 魔金 2123957932
 * @date 2019-06-24 19:16
 * <p>
 * 会员分析统计控制器
 */
@RestController
@Api(description = "会员分析统计接口")
public class MemberAnalysisController {

    /**
     * 注入统计服务
     */
    @Autowired
    private StatisticsServiceApi statisticsServiceApi;


    /**
     * 分页查询用户下单量
     *
     * @param pageHelper 分页帮助类
     * @param startTime  开始时间
     * @param endTime    结束时间
     * @return 返回用户下单量
     */
    @GetMapping("/memberanalysis/orderamount")
    @ApiOperation(value = "分页查询用户下单量", notes = "分页查询用户下单量（需要认证）")
    @PreAuthorize("hasAuthority('memberanalysis/querycustomerorderamount')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回用户下单量", response = CustomerOrderAmount.class)
    })
    public BaseResponse queryCustomerOrderAmount(@ApiIgnore PageHelper<CustomerOrderAmount> pageHelper, String startTime, String endTime) {
        return BaseResponse.build(statisticsServiceApi.queryCustomerOrderAmounts(pageHelper, startTime, endTime));
    }


    /**
     * 分页查询用户消费额
     *
     * @param pageHelper 分页帮助类
     * @param startTime  开始时间
     * @param endTime    结束时间
     * @return 返回用户消费额
     */
    @GetMapping("/memberanalysis/consumption")
    @PreAuthorize("hasAuthority('memberanalysis/querycustomerconsumption')")
    @ApiOperation(value = "分页查询用户消费额", notes = "分页查询用户消费额（需要认证）")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回用户消费额", response = CustomerConsumption.class)
    })
    public BaseResponse queryCustomerConsumption(@ApiIgnore PageHelper<CustomerConsumption> pageHelper, String startTime, String endTime) {
        return BaseResponse.build(statisticsServiceApi.queryCustomerConsumption(pageHelper, startTime, endTime));
    }


}
