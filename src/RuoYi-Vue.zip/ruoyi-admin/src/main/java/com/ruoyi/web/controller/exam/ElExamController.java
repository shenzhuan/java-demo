package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElExam;
import com.ruoyi.exam.service.IElExamService;
import com.ruoyi.exam.vo.BaseStateReqDTO;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * 课程Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElExam")
public class ElExamController extends BaseController {
    @Autowired
    private IElExamService elExamService;

    /**
     * 查询课程列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExam:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElExam elExam) {
        startPage();
        List<ElExam> list = elExamService.selectElExamList(elExam);
        return getDataTable(list);
    }

    /**
     * 查询考试视角列表
     */
    @GetMapping("/online")
    public TableDataInfo online(ElExam elExam) {
        startPage();
        List<ElExam> list = elExamService.online(elExam);
        return getDataTable(list);
    }

    /**
     * 查询待阅试卷
     */
    @GetMapping("/reviewPaging")
    public TableDataInfo reviewPaging(ElExam elExam) {
        startPage();
        List<ElExam> list = elExamService.reviewPaging(elExam);
        return getDataTable(list);
    }

    /**
     * 查找详情
     *
     * @param reqDTO
     * @return
     */
    @ApiOperation(value = "查找详情")
    @RequestMapping(value = "/state", method = {RequestMethod.POST})
    public AjaxResult state(@RequestBody BaseStateReqDTO reqDTO) {
        if (reqDTO.getIds() != null && reqDTO.getIds().size() > 0) {
            for (Long id : reqDTO.getIds()) {
                ElExam elExam = new ElExam();
                elExam.setId(id);
                elExam.setState(reqDTO.getState());
                elExam.setUpdateTime(new Date());
                elExamService.updateElExam(elExam);
            }
        }
        return AjaxResult.success();
    }

    /**
     * 导出课程列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExam:export')")
    @Log(title = "课程", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElExam elExam) {
        List<ElExam> list = elExamService.selectElExamList(elExam);
        ExcelUtil<ElExam> util = new ExcelUtil<ElExam>(ElExam.class);
        return util.exportExcel(list, "ElExam");
    }

    /**
     * 获取课程详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExam:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elExamService.findDetail(id));
    }

    /**
     * 新增课程
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExam:add')")
    @Log(title = "课程", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElExam elExam) {
        return toAjax(elExamService.save(elExam));
    }

    /**
     * 修改课程
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExam:edit')")
    @Log(title = "课程", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElExam elExam) {
        return toAjax(elExamService.save(elExam));
    }

    /**
     * 删除课程
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExam:remove')")
    @Log(title = "课程", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elExamService.deleteElExamByIds(ids));
    }
}
