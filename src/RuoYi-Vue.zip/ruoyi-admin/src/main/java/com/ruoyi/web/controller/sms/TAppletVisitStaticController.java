/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:TAppletVisitStaticController.java
 * Date:2021/01/09 11:40:09
 */

package com.ruoyi.web.controller.sms;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.sms.domain.TAppletVisitStatic;
import com.ruoyi.sms.service.ITAppletVisitStaticService;
import com.ruoyi.util.CommonConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 【请填写功能名称】Controller
 *
 * @author é­éåå
 * @date 2021-01-08
 */
@RestController
@RequestMapping("/sms/TAppletVisitStatic")
public class TAppletVisitStaticController extends BaseController {
    @Autowired
    private ITAppletVisitStaticService tAppletVisitStaticService;

    /**
     * 查询【请填写功能名称】列表
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisitStatic:list')")
    @GetMapping("/list")
    public TableDataInfo list(TAppletVisitStatic tAppletVisitStatic) {
        startPage();
        tAppletVisitStatic.setStoreId(CommonConstant.ADMIN_STOREID);
        List<TAppletVisitStatic> list = tAppletVisitStaticService.selectTAppletVisitStaticList(tAppletVisitStatic);
        return getDataTable(list);
    }

    /**
     * 导出【请填写功能名称】列表
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisitStatic:export')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(TAppletVisitStatic tAppletVisitStatic) {
        List<TAppletVisitStatic> list = tAppletVisitStaticService.selectTAppletVisitStaticList(tAppletVisitStatic);
        ExcelUtil<TAppletVisitStatic> util = new ExcelUtil<TAppletVisitStatic>(TAppletVisitStatic.class);
        return util.exportExcel(list, "TAppletVisitStatic");
    }

    /**
     * 获取【请填写功能名称】详细信息
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisitStatic:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(tAppletVisitStaticService.selectTAppletVisitStaticById(id));
    }

    /**
     * 新增【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisitStatic:add')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TAppletVisitStatic tAppletVisitStatic) {
        return toAjax(tAppletVisitStaticService.insertTAppletVisitStatic(tAppletVisitStatic));
    }

    /**
     * 修改【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisitStatic:edit')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TAppletVisitStatic tAppletVisitStatic) {
        return toAjax(tAppletVisitStaticService.updateTAppletVisitStatic(tAppletVisitStatic));
    }

    /**
     * 删除【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisitStatic:remove')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(tAppletVisitStaticService.deleteTAppletVisitStaticByIds(ids));
    }
}
