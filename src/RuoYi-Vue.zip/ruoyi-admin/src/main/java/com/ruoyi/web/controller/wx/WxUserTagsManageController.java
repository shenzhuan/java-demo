package com.ruoyi.web.controller.wx;


import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.wx.form.WxUserBatchTaggingForm;
import com.ruoyi.wx.form.WxUserTagForm;
import com.ruoyi.wx.service.IWxUserService;
import com.ruoyi.wx.service.IWxUserTagsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import me.chanjar.weixin.common.error.WxErrorException;
import me.chanjar.weixin.mp.bean.tag.WxUserTag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 公众号用户标签
 */
@RestController
@RequestMapping("/manage/wxUserTags")
@Api(tags = {"公众号用户标签-管理后台"})
public class WxUserTagsManageController {
    @Autowired
    private IWxUserService wxUserService;
    @Autowired
    private IWxUserTagsService wxUserTagsService;

    /**
     * 查询用户标签
     */
    @GetMapping("/list")
    @ApiOperation(value = "列表")
    public AjaxResult list(@CookieValue String appid) throws WxErrorException {
        List<WxUserTag> wxUserTags = wxUserTagsService.getWxTags(appid);
        return AjaxResult.success(wxUserTags);
    }

    /**
     * 修改或新增标签
     */
    @PostMapping("/save")
    @ApiOperation(value = "保存")
    public AjaxResult save(@CookieValue String appid, @RequestBody WxUserTagForm form) throws WxErrorException {
        Long tagid = form.getId();
        if (tagid == null || tagid <= 0) {
            wxUserTagsService.creatTag(appid, form.getName());
        } else {
            wxUserTagsService.updateTag(appid, tagid, form.getName());
        }
        return AjaxResult.success();
    }

    /**
     * 删除标签
     */
    @PostMapping("/delete/{tagid}")
    @ApiOperation(value = "删除标签")
    public AjaxResult delete(@CookieValue String appid, @PathVariable("tagid") Long tagid) throws WxErrorException {
        if (tagid == null || tagid <= 0) {
            return AjaxResult.error("标签ID不得为空");
        }
        wxUserTagsService.deleteTag(appid, tagid);
        return AjaxResult.success();
    }

    /**
     * 批量给用户打标签
     */
    @PostMapping("/batchTagging")
    @ApiOperation(value = "批量给用户打标签")
    public AjaxResult batchTagging(@CookieValue String appid, @RequestBody WxUserBatchTaggingForm form) throws WxErrorException {

        wxUserTagsService.batchTagging(appid, form.getTagid(), form.getOpenidList());
        return AjaxResult.success();
    }

    /**
     * 批量移除用户标签
     */
    @PostMapping("/batchUnTagging")
    @ApiOperation(value = "批量移除用户标签")
    public AjaxResult batchUnTagging(@CookieValue String appid, @RequestBody WxUserBatchTaggingForm form) throws WxErrorException {
        wxUserTagsService.batchUnTagging(appid, form.getTagid(), form.getOpenidList());
        return AjaxResult.success();
    }
}
