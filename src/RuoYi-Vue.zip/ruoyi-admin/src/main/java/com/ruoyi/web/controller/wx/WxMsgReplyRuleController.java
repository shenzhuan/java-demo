package com.ruoyi.web.controller.wx;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.wx.domain.WxMsgReplyRule;
import com.ruoyi.wx.service.IWxMsgReplyRuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 自动回复规则Controller
 *
 * @author é­éåå
 * @date 2021-06-26
 */
@RestController
@RequestMapping("/wx/WxMsgReplyRule")
public class WxMsgReplyRuleController extends BaseController {
    @Autowired
    private IWxMsgReplyRuleService wxMsgReplyRuleService;

    /**
     * 查询自动回复规则列表
     */
    @GetMapping("/list")
    public TableDataInfo list(WxMsgReplyRule wxMsgReplyRule) {
        startPage();
        List<WxMsgReplyRule> list = wxMsgReplyRuleService.selectWxMsgReplyRuleList(wxMsgReplyRule);
        return getDataTable(list);
    }

    /**
     * 导出自动回复规则列表
     */
    @Log(title = "自动回复规则", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(WxMsgReplyRule wxMsgReplyRule) {
        List<WxMsgReplyRule> list = wxMsgReplyRuleService.selectWxMsgReplyRuleList(wxMsgReplyRule);
        ExcelUtil<WxMsgReplyRule> util = new ExcelUtil<WxMsgReplyRule>(WxMsgReplyRule.class);
        return util.exportExcel(list, "WxMsgReplyRule");
    }

    /**
     * 获取自动回复规则详细信息
     */
    @GetMapping(value = "/{ruleId}")
    public AjaxResult getInfo(@PathVariable("ruleId") Long ruleId) {
        return AjaxResult.success(wxMsgReplyRuleService.selectWxMsgReplyRuleById(ruleId));
    }

    /**
     * 新增自动回复规则
     */

    @Log(title = "自动回复规则", businessType = BusinessType.INSERT)
    @PostMapping("/save")
    public AjaxResult add(@RequestBody WxMsgReplyRule wxMsgReplyRule) {
        return toAjax(wxMsgReplyRuleService.insertWxMsgReplyRule(wxMsgReplyRule));
    }

    /**
     * 修改自动回复规则
     */
    @Log(title = "自动回复规则", businessType = BusinessType.UPDATE)
    @PostMapping("/update")
    public AjaxResult edit(@RequestBody WxMsgReplyRule wxMsgReplyRule) {
        return toAjax(wxMsgReplyRuleService.updateWxMsgReplyRule(wxMsgReplyRule));
    }

    /**
     * 删除自动回复规则
     */
    @PreAuthorize("@ss.hasPermi('order:WxMsgReplyRule:remove')")
    @Log(title = "自动回复规则", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ruleIds}")
    public AjaxResult remove(@PathVariable Long[] ruleIds) {
        return toAjax(wxMsgReplyRuleService.deleteWxMsgReplyRuleByIds(ruleIds));
    }
}
