package com.ruoyi.web.controller.member;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.member.domain.UmsSimilarity;
import com.ruoyi.member.service.IUmsSimilarityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 用户相似度Controller
 *
 * @author é­éåå
 * @date 2021-01-22
 */
@RestController
@RequestMapping("/ums/UmsSimilarity")
public class UmsSimilarityController extends BaseController {
    @Autowired
    private IUmsSimilarityService umsSimilarityService;

    /**
     * 查询用户相似度列表
     */
    @PreAuthorize("@ss.hasPermi('ums:UmsSimilarity:list')")
    @GetMapping("/list")
    public TableDataInfo list(UmsSimilarity umsSimilarity) {
        startPage();
        List<UmsSimilarity> list = umsSimilarityService.selectUmsSimilarityList(umsSimilarity);
        return getDataTable(list);
    }

    /**
     * 导出用户相似度列表
     */
    @PreAuthorize("@ss.hasPermi('ums:UmsSimilarity:export')")
    @Log(title = "用户相似度", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(UmsSimilarity umsSimilarity) {
        List<UmsSimilarity> list = umsSimilarityService.selectUmsSimilarityList(umsSimilarity);
        ExcelUtil<UmsSimilarity> util = new ExcelUtil<UmsSimilarity>(UmsSimilarity.class);
        return util.exportExcel(list, "UmsSimilarity");
    }

    /**
     * 获取用户相似度详细信息
     */
    @PreAuthorize("@ss.hasPermi('ums:UmsSimilarity:query')")
    @GetMapping(value = "/{userId}")
    public AjaxResult getInfo(@PathVariable("userId") Long userId) {
        return AjaxResult.success(umsSimilarityService.selectUmsSimilarityById(userId));
    }

    /**
     * 新增用户相似度
     */
    @PreAuthorize("@ss.hasPermi('ums:UmsSimilarity:add')")
    @Log(title = "用户相似度", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody UmsSimilarity umsSimilarity) {
        return toAjax(umsSimilarityService.insertUmsSimilarity(umsSimilarity));
    }

    /**
     * 修改用户相似度
     */
    @PreAuthorize("@ss.hasPermi('ums:UmsSimilarity:edit')")
    @Log(title = "用户相似度", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody UmsSimilarity umsSimilarity) {
        return toAjax(umsSimilarityService.updateUmsSimilarity(umsSimilarity));
    }

    /**
     * 删除用户相似度
     */
    @PreAuthorize("@ss.hasPermi('ums:UmsSimilarity:remove')")
    @Log(title = "用户相似度", businessType = BusinessType.DELETE)
    @DeleteMapping("/{userIds}")
    public AjaxResult remove(@PathVariable Long[] userIds) {
        return toAjax(umsSimilarityService.deleteUmsSimilarityByIds(userIds));
    }
}
