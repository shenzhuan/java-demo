package com.ruoyi.web.controller.wx;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.wx.domain.WxMsgTemplate;
import com.ruoyi.wx.form.TemplateMsgBatchForm;
import com.ruoyi.wx.service.IWxMsgTemplateService;
import io.swagger.annotations.ApiOperation;
import me.chanjar.weixin.common.error.WxErrorException;
import me.chanjar.weixin.mp.api.WxMpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 消息模板Controller
 *
 * @author é­éåå
 * @date 2021-06-26
 */
@RestController
@RequestMapping("/wx/WxMsgTemplate")
public class WxMsgTemplateController extends BaseController {
    @Autowired
    private IWxMsgTemplateService wxMsgTemplateService;
    @Autowired
    private WxMpService wxMpService;


    /**
     * 查询消息模板列表
     */
    @GetMapping("/list")
    public TableDataInfo list(@CookieValue String appid, WxMsgTemplate wxMsgTemplate) {
        startPage();
        wxMsgTemplate.setAppid(appid);
        List<WxMsgTemplate> list = wxMsgTemplateService.selectWxMsgTemplateList(wxMsgTemplate);
        return getDataTable(list);
    }

    /**
     * 导出消息模板列表
     */
    @Log(title = "消息模板", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(WxMsgTemplate wxMsgTemplate) {
        List<WxMsgTemplate> list = wxMsgTemplateService.selectWxMsgTemplateList(wxMsgTemplate);
        ExcelUtil<WxMsgTemplate> util = new ExcelUtil<WxMsgTemplate>(WxMsgTemplate.class);
        return util.exportExcel(list, "WxMsgTemplate");
    }

    /**
     * 获取消息模板详细信息
     */
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(wxMsgTemplateService.selectWxMsgTemplateById(id));
    }

    /**
     * 信息
     */
    @GetMapping("/getByName")
    @ApiOperation(value = "详情-通过名称")
    public AjaxResult getByName(String name) {
        return AjaxResult.success(wxMsgTemplateService.getByName(name));
    }

    /**
     * 新增消息模板
     */
    @Log(title = "消息模板", businessType = BusinessType.INSERT)
    @PostMapping("/save")
    public AjaxResult add(@RequestBody WxMsgTemplate wxMsgTemplate) {
        return toAjax(wxMsgTemplateService.insertWxMsgTemplate(wxMsgTemplate));
    }

    /**
     * 修改消息模板
     */
    @Log(title = "消息模板", businessType = BusinessType.UPDATE)
    @PostMapping("/update")
    public AjaxResult edit(@RequestBody WxMsgTemplate wxMsgTemplate) {
        return toAjax(wxMsgTemplateService.updateWxMsgTemplate(wxMsgTemplate));
    }

    /**
     * 删除消息模板
     */
    @Log(title = "消息模板", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(wxMsgTemplateService.deleteWxMsgTemplateByIds(ids));
    }

    /**
     * 同步公众号模板
     */
    @PostMapping("/syncWxTemplate")
    @ApiOperation(value = "同步公众号模板")
    public AjaxResult syncWxTemplate(@CookieValue String appid) throws WxErrorException {
        this.wxMpService.switchoverTo(appid);
        wxMsgTemplateService.syncWxTemplate(appid);
        return AjaxResult.success();
    }

    /**
     * 批量向用户发送模板消息
     * 通过用户筛选条件（一般使用标签筛选），将消息发送给数据库中所有符合筛选条件的用户
     */
    @PostMapping("/sendMsgBatch")
    @ApiOperation(value = "批量向用户发送模板消息", notes = "将消息发送给数据库中所有符合筛选条件的用户")
    public AjaxResult sendMsgBatch(@CookieValue String appid, @RequestBody TemplateMsgBatchForm form) {
        this.wxMpService.switchoverTo(appid);
        wxMsgTemplateService.sendMsgBatch(form, appid);
        return AjaxResult.success();
    }
}
