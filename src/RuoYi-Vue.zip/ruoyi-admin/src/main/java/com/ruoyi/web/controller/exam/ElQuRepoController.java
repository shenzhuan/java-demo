package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElQuRepo;
import com.ruoyi.exam.service.IElQuRepoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 试题题库Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElQuRepo")
public class ElQuRepoController extends BaseController {
    @Autowired
    private IElQuRepoService elQuRepoService;

    /**
     * 查询试题题库列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuRepo:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElQuRepo elQuRepo) {
        startPage();
        List<ElQuRepo> list = elQuRepoService.selectElQuRepoList(elQuRepo);
        return getDataTable(list);
    }

    /**
     * 导出试题题库列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuRepo:export')")
    @Log(title = "试题题库", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElQuRepo elQuRepo) {
        List<ElQuRepo> list = elQuRepoService.selectElQuRepoList(elQuRepo);
        ExcelUtil<ElQuRepo> util = new ExcelUtil<ElQuRepo>(ElQuRepo.class);
        return util.exportExcel(list, "ElQuRepo");
    }

    /**
     * 获取试题题库详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuRepo:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elQuRepoService.selectElQuRepoById(id));
    }

    /**
     * 新增试题题库
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuRepo:add')")
    @Log(title = "试题题库", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElQuRepo elQuRepo) {
        return toAjax(elQuRepoService.insertElQuRepo(elQuRepo));
    }

    /**
     * 修改试题题库
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuRepo:edit')")
    @Log(title = "试题题库", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElQuRepo elQuRepo) {
        return toAjax(elQuRepoService.updateElQuRepo(elQuRepo));
    }

    /**
     * 删除试题题库
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuRepo:remove')")
    @Log(title = "试题题库", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elQuRepoService.deleteElQuRepoByIds(ids));
    }
}
