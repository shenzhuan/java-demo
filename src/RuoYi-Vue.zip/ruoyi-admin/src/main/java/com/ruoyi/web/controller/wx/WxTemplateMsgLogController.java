package com.ruoyi.web.controller.wx;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.wx.domain.WxTemplateMsgLog;
import com.ruoyi.wx.service.IWxTemplateMsgLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 微信模版消息发送记录Controller
 *
 * @author é­éåå
 * @date 2021-06-26
 */
@RestController
@RequestMapping("/wx/WxTemplateMsgLog")
public class WxTemplateMsgLogController extends BaseController {
    @Autowired
    private IWxTemplateMsgLogService wxTemplateMsgLogService;

    /**
     * 查询微信模版消息发送记录列表
     */
    @GetMapping("/list")
    public TableDataInfo list(@CookieValue String appid, WxTemplateMsgLog wxTemplateMsgLog) {
        wxTemplateMsgLog.setAppid(appid);
        startPage();
        List<WxTemplateMsgLog> list = wxTemplateMsgLogService.selectWxTemplateMsgLogList(wxTemplateMsgLog);
        return getDataTable(list);
    }

    /**
     * 导出微信模版消息发送记录列表
     */
    @Log(title = "微信模版消息发送记录", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(WxTemplateMsgLog wxTemplateMsgLog) {
        List<WxTemplateMsgLog> list = wxTemplateMsgLogService.selectWxTemplateMsgLogList(wxTemplateMsgLog);
        ExcelUtil<WxTemplateMsgLog> util = new ExcelUtil<WxTemplateMsgLog>(WxTemplateMsgLog.class);
        return util.exportExcel(list, "WxTemplateMsgLog");
    }

    /**
     * 获取微信模版消息发送记录详细信息
     */
    @GetMapping(value = "/{logId}")
    public AjaxResult getInfo(@PathVariable("logId") Long logId) {
        return AjaxResult.success(wxTemplateMsgLogService.selectWxTemplateMsgLogById(logId));
    }

    /**
     * 新增微信模版消息发送记录
     */
    @Log(title = "微信模版消息发送记录", businessType = BusinessType.INSERT)
    @PostMapping("/save")
    public AjaxResult add(@RequestBody WxTemplateMsgLog wxTemplateMsgLog) {
        return toAjax(wxTemplateMsgLogService.insertWxTemplateMsgLog(wxTemplateMsgLog));
    }

    /**
     * 修改微信模版消息发送记录
     */
    @Log(title = "微信模版消息发送记录", businessType = BusinessType.UPDATE)
    @PostMapping("/update")
    public AjaxResult edit(@RequestBody WxTemplateMsgLog wxTemplateMsgLog) {
        return toAjax(wxTemplateMsgLogService.updateWxTemplateMsgLog(wxTemplateMsgLog));
    }

    /**
     * 删除微信模版消息发送记录
     */

    @Log(title = "微信模版消息发送记录", businessType = BusinessType.DELETE)
    @DeleteMapping("/{logIds}")
    public AjaxResult remove(@PathVariable Long[] logIds) {
        return toAjax(wxTemplateMsgLogService.deleteWxTemplateMsgLogByIds(logIds));
    }
}
