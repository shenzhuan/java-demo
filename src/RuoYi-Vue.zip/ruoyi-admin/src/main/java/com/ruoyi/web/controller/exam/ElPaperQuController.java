package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElPaperQu;
import com.ruoyi.exam.service.IElPaperQuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 试卷考题Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElPaperQu")
public class ElPaperQuController extends BaseController {
    @Autowired
    private IElPaperQuService elPaperQuService;

    /**
     * 查询试卷考题列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQu:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElPaperQu elPaperQu) {
        startPage();
        List<ElPaperQu> list = elPaperQuService.selectElPaperQuList(elPaperQu);
        return getDataTable(list);
    }

    /**
     * 导出试卷考题列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQu:export')")
    @Log(title = "试卷考题", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElPaperQu elPaperQu) {
        List<ElPaperQu> list = elPaperQuService.selectElPaperQuList(elPaperQu);
        ExcelUtil<ElPaperQu> util = new ExcelUtil<ElPaperQu>(ElPaperQu.class);
        return util.exportExcel(list, "ElPaperQu");
    }

    /**
     * 获取试卷考题详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQu:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elPaperQuService.selectElPaperQuById(id));
    }

    /**
     * 新增试卷考题
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQu:add')")
    @Log(title = "试卷考题", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElPaperQu elPaperQu) {
        return toAjax(elPaperQuService.insertElPaperQu(elPaperQu));
    }

    /**
     * 修改试卷考题
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQu:edit')")
    @Log(title = "试卷考题", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElPaperQu elPaperQu) {
        return toAjax(elPaperQuService.updateElPaperQu(elPaperQu));
    }

    /**
     * 删除试卷考题
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQu:remove')")
    @Log(title = "试卷考题", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elPaperQuService.deleteElPaperQuByIds(ids));
    }
}
