package com.ruoyi.goods.controller;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.goods.domain.PmsViewGoods;
import com.ruoyi.goods.service.IPmsViewGoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 商品浏览记录Controller
 *
 * @author 魔金
 * @date 2021-01-22
 */
@RestController
@RequestMapping("/pms/PmsViewGoods")
public class PmsViewGoodsController extends BaseController {
    @Autowired
    private IPmsViewGoodsService pmsViewGoodsService;

    /**
     * 查询商品浏览记录列表
     */
    @PreAuthorize("@ss.hasPermi('pms:PmsViewGoods:list')")
    @GetMapping("/list")
    public TableDataInfo list(PmsViewGoods pmsViewGoods) {
        startPage();
        List<PmsViewGoods> list = pmsViewGoodsService.selectPmsViewGoodsList(pmsViewGoods);
        return getDataTable(list);
    }

    /**
     * 导出商品浏览记录列表
     */
    @PreAuthorize("@ss.hasPermi('pms:PmsViewGoods:export')")
    @Log(title = "商品浏览记录", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(PmsViewGoods pmsViewGoods) {
        List<PmsViewGoods> list = pmsViewGoodsService.selectPmsViewGoodsList(pmsViewGoods);
        ExcelUtil<PmsViewGoods> util = new ExcelUtil<PmsViewGoods>(PmsViewGoods.class);
        return util.exportExcel(list, "PmsViewGoods");
    }


    /**
     * 新增商品浏览记录
     */
    @PreAuthorize("@ss.hasPermi('pms:PmsViewGoods:add')")
    @Log(title = "商品浏览记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody PmsViewGoods pmsViewGoods) {
        return toAjax(pmsViewGoodsService.insertPmsViewGoods(pmsViewGoods));
    }

    /**
     * 修改商品浏览记录
     */
    @PreAuthorize("@ss.hasPermi('pms:PmsViewGoods:edit')")
    @Log(title = "商品浏览记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody PmsViewGoods pmsViewGoods) {
        return toAjax(pmsViewGoodsService.updatePmsViewGoods(pmsViewGoods));
    }

    /**
     * 删除商品浏览记录
     */
    @PreAuthorize("@ss.hasPermi('pms:PmsViewGoods:remove')")
    @Log(title = "商品浏览记录", businessType = BusinessType.DELETE)
    @DeleteMapping("/{userIds}")
    public AjaxResult remove(@PathVariable Long[] userIds) {
        return toAjax(pmsViewGoodsService.deletePmsViewGoodsByIds(userIds));
    }
}
