/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:OmsBillingRecordsController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.order;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.order.domain.OmsBillingRecords;
import com.ruoyi.order.service.IOmsBillingRecordsService;
import com.ruoyi.order.vo.QueryBillCriteria;
import com.ruoyi.order.vo.StoreBilling;
import com.ruoyi.util.BaseResponse;
import com.ruoyi.util.CommonConstant;
import com.ruoyi.util.PageHelper;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * 账单记录Controller
 *
 * @author 魔金商城
 * @date 2020-07-24
 */
@RestController
@RequestMapping("/order/OmsBillingRecords")
public class OmsBillingRecordsController extends BaseController {
    @Autowired
    private IOmsBillingRecordsService omsBillingRecordsService;

    /**
     * 分页查询店铺账单
     *
     * @param pageHelper    分页帮助类
     * @param queryCriteria 查询条件
     * @return 店铺账单列表
     */
    @GetMapping("/storebillings")
    @ApiOperation(value = "分页查询店铺账单", notes = "分页查询店铺账单（需要认证）")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "mobile", value = "店铺手机号码"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "storeName", value = "店铺名称"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "店铺账单列表", response = OmsBillingRecords.class)
    })
    public BaseResponse queryStoreBillingList(@ApiIgnore PageHelper<StoreBilling> pageHelper, @ApiIgnore QueryBillCriteria queryCriteria) {
        queryCriteria.setStoreId(CommonConstant.ADMIN_STOREID);
        return BaseResponse.build(omsBillingRecordsService.queryStoreBillings(pageHelper, queryCriteria));
    }

    /**
     * 分页查询店铺对账记录
     *
     * @param pageHelper    分页帮助类
     * @param queryCriteria 查询参数
     * @return 店铺对账记录列表
     */
    @GetMapping("/storebillingrecords")
    @ApiOperation(value = "分页查询店铺对账记录", notes = "分页查询店铺对账记录（需要认证）")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "storeId", value = "店铺id"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "status", value = "结算状态 0 未结算 1 已结算 默认0"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "店铺对账记录列表", response = OmsBillingRecords.class)
    })
    public BaseResponse queryStoreBillingRecords(@ApiIgnore PageHelper<OmsBillingRecords> pageHelper, @ApiIgnore QueryBillCriteria queryCriteria) {
        return BaseResponse.build(omsBillingRecordsService.queryStoreBillingRecords(pageHelper, queryCriteria));
    }

    /**
     * 设置店铺对账记录状态为已结算
     *
     * @param ids 对账记录id数组
     * @return 成功>=1 否则失败
     */
    @PutMapping("/storebillingrecord")
    @ApiOperation(value = "设置店铺对账记录状态为已结算", notes = "设置店铺对账记录状态为已结算（需要认证）")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "array", name = "ids", value = "对账记录id数组"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "成功>=1 否则失败", response = Integer.class)
    })
    public int updateStoreBillingRecordStatus(Long[] ids) {
        return omsBillingRecordsService.updateStatus(ids);
    }

    /**
     * 查询账单记录列表
     */
    @PreAuthorize("@ss.hasPermi('order:OmsBillingRecords:list')")
    @GetMapping("/list")
    public TableDataInfo list(OmsBillingRecords omsBillingRecords) {
        startPage();
        List<OmsBillingRecords> list = omsBillingRecordsService.selectOmsBillingRecordsList(omsBillingRecords);
        return getDataTable(list);
    }

    /**
     * 导出账单记录列表
     */
    @PreAuthorize("@ss.hasPermi('order:OmsBillingRecords:export')")
    @Log(title = "账单记录", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(OmsBillingRecords omsBillingRecords) {
        List<OmsBillingRecords> list = omsBillingRecordsService.selectOmsBillingRecordsList(omsBillingRecords);
        ExcelUtil<OmsBillingRecords> util = new ExcelUtil<OmsBillingRecords>(OmsBillingRecords.class);
        return util.exportExcel(list, "OmsBillingRecords");
    }

    /**
     * 获取账单记录详细信息
     */
    @PreAuthorize("@ss.hasPermi('order:OmsBillingRecords:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(omsBillingRecordsService.selectOmsBillingRecordsById(id));
    }

    /**
     * 新增账单记录
     */
    @PreAuthorize("@ss.hasPermi('order:OmsBillingRecords:add')")
    @Log(title = "账单记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody OmsBillingRecords omsBillingRecords) {
        return toAjax(omsBillingRecordsService.insertOmsBillingRecords(omsBillingRecords));
    }

    /**
     * 修改账单记录
     */
    @PreAuthorize("@ss.hasPermi('order:OmsBillingRecords:edit')")
    @Log(title = "账单记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody OmsBillingRecords omsBillingRecords) {
        return toAjax(omsBillingRecordsService.updateOmsBillingRecords(omsBillingRecords));
    }

    /**
     * 删除账单记录
     */
    @PreAuthorize("@ss.hasPermi('order:OmsBillingRecords:remove')")
    @Log(title = "账单记录", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(omsBillingRecordsService.deleteOmsBillingRecordsByIds(ids));
    }
}
