package com.ruoyi.web.controller.wx;

import com.baomidou.mybatisplus.extension.api.R;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.wx.domain.WxMsg;
import com.ruoyi.wx.form.WxMsgReplyForm;
import com.ruoyi.wx.service.IWxMsgReplyRuleService;
import com.ruoyi.wx.service.IWxMsgService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 微信消息Controller
 *
 * @author é­éåå
 * @date 2021-06-26
 */
@RestController
@RequestMapping("/wx/WxMsg")
public class WxMsgController extends BaseController {
    @Autowired
    private IWxMsgService wxMsgService;
    @Autowired
    private IWxMsgReplyRuleService msgReplyRuleService;
    /**
     * 查询微信消息列表
     */
    @GetMapping("/list")
    public TableDataInfo list(WxMsg wxMsg) {
        startPage();
        List<WxMsg> list = wxMsgService.selectWxMsgList(wxMsg);
        return getDataTable(list);
    }
    /**
     * 回复
     */
    @PostMapping("/reply")
    @ApiOperation(value = "回复")
    public AjaxResult reply(@CookieValue String appid, @RequestBody WxMsgReplyForm form){
        msgReplyRuleService.reply(form.getOpenid(),form.getReplyType(),form.getReplyContent());
        return AjaxResult.success();
    }
    /**
     * 导出微信消息列表
     */
    @Log(title = "微信消息", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(WxMsg wxMsg) {
        List<WxMsg> list = wxMsgService.selectWxMsgList(wxMsg);
        ExcelUtil<WxMsg> util = new ExcelUtil<WxMsg>(WxMsg.class);
        return util.exportExcel(list, "WxMsg");
    }

    /**
     * 获取微信消息详细信息
     */

    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(wxMsgService.selectWxMsgById(id));
    }

    /**
     * 新增微信消息
     */

    @Log(title = "微信消息", businessType = BusinessType.INSERT)
    @PostMapping("/save")
    public AjaxResult add(@RequestBody WxMsg wxMsg) {
        return toAjax(wxMsgService.insertWxMsg(wxMsg));
    }

    /**
     * 修改微信消息
     */

    @Log(title = "微信消息", businessType = BusinessType.UPDATE)
    @PostMapping("/update")
    public AjaxResult edit(@RequestBody WxMsg wxMsg) {
        return toAjax(wxMsgService.updateWxMsg(wxMsg));
    }

    /**
     * 删除微信消息
     */
    @Log(title = "微信消息", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(wxMsgService.deleteWxMsgByIds(ids));
    }
}
