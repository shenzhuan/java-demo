/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:RyTask.java
 * Date:2021/01/14 20:04:14
 */

package com.ruoyi.web.task;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ruoyi.common.constant.Constants;
import com.ruoyi.common.core.redis.RedisCache;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.WechatAppletDataUtils;
import com.ruoyi.common.utils.WechatParam;
import com.ruoyi.common.utils.bean.WechatSetting;
import com.ruoyi.common.utils.http.HttpUtils;
import com.ruoyi.goods.domain.PmsViewGoods;
import com.ruoyi.goods.service.IPmsGoodsService;
import com.ruoyi.goods.service.IPmsTypeService;
import com.ruoyi.goods.service.IPmsViewGoodsService;
import com.ruoyi.luence.LuenceService;
import com.ruoyi.marketing.service.GroupMarketingShowService;
import com.ruoyi.marketing.service.PreSaleShowService;
import com.ruoyi.marketing.service.TryMarketingShowService;
import com.ruoyi.marketing.service.TrySkuApplyService;
import com.ruoyi.member.domain.UmsSimilarity;
import com.ruoyi.member.service.IUmsSimilarityService;
import com.ruoyi.order.mapper.OmsOrderMapper;
import com.ruoyi.order.service.IOmsOrderService;
import com.ruoyi.order.service.IOrderApiService;
import com.ruoyi.recommend.RecommendUtils;
import com.ruoyi.setting.bean.WechatPaySet;
import com.ruoyi.setting.service.ILsPaySettingService;
import com.ruoyi.sms.domain.TAppletPageVisit;
import com.ruoyi.sms.domain.TAppletVisit;
import com.ruoyi.sms.domain.TAppletVisitStatic;
import com.ruoyi.sms.service.*;
import com.ruoyi.store.domain.TStoreInfo;
import com.ruoyi.store.mapper.TStoreInfoMapper;
import com.ruoyi.system.service.ISysNoticeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 定时任务调度测试
 *
 * @author ruoyi
 */
@Slf4j
@Component("ryTask")
public class RyTask {
    @Autowired
    TestSynController testSynController;
    /**
     * 试用申请接口实现类
     */
    @Autowired
    private TrySkuApplyService trySkuApplyService;
    /**
     * 注入订单服务接口
     */
    @Autowired
    private IOrderApiService IOrderApiService;
    /**
     * 注入拼团活动服务接口
     */
    @Autowired
    private GroupMarketingShowService groupMarketingShowService;
    /**
     * 注入试用活动服务接口
     */
    @Autowired
    private TryMarketingShowService tryMarketingShowService;
    /**
     * 注入预售活动服务接口
     */
    @Autowired
    private PreSaleShowService preSaleShowService;
    @Resource
    private ISmsHomeNewProductService homeNewProductService;
    @Resource
    private ISmsHomeRecommendProductService homeRecommendProductService;
    @Resource
    private ISmsHomeBrandService homeBrandService;
    @Resource
    private ISmsHomeRecommendSubjectService homeRecommendSubjectService;
    @Resource
    private ISmsHomeAdvertiseService homeAdvertiseService;
    @Resource
    private ISysNoticeService sysNoticeService;
    @Resource
    private IPmsTypeService typeService;
    @Autowired
    private IPmsGoodsService pmsGoodsService;
    @Autowired
    private ITAppletVisitService appletVisitService;
    @Autowired
    private ITAppletPageVisitService appletPageVisitService;
    @Autowired
    private ITAppletVisitStaticService appletVisitStaticService;
    @Autowired
    private ILsPaySettingService paySettingService;
    @Autowired
    private IPmsViewGoodsService viewGoodsService;
    @Autowired
    private IUmsSimilarityService similarityService;
    @Resource
    private LuenceService luenceService;
    @Autowired
    private RedisCache redisCache;
    @Autowired
    private OmsOrderMapper orderMapper;
    @Autowired
    private TStoreInfoMapper storeInfoMapper;

    public void ryMultipleParams(String s, Boolean b, Long l, Double d, Integer i) {
        //    System.out.println(StringUtils.format("执行多参方法： 字符串类型{}，布尔类型{}，长整型{}，浮点型{}，整形{}", s, b, l, d, i));
    }

    /**
     * 计算店铺的销量
     */
    public void ryNoParams() {
        List<TStoreInfo> storeInfoList = storeInfoMapper.selectTStoreInfoList(new TStoreInfo());
        for (TStoreInfo store : storeInfoList){
            store.setSale(orderMapper.saleNum(store.getId()));
            if (store.getSale()>0){
                storeInfoMapper.updateTStoreInfo(store);
            }
        }

    }
    public void ryParams(String params) {

    }

    /**
     * 同步商品数据到luence
     */
    public void createProductIndex() throws IOException {
       /* Long t=System.currentTimeMillis();
        log.debug("构建商品索引......start");
        PmsGoods goods = new PmsGoods();
        goods.setShelvesStatus("1");
        goods.setStatus(StatusEnum.AuditType.SUCESS.code()+"");
        luenceService.createProductIndex(pmsGoodsService.selectPmsGoodsList(goods));
        log.debug("构建商品索引......end"+(System.currentTimeMillis()-t)/1000+"m");*/

    }

    /**
     * 计算用户的相似度
     */
    public void calLoginUserSimilarity() {
        Long t = System.currentTimeMillis();
        log.debug("计算用户的相似度calLoginUserSimilarity......start");
        // 1.查询所有的用户浏览记录
        PmsViewGoods viewGoods = new PmsViewGoods();
        List<PmsViewGoods> viewGoodsList = viewGoodsService.selectPmsViewGoodsList(viewGoods);

        // 2.调用推荐模块工具类的方法组装成一个ConcurrentHashMap来存储每个用户以及其对应的二级类目的点击量
        ConcurrentHashMap<Long, ConcurrentHashMap<Long, PmsViewGoods>> goodsBehavior = RecommendUtils.assembleUserGoodsBehavior(viewGoodsList);

        // 3.调用推荐模块工具类的方法计算用户与用户之间的相似度
        List<UmsSimilarity> similarityList = RecommendUtils.calcSimilarityBetweenUsers(goodsBehavior);

        // 4.输出计算好的用户之间的相似度
        for (UmsSimilarity usim : similarityList) {
            // 5.如果用户之间的相似度已经存在与数据库中就修改，不存在就添加
            if (!usim.getUserId().equals(usim.getUserRefId())) {
                if (similarityService.countUserSimilarity(usim) > 0) { // 修改
                    similarityService.updateUmsSimilarity(usim);
                } else { // 新增
                    similarityService.insertUmsSimilarity(usim);
                }
            }
        }
        log.debug("计算用户的相似度calLoginUserSimilarity......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }



    /**
     * 清理 因为商品被删除 导致的数据关联问题 半小时一次
     */
    // @Scheduled(cron = "0 0/30 * ? * ?")
    private void clearGoodsRelate() {

        Long t = System.currentTimeMillis();
        log.info("清理 因为商品被删除 导致的数据关联问题start = {}", new Date());
        String redisKey = Constants.GOODS_DOWN;
        Long size = redisCache.getListSize(redisKey);

        if (size < 1) {
            return;
        }
        for (int i = 0; i < size; i++) {
            //如果10秒钟拿不到一个数据，那么退出循环
            Long id = (Long) redisCache.getRightPop(redisKey, 10L);
            if (null == id) {
                continue;
            }
            try {
                homeNewProductService.deleteSmsHomeNewProductById(id);
                int result = homeRecommendProductService.deleteSmsHomeRecommendProductById(id);
                if (false) {
                    redisCache.lPush(redisKey, id);
                }
            } catch (Exception e) {
                redisCache.lPush(redisKey, id);
            }
        }

        /*List<SmsHomeRecommendProduct> homeRecommendProductList = homeRecommendProductService.selectSmsHomeRecommendProductList(new SmsHomeRecommendProduct());
        List<SmsHomeNewProduct> homeNewProducts = homeNewProductService.selectSmsHomeNewProductList(new SmsHomeNewProduct());
        List<PmsGoods> productList = pmsGoodsService.selectPmsGoodsList(new PmsGoods());
        List<Long> ids = productList.stream().map(PmsGoods::getId).collect(Collectors.toList());
        for (SmsHomeNewProduct product : homeNewProducts) {
            if (!ids.contains(product.getProductId())) {
                homeNewProductService.deleteSmsHomeNewProductById(product.getId());
            }
        }
        for (SmsHomeRecommendProduct product : homeRecommendProductList) {
            if (!ids.contains(product.getProductId())) {
                homeRecommendProductService.deleteSmsHomeRecommendProductById(product.getId());
            }
        }*/
        log.debug("清理 因为商品被删除 导致的数据关联问题......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 扫描已结束的试用促销，并随机抽取获得申请资格的人
     */
    //@Scheduled(cron = "0 0 2 * * ?")
    public void randomExtractApplyCustomer() {
        Long t = System.currentTimeMillis();
        log.info("扫描已结束的试用促销，并随机抽取获得申请资格的人start = {}", new Date());
        trySkuApplyService.randomExtractApplyCustomer();
        log.debug("扫描已结束的试用促销，并随机抽取获得申请资格的人......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 确认收货
     */
    // @Scheduled(cron = "0 0 2 * * ?")
    public void autoConfirmReceipt() {
        Long t = System.currentTimeMillis();
        log.info("确认收货start = {}", new Date());
        IOrderApiService.autoConfirmReceipt();
        log.debug("确认收货......end" + (System.currentTimeMillis() - t) / 1000 + "m");
        /*for (int j = 0; j < 10000; j++) {
            String url = "https://ceres.zkthink.com/api/classify/getClaasifyProducts";
            String rspStr = HttpUtils.sendGet(url, "classifyId=770&type=1&volume=1&productName=&page=1&pageSize=200");
            JSONObject obj = JSONObject.parseObject(rspStr);
            System.out.println(obj);
            JSONObject obj1 = JSONObject.parseObject(obj.getString("data"));
            System.out.println(obj1.getString("list"));
            JSONArray region = obj1.getJSONArray("list");
            for (int i = 0; i < region.size(); i++) {
                try {
                    String uu = "https://ceres.zkthink.com/api/product/getProducts";
                    String rspStr1 = HttpUtils.sendGet(uu, "skuId=" + region.getJSONObject(i).getLong("skuId") + "&productId=" + region.getJSONObject(i).getLong("productId"));
                    System.out.println(rspStr1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }*/
    }

    /**
     * 取消订单
     */
    // @Scheduled(cron = "0 0 2 * * ?")
    public void autoCancelOrder() {
        Long t = System.currentTimeMillis();
        log.info("取消订单start = {}", new Date());
        IOrderApiService.autoCancelOrder();
        log.debug("取消订单......end" + (System.currentTimeMillis() - t) / 1000 + "m");

    }

    /**
     * 处理超过24小时的拼团订单
     */
    // @Scheduled(cron = "0 0 0/2 * * ? ")
    public void autoCancelGroupOrder() {
        Long t = System.currentTimeMillis();
        log.info("处理超过24小时的拼团订单start = {}", new Date());
        IOrderApiService.autoCancelGroupOrder();
        log.debug("处理超过24小时的拼团订单......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 自动取消定金预售订单
     */
    // @Scheduled(cron = "0 0 0 24 * ? ")
    public void autoCancelDepositPreSaleOrder() {
        Long t = System.currentTimeMillis();
        log.info("清理 因为商品被删除 导致的数据关联问题start = {}", new Date());
        IOrderApiService.autoCancelDepositPreSaleOrder();
        log.debug("计算用户的相似度calLoginUserSimilarity......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 处理已结束的众筹订单
     */
    // @Scheduled(cron = "0 0 2 * * ?")
    public void autoHandleCrowdFundingOrder() {
        Long t = System.currentTimeMillis();
        log.info("处理已结束的众筹订单start = {}", new Date());
        IOrderApiService.autoHandleCrowdFundingOrder();
        log.debug("处理已结束的众筹订单......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 自动删除结束的拼团活动
     */
    // @Scheduled(cron = "0 0 0 * * ?")
    public void autoDeleteEndGroups() {
        Long t = System.currentTimeMillis();
        log.info("自动删除结束的拼团活动start = {}", new Date());
        groupMarketingShowService.autoDeleteEndGroups();
        log.debug("自动删除结束的拼团活动......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 自动删除结束的试用活动
     */
    // @Scheduled(cron = "0 0 0 * * ?")
    public void autoDeleteEndTrys() {
        Long t = System.currentTimeMillis();
        log.info("清理 因为商品被删除 导致的数据关联问题start = {}", new Date());
        tryMarketingShowService.autoDeleteEndTrys();
        log.debug("计算用户的相似度calLoginUserSimilarity......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 自动删除结束的预售活动
     */
    // @Scheduled(cron = "0 0 0 * * ?")
    public void autoDeleteEndPreSales() {
        Long t = System.currentTimeMillis();
        log.info("自动删除结束的预售活动 = {}", new Date());
        preSaleShowService.autoDeleteEndPreSales();
        log.debug("自动删除结束的预售活动......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 访问页面。目前只提供按 page_visit_pv 排序的 top200。
     */
    // @Scheduled(cron = "0 18 11 * * ? *")
    public void getVisitPage() {
        Long t = System.currentTimeMillis();
        log.debug("访问页面。目前只提供按 page_visit_pv 排序的 top200......start");
        WechatPaySet wechatAppletPaySet = paySettingService.queryPaySet(0).getWechatAppletPaySet();
        WechatSetting wechatSetting = new WechatSetting();
        wechatSetting.setAppId(wechatAppletPaySet.getAppId());
        wechatSetting.setAppSecret(wechatAppletPaySet.getAppSecret());
        WechatParam param = new WechatParam();
        String yesterday = DateUtils.parseDateToStr("yyyyMMdd", DateUtils.addDays(new Date(), -1));
        param.setBegin_date(yesterday);
        param.setEnd_date(yesterday);
        String json = WechatAppletDataUtils.getVisitPage(wechatSetting, param);
        JSONObject object = JSONObject.parseObject(json);
        if (object != null) {
            JSONArray array = JSONArray.parseArray(object.get("list").toString());
            for (int i = 0; i < array.size(); i++) {
                TAppletPageVisit pageVisit = new TAppletPageVisit();
                pageVisit.setPagePath(array.getJSONObject(i).get("page_path").toString());
                pageVisit.setPageVisitUv((Integer) array.getJSONObject(i).get("page_visit_uv"));
                pageVisit.setPageVisitPv((Integer) array.getJSONObject(i).get("page_visit_pv"));
                pageVisit.setPageStaytimePv(array.getJSONObject(i).getBigDecimal("page_staytime_pv"));
                pageVisit.setEntrypagePv((Integer) array.getJSONObject(i).get("entrypage_pv"));
                pageVisit.setExitpagePv((Integer) array.getJSONObject(i).get("exitpage_pv"));
                pageVisit.setPageSharePv((Integer) array.getJSONObject(i).get("page_share_pv"));
                pageVisit.setPageShareUv((Integer) array.getJSONObject(i).get("page_share_uv"));
                pageVisit.setCreateTime(new Date());
                pageVisit.setStoreId(0L);
                appletPageVisitService.insertTAppletPageVisit(pageVisit);

            }
        }

        log.debug("访问页面。目前只提供按 page_visit_pv 排序的 top200.....end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 获取小程序新增或活跃用户的画像分布数据。时间范围支持昨天、最近7天、最近30天。其中，新增用户数为时间范围内首次访问小程序的去重用户数，活跃用户数为时间范围内访问过小程序的去重用户数
     */
    // @Scheduled(cron = "0 18 11 * * ? *")
    public void getUserPortrait1() {
        Long t = System.currentTimeMillis();
        log.debug("获取小程序新增或活跃用户的画像分布数据。......start");
        WechatPaySet wechatAppletPaySet = paySettingService.queryPaySet(0).getWechatAppletPaySet();
        WechatSetting wechatSetting = new WechatSetting();
        wechatSetting.setAppId(wechatAppletPaySet.getAppId());
        wechatSetting.setAppSecret(wechatAppletPaySet.getAppSecret());
        WechatParam param = new WechatParam();
        String yesterday = DateUtils.parseDateToStr("yyyyMMdd", DateUtils.addDays(new Date(), -1));
        param.setBegin_date(yesterday);
        param.setEnd_date(yesterday);
        String json = WechatAppletDataUtils.getUserPortrait(wechatSetting, param);
        JSONObject object = JSONObject.parseObject(json);
        JSONObject visit_uv_new = JSONObject.parseObject(object.get("visit_uv_new").toString());
        JSONArray platforms = JSONArray.parseArray(visit_uv_new.get("platforms").toString());
        for (int i = 0; i < platforms.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(platforms.getJSONObject(i).getLong("id"));
            pageVisit.setName(platforms.getJSONObject(i).get("name").toString());
            pageVisit.setValue(platforms.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("4");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray devices = JSONArray.parseArray(visit_uv_new.get("devices").toString());
        for (int i = 0; i < devices.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(devices.getJSONObject(i).getLong("value"));
            pageVisit.setName(devices.getJSONObject(i).get("name").toString());
            pageVisit.setValue(devices.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("5");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray ages = JSONArray.parseArray(visit_uv_new.get("ages").toString());
        for (int i = 0; i < ages.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(ages.getJSONObject(i).getLong("id"));
            pageVisit.setName(ages.getJSONObject(i).get("name").toString());
            pageVisit.setValue(ages.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("6");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray genders = JSONArray.parseArray(visit_uv_new.get("genders").toString());
        for (int i = 0; i < genders.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(genders.getJSONObject(i).getLong("id"));
            pageVisit.setName(genders.getJSONObject(i).get("name").toString());
            pageVisit.setValue(genders.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("3");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }

        JSONArray province = JSONArray.parseArray(visit_uv_new.get("province").toString());
        for (int i = 0; i < province.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(province.getJSONObject(i).getLong("id"));
            pageVisit.setName(province.getJSONObject(i).get("name").toString());
            pageVisit.setValue(province.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("1");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray city = JSONArray.parseArray(visit_uv_new.get("city").toString());
        for (int i = 0; i < city.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(city.getJSONObject(i).getLong("id"));
            pageVisit.setName(city.getJSONObject(i).get("name").toString());
            pageVisit.setValue(city.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("2");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        /** 新增（1省，2市，3性别，4平台 5设备 6 年龄）
         留存（11省，12市，13性别，14平台 15设备 16 年龄） */

        log.debug("获取小程序新增或活跃用户的画像分布数据。......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 获取小程序新增或活跃用户的画像分布数据。时间范围支持昨天、最近7天、最近30天。其中，新增用户数为时间范围内首次访问小程序的去重用户数，活跃用户数为时间范围内访问过小程序的去重用户数
     */
    // @Scheduled(cron = "0 18 11 * * ? *")
    public void getUserPortrait2() {
        Long t = System.currentTimeMillis();
        log.debug("获取小程序新增或活跃用户的画像分布数据2......start");
        WechatPaySet wechatAppletPaySet = paySettingService.queryPaySet(0).getWechatAppletPaySet();
        WechatSetting wechatSetting = new WechatSetting();
        wechatSetting.setAppId(wechatAppletPaySet.getAppId());
        wechatSetting.setAppSecret(wechatAppletPaySet.getAppSecret());
        WechatParam param = new WechatParam();
        String yesterday = DateUtils.parseDateToStr("yyyyMMdd", DateUtils.addDays(new Date(), -1));
        param.setBegin_date(yesterday);
        param.setEnd_date(yesterday);
        String json = WechatAppletDataUtils.getUserPortrait(wechatSetting, param);
        JSONObject object = JSONObject.parseObject(json);
        JSONObject visit_uv_new = JSONObject.parseObject(object.get("visit_uv").toString());
        JSONArray platforms = JSONArray.parseArray(visit_uv_new.get("platforms").toString());
        for (int i = 0; i < platforms.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(platforms.getJSONObject(i).getLong("id"));
            pageVisit.setName(platforms.getJSONObject(i).get("name").toString());
            pageVisit.setValue(platforms.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("14");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray devices = JSONArray.parseArray(visit_uv_new.get("devices").toString());
        for (int i = 0; i < devices.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(devices.getJSONObject(i).getLong("value"));
            pageVisit.setName(devices.getJSONObject(i).get("name").toString());
            pageVisit.setValue(devices.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("15");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray ages = JSONArray.parseArray(visit_uv_new.get("ages").toString());
        for (int i = 0; i < ages.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(ages.getJSONObject(i).getLong("id"));
            pageVisit.setName(ages.getJSONObject(i).get("name").toString());
            pageVisit.setValue(ages.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("16");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray genders = JSONArray.parseArray(visit_uv_new.get("genders").toString());
        for (int i = 0; i < genders.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(genders.getJSONObject(i).getLong("id"));
            pageVisit.setName(genders.getJSONObject(i).get("name").toString());
            pageVisit.setValue(genders.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("13");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }

        JSONArray province = JSONArray.parseArray(visit_uv_new.get("province").toString());
        for (int i = 0; i < province.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(province.getJSONObject(i).getLong("id"));
            pageVisit.setName(province.getJSONObject(i).get("name").toString());
            pageVisit.setValue(province.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("11");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray city = JSONArray.parseArray(visit_uv_new.get("city").toString());
        for (int i = 0; i < city.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(city.getJSONObject(i).getLong("id"));
            pageVisit.setName(city.getJSONObject(i).get("name").toString());
            pageVisit.setValue(city.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("12");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        /** 新增（1省，2市，3性别，4平台 5设备 6 年龄）
         留存（11省，12市，13性别，14平台 15设备 16 年龄） */

        log.debug("获取小程序新增或活跃用户的画像分布数据2......end" + (System.currentTimeMillis() - t) / 1000 + "m");
    }

    /**
     * 获取用户访问小程序日留存
     */
    @Scheduled(cron = "0 18 11 * * ? *")
    public void getDailyRetain() {
        log.debug("获取用户访问小程序日留存......start");
        Long t = System.currentTimeMillis();
        appletVisitService.insertTAppletVisit(appletVisitService.getDailyRetain(-1));
        log.debug("获取用户访问小程序日留存......end" + (System.currentTimeMillis() - t) / 1000 + "m");

    }
}
