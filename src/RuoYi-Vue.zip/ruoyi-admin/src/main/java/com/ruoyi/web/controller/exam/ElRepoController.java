package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElRepo;
import com.ruoyi.exam.service.IElRepoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 题库Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElRepo")
public class ElRepoController extends BaseController {
    @Autowired
    private IElRepoService elRepoService;

    /**
     * 查询题库列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElRepo:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElRepo elRepo) {
        startPage();
        List<ElRepo> list = elRepoService.selectElRepoList(elRepo);
        return getDataTable(list);
    }

    /**
     * 导出题库列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElRepo:export')")
    @Log(title = "题库", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElRepo elRepo) {
        List<ElRepo> list = elRepoService.selectElRepoList(elRepo);
        ExcelUtil<ElRepo> util = new ExcelUtil<ElRepo>(ElRepo.class);
        return util.exportExcel(list, "ElRepo");
    }

    /**
     * 获取题库详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElRepo:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elRepoService.selectElRepoById(id));
    }

    /**
     * 新增题库
     */
    @PreAuthorize("@ss.hasPermi('exam:ElRepo:add')")
    @Log(title = "题库", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElRepo elRepo) {
        return toAjax(elRepoService.insertElRepo(elRepo));
    }

    /**
     * 修改题库
     */
    @PreAuthorize("@ss.hasPermi('exam:ElRepo:edit')")
    @Log(title = "题库", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElRepo elRepo) {
        return toAjax(elRepoService.updateElRepo(elRepo));
    }

    /**
     * 删除题库
     */
    @PreAuthorize("@ss.hasPermi('exam:ElRepo:remove')")
    @Log(title = "题库", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elRepoService.deleteElRepoByIds(ids));
    }
}
