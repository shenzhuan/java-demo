/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:IndexController.java
 * Date:2020/09/13 08:43:13
 */

package com.ruoyi.web.task;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ruoyi.common.annotation.UnAuth;
import com.ruoyi.common.constant.Rediskey;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.domain.entity.SysUser;
import com.ruoyi.common.core.redis.RedisCache;
import com.ruoyi.common.enums.StatusEnum;
import com.ruoyi.common.utils.http.HttpUtils;
import com.ruoyi.goods.domain.*;
import com.ruoyi.goods.service.IPmsCategoryService;
import com.ruoyi.goods.service.IPmsGoodsService;
import com.ruoyi.goods.service.IPmsTypeService;
import com.ruoyi.goods.service.IPmsViewGoodsService;
import com.ruoyi.luence.LuenceService;
import com.ruoyi.member.domain.UmsMember;
import com.ruoyi.member.service.IUmsMemberService;
import com.ruoyi.member.service.IUmsSimilarityService;
import com.ruoyi.security.SecurityUtils;
import com.ruoyi.sms.service.*;
import com.ruoyi.store.domain.TStoreInfo;
import com.ruoyi.store.service.ITStoreInfoService;
import com.ruoyi.store.vo.StoreBusiness;
import com.ruoyi.system.service.ISysNoticeService;
import com.ruoyi.system.service.ISysStoreUserService;
import io.jsonwebtoken.CompressionCodecs;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @Auther: shenzhuan
 * @Date: 2019/4/2 15:02
 * @Description:
 */

@Slf4j
@RestController
@Api(tags = "TestController", description = "home")
public class TestSynController extends BaseController {

    /**
     * 注入开店店铺信息service
     */
    @Autowired
    private ITStoreInfoService storeInfoService;


    @Resource
    private ISmsHomeNewProductService homeNewProductService;
    @Resource
    private ISmsHomeRecommendProductService homeRecommendProductService;
    @Resource
    private ISmsHomeBrandService homeBrandService;
    @Resource
    private ISmsHomeRecommendSubjectService homeRecommendSubjectService;
    @Resource
    private ISmsHomeAdvertiseService homeAdvertiseService;
    @Resource
    private ISysNoticeService sysNoticeService;
    @Resource
    private IPmsTypeService typeService;
    @Autowired
    private IPmsGoodsService pmsGoodsService;
    @Autowired
    private IPmsCategoryService pmsCategoryService;
    @Autowired
    private IPmsViewGoodsService viewGoodsService;
    @Autowired
    private IUmsSimilarityService similarityService;

    @Autowired
    private LuenceService luenceService;

    /**
     * 注入redis服务
     */
    @Autowired
    private RedisCache redisService;
    /**
     * 注入会员服务接口
     */
    @Autowired
    private IUmsMemberService customerService;
    /**
     * 会员服务接口
     */
    @Autowired
    private ISysStoreUserService storeUserService;

    /**
     * jwt密钥
     */
    @Value("${token.secret}")
    private String jwtSecretKey;

    public static void main(String[] args) {


        String url = "http://api.tbk.dingdanxia.com/pdd/recommend";
        String rspStr = HttpUtils.sendGet(url, "apikey=xBwytZV6u6JAgqSCXuPgkxPeJIBsPp08&&offset=100");
        JSONObject obj = JSONObject.parseObject(rspStr);

        JSONObject obj1 = JSONObject.parseObject(obj.get("data").toString());
        JSONArray region = obj1.getJSONArray("list");
        System.out.println(region.size());
        for (int i = 0; i < region.size(); i++) {
            String uu = "http://api.tbk.dingdanxia.com/pdd/goods_detail";
            String rspStr1 = HttpUtils.sendGet(uu, "apikey=xBwytZV6u6JAgqSCXuPgkxPeJIBsPp08&&goods_id_list=" + region.getJSONObject(i).getLong("goods_id"));
            JSONObject obj12 = JSONObject.parseObject(rspStr1);
            JSONObject obj11 = (JSONObject) obj12.getJSONArray("data").get(0);
            System.out.println(obj11);
            //System.out.println(region.getJSONObject(i).get("goods_name"));
            PmsGoods goods = new PmsGoods();
            goods.setSubtitle(obj11.get("goods_desc").toString());

            goods.setName(obj11.get("goods_name").toString());
            goods.setUrl(obj11.get("goods_thumbnail_url").toString());
            if (obj11.getJSONArray("video_urls") != null && obj11.getJSONArray("video_urls").size() > 0) {
                goods.setVideo(obj11.getJSONArray("video_urls").get(0).toString());
                goods.setVideoPic(goods.getUrl());
            }
            goods.setSale(0);
            goods.setHit(0);
            goods.setStatus("3");
            goods.setIsVirtual("0");
            goods.setShelvesStatus("1");
            goods.setStoreName(obj11.get("mall_name").toString());
            goods.setStoreId(obj11.getLong("mall_id"));

            goods.setId(obj11.getLong("goods_id"));
            //TODO
            goods.setFirstCateId(obj11.getJSONArray("cat_ids").getLong(0));
            goods.setSecondCateId(obj11.getJSONArray("cat_ids").getLong(1));
            goods.setThirdCateId(obj11.getJSONArray("cat_ids").getLong(2));
            goods.setBrandId(1L);
            goods.setTypeId(19L);
            //
            List<PmsGoodsImage> goodsImageList = new ArrayList<>();
            JSONArray goods_gallery_urls = obj11.getJSONArray("goods_gallery_urls");
            if (obj11.getJSONArray("goods_gallery_urls") != null && obj11.getJSONArray("goods_gallery_urls").size() > 0) {
                for (int j = 0; j < goods_gallery_urls.size(); j++) {
                    PmsGoodsImage goodsImage = new PmsGoodsImage();
                    goodsImage.setUrl(goods_gallery_urls.getString(j));
                    goodsImageList.add(goodsImage);
                }
            }
            goods.setSpuImages(goodsImageList);

            List<PmsGoodsServiceSupport> serviceSupports = new ArrayList<>();
            JSONArray service_tags = obj11.getJSONArray("service_tags");
            if (obj11.getJSONArray("service_tags") != null && obj11.getJSONArray("service_tags").size() > 0) {
                for (int j = 0; j < service_tags.size(); j++) {
                    PmsGoodsServiceSupport goodsImage = new PmsGoodsServiceSupport();
                    goodsImage.setId(service_tags.getLong(j));
                    serviceSupports.add(goodsImage);
                }
            }
            goods.setSpuServiceSupports(serviceSupports);

            goods.setPrice(obj11.getBigDecimal("mall_coupon_max_discount_amount"));
            goods.setCreateTime(new Date());
            goods.setRemark(obj11.get("sales_tip").toString());
            //  pmsGoodsService.insertOnlyGoods(goods);
        }
    }

    /**
     * banner
     *
     * @return
     */
    @UnAuth
    @GetMapping("/genToken")
    public Object genToken(Long id) {
        UmsMember customer = customerService.selectUmsMemberById(id);
        final StringBuilder sb = new StringBuilder();
        sb.append(Jwts.builder().setSubject(customer.getUsername())
                .compressWith(CompressionCodecs.DEFLATE)
                .signWith(SignatureAlgorithm.HS256, jwtSecretKey)
                .setIssuedAt(new Date())
                .claim("userName", customer.getUsername())
                .claim("nickName", customer.getNickname())
                .claim("releName", customer.getRelename())
                .claim("id", customer.getId())
                .setExpiration(Date.from(Instant.now().plus(1, ChronoUnit.HOURS))) // 有效期1小时
                .compact());
        if (customer != null) {
            redisService.putToRedis(String.format(Rediskey.TOKEN, sb.toString()), JSON.toJSONString(customer), 100, TimeUnit.DAYS);
        }
        return AjaxResult.success(sb.toString());
    }

    /**
     * 同步商品数据到luence
     */
    @UnAuth
    @GetMapping("/goodsIndex")
    public void createProductIndex() throws IOException {
        Long t = System.currentTimeMillis();
        log.debug("构建商品索引......start");
        PmsGoods goods = new PmsGoods();
        goods.setShelvesStatus("1");
        goods.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
        luenceService.createProductIndex(pmsGoodsService.selectPmsGoodsList(goods));
        log.debug("构建商品索引......end" + (System.currentTimeMillis() - t) / 1000 + "m");

    }

    @UnAuth
    @GetMapping("/synGoods")
    public void synGoods(int num) throws IOException {

        String url = "http://api.tbk.dingdanxia.com/pdd/recommend";
        String rspStr = HttpUtils.sendGet(url, "apikey=xBwytZV6u6JAgqSCXuPgkxPeJIBsPp08&&offset=" + num + "&&limit=50");
        JSONObject obj = JSONObject.parseObject(rspStr);

        JSONObject obj1 = JSONObject.parseObject(obj.get("data").toString());
        JSONArray region = obj1.getJSONArray("list");
        for (int i = 0; i < region.size(); i++) {
            try {
                String uu = "http://api.tbk.dingdanxia.com/pdd/goods_detail";
                String rspStr1 = HttpUtils.sendGet(uu, "apikey=xBwytZV6u6JAgqSCXuPgkxPeJIBsPp08&&goods_id_list=" + region.getJSONObject(i).getLong("goods_id"));
                JSONObject obj12 = JSONObject.parseObject(rspStr1);
                JSONObject obj11 = (JSONObject) obj12.getJSONArray("data").get(0);
                System.out.println(obj11);
                PmsGoods goods = new PmsGoods();
                goods.setSubtitle(obj11.get("goods_desc").toString());

                goods.setName(obj11.get("goods_name").toString());
                goods.setUrl(obj11.get("goods_thumbnail_url").toString());
                if (obj11.getJSONArray("video_urls") != null && obj11.getJSONArray("video_urls").size() > 0) {
                    goods.setVideo(obj11.getJSONArray("video_urls").get(0).toString());
                    goods.setVideoPic(goods.getUrl());
                }
                goods.setSale(0);
                goods.setHit(0);
                goods.setStatus("3");
                goods.setIsVirtual("0");
                goods.setShelvesStatus("1");
                goods.setId(obj11.getLong("goods_id"));
                goods.setStoreName(obj11.get("mall_name").toString());
                goods.setStoreId(obj11.getLong("mall_id"));
                // goods.setStoreId(0L);
                TStoreInfo exist = storeInfoService.selectTStoreInfoById(goods.getStoreId());
                if (exist == null) {
                    SysUser customer = new SysUser();
                    // 设置会员密码
                    customer.setPassword(SecurityUtils.encryptPassword("123456"));
                    customer.setUserName(goods.getId() + "");
                    customer.setNickName(goods.getStoreName());
                    storeUserService.insertUser(customer);
                    TStoreInfo info = storeInfoService.selectTStoreInfoById(18L);
                    info.setId(goods.getStoreId());
                    info.setStoreName(goods.getStoreName());
                    info.setCompanyName(goods.getStoreName());
                    info.setCompanyPhone(customer.getUserName());
                    StoreBusiness storeBusiness = new StoreBusiness();
                    storeBusiness.setStoreInfo(info);
                    storeBusiness.setMobile(customer.getUserName());
                    storeInfoService.addStore(storeBusiness);
                }

                goods.setLogisticsTemplateId(7L);

                //TODO
                goods.setFirstCateId(obj11.getJSONArray("cat_ids").getLong(0));
                goods.setSecondCateId(obj11.getJSONArray("cat_ids").getLong(1));
                goods.setThirdCateId(obj11.getJSONArray("cat_ids").getLong(2));
                goods.setBrandId(17L);
                goods.setTypeId(19L);
                //
                List<PmsSkuImage> skuImages = new ArrayList<>();
                List<PmsGoodsImage> goodsImageList = new ArrayList<>();
                JSONArray goods_gallery_urls = obj11.getJSONArray("goods_gallery_urls");
                if (obj11.getJSONArray("goods_gallery_urls") != null && obj11.getJSONArray("goods_gallery_urls").size() > 0) {
                    for (int j = 0; j < goods_gallery_urls.size(); j++) {
                        PmsGoodsImage goodsImage = new PmsGoodsImage();
                        goodsImage.setUrl(goods_gallery_urls.getString(j));
                        goodsImageList.add(goodsImage);
                        PmsSkuImage skuImage = new PmsSkuImage();
                        skuImage.setSpuId(goods.getId());
                        skuImage.setUrl(goods_gallery_urls.getString(j));
                        skuImages.add(skuImage);
                    }
                }
                goods.setSpuImages(goodsImageList);

                List<PmsGoodsServiceSupport> serviceSupports = new ArrayList<>();
                JSONArray service_tags = obj11.getJSONArray("service_tags");
                if (obj11.getJSONArray("service_tags") != null && obj11.getJSONArray("service_tags").size() > 0) {
                    for (int j = 0; j < service_tags.size(); j++) {
                        PmsGoodsServiceSupport goodsImage = new PmsGoodsServiceSupport();
                        goodsImage.setId(service_tags.getLong(j));
                        serviceSupports.add(goodsImage);
                    }
                }
                goods.setSpuServiceSupports(serviceSupports);

                goods.setPrice(obj11.getBigDecimal("min_normal_price"));
                goods.setCreateTime(new Date());
                goods.setRemark(obj11.get("sales_tip").toString());

                List<PmsSku> skus = new ArrayList<>();

                PmsSku sku = new PmsSku();
                sku.setName(goods.getName());
                sku.setPrice(goods.getPrice());
                sku.setUrl(goods.getUrl());
                sku.setStock(100);
                sku.setWeight(BigDecimal.ZERO);
                sku.setSkuNo(System.nanoTime() + "");
                sku.setRemark("通用规格");

                sku.setSkuImages(skuImages);
                // 0: {specId: 22, specValueId: "1612608053374220", valueRemark: "通用规格"}
                List<PmsSkuSpecValue> skuSpecValues = new ArrayList<>();
                PmsSkuSpecValue skuSpecValue = new PmsSkuSpecValue();
                skuSpecValue.setSpecValueId("1612608053374220");
                skuSpecValue.setSpecId(22L);
                skuSpecValue.setValueRemark("通用规格");
                skuSpecValues.add(skuSpecValue);
                sku.setSkuSpecValues(skuSpecValues);
                skus.add(sku);

                goods.setSkus(skus);

                goods.setSpuServiceSupports(serviceSupports);

                List<PmsGoodsSpecValue> specValueList = new ArrayList<>();
                PmsGoodsSpecValue specValue = new PmsGoodsSpecValue();
                // 0: {specId: 22, specValueId: "1612608053374220", valueRemark: "通用规格", url: null}
                specValue.setSpecValueId("1612608053374220");
                specValue.setSpecId(22L);
                specValue.setValueRemark("通用规格");
                specValueList.add(specValue);
                goods.setSpuSpecValues(specValueList);

                List<PmsGoodsAttributeValue> attributeValues = new ArrayList<>();
                PmsGoodsAttributeValue attributeValue = new PmsGoodsAttributeValue();
                // 0: {attributeId: "1612608070876190", attributeName: "通用属性", attributeValue: "通用属性",…}
                attributeValue.setAttributeId("1612608070876190");
                attributeValue.setAttributeName("通用属性");
                attributeValue.setAttributeValue("通用规格");
                attributeValue.setAttributeValueId("1612608070876190");
                attributeValues.add(attributeValue);
                goods.setSpuAttributeValues(attributeValues);
                pmsGoodsService.insertPmsGoods(goods);
            } catch (Exception e) {
                log.debug("ss");
                continue;
            }
        }




        /*String url ="http://apiv3.yangkeduo.com/operation/14/groups";
        String rspStr = HttpUtils.sendGet(url,"page=1&size=100&opt_type=1");
        JSONObject obj = JSONObject.parseObject(rspStr);
        JSONArray region = obj.getJSONArray("goods_list");
        for(int i=0;i<region.size();i++) {
            System.out.println(region.getJSONObject(i));
            //System.out.println(region.getJSONObject(i).get("goods_name"));
            PmsGoods goods = new PmsGoods();
            goods.setSubtitle(region.getJSONObject(i).get("short_name").toString());
            goods.setName(region.getJSONObject(i).get("goods_name").toString());
            goods.setUrl(region.getJSONObject(i).get("thumb_url").toString());
            goods.setSale(0);
            goods.setHit(0);
            goods.setStatus("3");
            goods.setIsVirtual("0");
            goods.setShelvesStatus("1");
            goods.setStoreName("平台自营");
            goods.setStoreId(0L);
            goods.setId(region.getJSONObject(i).getLong("goods_id"));
            //TODO
            goods.setFirstCateId(1L);
            goods.setSecondCateId(1L);
            goods.setThirdCateId(1L);
            goods.setBrandId(1L);
            goods.setTypeId(1L);
            //
            List<PmsGoodsImage> goodsImageList = new ArrayList<>();
                PmsGoodsImage goodsImage = new PmsGoodsImage();
                goodsImage.setUrl(goods.getUrl());
                goodsImageList.add(goodsImage);
            goods.setSpuImages(goodsImageList);

            goods.setPrice(region.getJSONObject(i).getBigDecimal("normal_price"));
            goods.setCreateTime(new Date());
            goods.setRemark(region.getJSONObject(i).get("sales_tip").toString());
            pmsGoodsService.insertOnlyGoods(goods);
        }*/

    }

    @UnAuth
    @GetMapping("/synGoodsCate")
    public void synGoodsCate() throws IOException {

        String url = "http://api.tbk.dingdanxia.com/pdd/cats";
        String rspStr = HttpUtils.sendGet(url, "apikey=xBwytZV6u6JAgqSCXuPgkxPeJIBsPp08&&parent_cat_id=0");
        JSONObject obj = JSONObject.parseObject(rspStr);

        JSONObject obj1 = JSONObject.parseObject(obj.get("data").toString());
        JSONArray region3 = obj1.getJSONArray("goods_cats_list");
        for (int i = 0; i < region3.size(); i++) {
            PmsCategory goods = new PmsCategory();
            goods.setGrade(region3.getJSONObject(i).getIntValue("level"));
            goods.setId(region3.getJSONObject(i).getLong("cat_id"));
            goods.setParentId(region3.getJSONObject(i).getLong("parent_cat_id"));
            goods.setName(region3.getJSONObject(i).get("cat_name").toString());
            goods.setCreateTime(new Date());
            goods.setCreateName("mojin");
            pmsCategoryService.addCategory(goods);
            url = "http://api.tbk.dingdanxia.com/pdd/cats";
            rspStr = HttpUtils.sendGet(url, "apikey=xBwytZV6u6JAgqSCXuPgkxPeJIBsPp08&&parent_cat_id=" + goods.getId());
            obj = JSONObject.parseObject(rspStr);
            System.out.println(goods.getName());
            obj1 = JSONObject.parseObject(obj.get("data").toString());
            JSONArray region2 = obj1.getJSONArray("goods_cats_list");
            if (region2 != null && region2.size() > 0) {
                for (int j = 0; j < region2.size(); j++) {
                    goods = new PmsCategory();
                    goods.setGrade(region2.getJSONObject(j).getIntValue("level"));
                    goods.setId(region2.getJSONObject(j).getLong("cat_id"));
                    goods.setParentId(region2.getJSONObject(j).getLong("parent_cat_id"));
                    goods.setName(region2.getJSONObject(j).get("cat_name").toString());
                    goods.setCreateTime(new Date());
                    goods.setCreateName("mojin");
                    pmsCategoryService.addCategory(goods);
                    url = "http://api.tbk.dingdanxia.com/pdd/cats";
                    rspStr = HttpUtils.sendGet(url, "apikey=xBwytZV6u6JAgqSCXuPgkxPeJIBsPp08&&parent_cat_id=" + goods.getId());
                    obj = JSONObject.parseObject(rspStr);

                    obj1 = JSONObject.parseObject(obj.get("data").toString());
                    JSONArray region = obj1.getJSONArray("goods_cats_list");
                    if (region != null && region.size() > 0) {
                        for (int k = 0; k < region.size(); k++) {
                            goods = new PmsCategory();
                            goods.setGrade(region.getJSONObject(k).getIntValue("level"));
                            goods.setId(region.getJSONObject(k).getLong("cat_id"));
                            goods.setParentId(region.getJSONObject(k).getLong("parent_cat_id"));
                            goods.setName(region.getJSONObject(k).get("cat_name").toString());
                            goods.setCreateTime(new Date());
                            goods.setRate(BigDecimal.ONE);
                            goods.setCreateName("mojin");
                            goods.setTypeId(19L);
                            List<PmsCategorySpec> list = new ArrayList<>();
                            PmsCategorySpec spec = new PmsCategorySpec();
                            spec.setSpecId(22L);
                            list.add(spec);
                            goods.setCateSpecs(list);

                            pmsCategoryService.addCategory(goods);


                        }
                    }
                }
            }


        }
    }
}
