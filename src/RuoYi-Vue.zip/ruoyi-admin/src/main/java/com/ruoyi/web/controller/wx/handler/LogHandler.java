package com.ruoyi.web.controller.wx.handler;


import com.ruoyi.common.utils.JSONUtils;
import com.ruoyi.wx.domain.WxMsg;
import com.ruoyi.wx.service.IWxMsgService;
import me.chanjar.weixin.common.session.WxSessionManager;
import me.chanjar.weixin.mp.api.WxMpService;
import me.chanjar.weixin.mp.bean.message.WxMpXmlMessage;
import me.chanjar.weixin.mp.bean.message.WxMpXmlOutMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @author Binary Wang
 */
@Component
public class LogHandler extends AbstractHandler {
    @Autowired
    IWxMsgService wxMsgService;

    @Override
    public WxMpXmlOutMessage handle(WxMpXmlMessage wxMessage,
                                    Map<String, Object> context, WxMpService wxMpService,
                                    WxSessionManager sessionManager) {
        try {
            this.logger.debug("\n接收到请求消息，内容：{}", JSONUtils.toJson(wxMessage));
            wxMsgService.insertWxMsg(new WxMsg(wxMessage));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

}
