/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:TAppletPageVisitController.java
 * Date:2021/01/09 11:40:09
 */

package com.ruoyi.web.controller.sms;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.sms.domain.TAppletPageVisit;
import com.ruoyi.sms.service.ITAppletPageVisitService;
import com.ruoyi.util.CommonConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 【请填写功能名称】Controller
 *
 * @author é­éåå
 * @date 2021-01-08
 */
@RestController
@RequestMapping("/sms/TAppletPageVisit")
public class TAppletPageVisitController extends BaseController {
    @Autowired
    private ITAppletPageVisitService tAppletPageVisitService;

    /**
     * 查询【请填写功能名称】列表
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletPageVisit:list')")
    @GetMapping("/list")
    public TableDataInfo list(TAppletPageVisit tAppletPageVisit) {
        tAppletPageVisit.setStoreId(CommonConstant.ADMIN_STOREID);
        startPage();
        List<TAppletPageVisit> list = tAppletPageVisitService.selectTAppletPageVisitList(tAppletPageVisit);
        return getDataTable(list);
    }

    /**
     * 导出【请填写功能名称】列表
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletPageVisit:export')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(TAppletPageVisit tAppletPageVisit) {
        List<TAppletPageVisit> list = tAppletPageVisitService.selectTAppletPageVisitList(tAppletPageVisit);
        ExcelUtil<TAppletPageVisit> util = new ExcelUtil<TAppletPageVisit>(TAppletPageVisit.class);
        return util.exportExcel(list, "TAppletPageVisit");
    }

    /**
     * 获取【请填写功能名称】详细信息
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletPageVisit:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(tAppletPageVisitService.selectTAppletPageVisitById(id));
    }

    /**
     * 新增【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletPageVisit:add')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TAppletPageVisit tAppletPageVisit) {
        return toAjax(tAppletPageVisitService.insertTAppletPageVisit(tAppletPageVisit));
    }

    /**
     * 修改【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletPageVisit:edit')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TAppletPageVisit tAppletPageVisit) {
        return toAjax(tAppletPageVisitService.updateTAppletPageVisit(tAppletPageVisit));
    }

    /**
     * 删除【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletPageVisit:remove')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(tAppletPageVisitService.deleteTAppletPageVisitByIds(ids));
    }
}
