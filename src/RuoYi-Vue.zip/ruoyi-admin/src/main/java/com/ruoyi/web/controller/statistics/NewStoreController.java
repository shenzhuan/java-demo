/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:NewStoreController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.statistics;


import com.ruoyi.statistics.service.StatisticsServiceApi;
import com.ruoyi.store.domain.TStoreInfo;
import com.ruoyi.store.service.ITStoreInfoService;
import com.ruoyi.store.vo.NewStoreInfoStatistics;
import com.ruoyi.util.BaseResponse;
import com.ruoyi.util.PageHelper;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author 魔金 2123957932
 * @date 2019-06-25 09:27
 * <p>
 * 新增店铺统计控制器
 */
@RestController
@Api(description = "新增店铺统计接口")
public class NewStoreController {


    /**
     * 注入统计服务
     */
    @Autowired
    private StatisticsServiceApi statisticsServiceApi;


    /**
     * 注入店铺信息服务接口
     */
    @Autowired
    private ITStoreInfoService storeInfoService;

    /**
     * 分页查询新增店铺统计
     *
     * @param pageHelper 分页帮助类
     * @param startTime  开始时间
     * @param endTime    结束时间
     * @return 返回新增店铺统计（带分页）
     */
    @GetMapping("/newstore/statistics")
    @ApiOperation(value = "分页查询新增店铺统计", notes = "分页查询新增店铺统计（需要认证）")
    @PreAuthorize("hasAuthority('newstore/querynewstoreinfostatisticswithpage')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回新增店铺统计（带分页）", response = NewStoreInfoStatistics.class)
    })
    public BaseResponse queryNewStoreInfoStatisticsWithPage(@ApiIgnore PageHelper<NewStoreInfoStatistics> pageHelper, String startTime, String endTime) {
        return BaseResponse.build(statisticsServiceApi.queryNewStoreInfoStatisticsWithPage(pageHelper, startTime, endTime));
    }


    /**
     * 查询新增店铺统计
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return 返回新增店铺统计
     */
    @GetMapping("/newstore")
    @ApiOperation(value = "查询新增店铺统计", notes = "查询新增店铺统计（需要认证）")
    @PreAuthorize("hasAuthority('newstore/querynewstoreinfostatistics')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回新增店铺统计", response = NewStoreInfoStatistics.class)
    })
    public java.util.List<NewStoreInfoStatistics> queryNewStoreInfoStatistics(String startTime, String endTime) {
        return statisticsServiceApi.queryNewStoreInfoStatistics(startTime, endTime);
    }


    /**
     * 查询新增店铺信息
     *
     * @param pageHelper 分页帮助类
     * @param createTime 创建时间
     * @return 返回新增店铺信息
     */
    @GetMapping("/newstore/new")
    @ApiOperation(value = "查询新增店铺信息", notes = "查询新增店铺信息（需要认证）")
    @PreAuthorize("hasAuthority('newstore/querynewstoreinfo')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "createTime", value = "创建时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回新增店铺信息", response = TStoreInfo.class)
    })
    public BaseResponse queryNewStoreInfo(@ApiIgnore PageHelper<TStoreInfo> pageHelper, String createTime) {
        return BaseResponse.build(storeInfoService.queryStoreInfoForAuditList(pageHelper, "2", null, null, createTime, null, -1));
    }

}
