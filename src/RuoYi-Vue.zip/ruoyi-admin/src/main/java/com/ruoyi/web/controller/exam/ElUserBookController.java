package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElUserBook;
import com.ruoyi.exam.service.IElUserBookService;
import com.ruoyi.exam.vo.BaseIdRespDTO;
import com.ruoyi.web.utils.AdminLoginUtils;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 错题本Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElUserBook")
public class ElUserBookController extends BaseController {
    @Autowired
    private IElUserBookService elUserBookService;

    /**
     * 查询错题本列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserBook:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElUserBook elUserBook) {
        startPage();
        List<ElUserBook> list = elUserBookService.selectElUserBookList(elUserBook);
        return getDataTable(list);
    }

    /**
     * 查找列表，每次最多返回200条数据
     *
     * @param reqDTO
     * @return
     */
    @ApiOperation(value = "查找列表")
    @RequestMapping(value = "/next", method = {RequestMethod.GET})
    public AjaxResult nextQu(ElUserBook reqDTO) {
        //转换并返回
        Long quId = elUserBookService.findNext(reqDTO.getExamId(), reqDTO.getQuId(), AdminLoginUtils.getInstance().getManagerId());
        return AjaxResult.success(new BaseIdRespDTO(quId));
    }

    /**
     * 导出错题本列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserBook:export')")
    @Log(title = "错题本", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElUserBook elUserBook) {
        List<ElUserBook> list = elUserBookService.selectElUserBookList(elUserBook);
        ExcelUtil<ElUserBook> util = new ExcelUtil<ElUserBook>(ElUserBook.class);
        return util.exportExcel(list, "ElUserBook");
    }

    /**
     * 获取错题本详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserBook:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elUserBookService.selectElUserBookById(id));
    }

    /**
     * 新增错题本
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserBook:add')")
    @Log(title = "错题本", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElUserBook elUserBook) {
        return toAjax(elUserBookService.insertElUserBook(elUserBook));
    }

    /**
     * 修改错题本
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserBook:edit')")
    @Log(title = "错题本", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElUserBook elUserBook) {
        return toAjax(elUserBookService.updateElUserBook(elUserBook));
    }

    /**
     * 删除错题本
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserBook:remove')")
    @Log(title = "错题本", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elUserBookService.deleteElUserBookByIds(ids));
    }
}
