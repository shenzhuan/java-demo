package com.ruoyi.web.controller.wx;


import com.baomidou.mybatisplus.extension.api.R;
import com.ruoyi.wx.domain.WxUser;
import com.ruoyi.wx.form.WxUserTaggingForm;
import com.ruoyi.wx.service.IWxUserService;
import com.ruoyi.wx.service.IWxUserTagsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import me.chanjar.weixin.common.error.WxError;
import me.chanjar.weixin.common.error.WxErrorException;
import me.chanjar.weixin.mp.api.WxMpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 粉丝标签
 */
@RestController
@RequestMapping("/wxUserTags")
@RequiredArgsConstructor
@Api(tags = {"粉丝标签"})
public class WxUserTagsController {
    private final WxMpService wxMpService;
    @Autowired
    IWxUserTagsService wxUserTagsService;
    @Autowired
    IWxUserService wxUserService;

    @GetMapping("/userTags")
    @ApiOperation(value = "当前用户的标签")
    public R userTags(@CookieValue String appid, @CookieValue String openid) {
        if (openid == null) {
            return R.failed("none_openid");
        }
        this.wxMpService.switchoverTo(appid);
        WxUser wxUser = wxUserService.selectWxUserById(openid);
        if (wxUser == null) {
            wxUser = wxUserService.refreshUserInfo(openid, appid);
            if (wxUser == null) {
                return R.failed("not_subscribed");
            }
        }
        return R.ok(wxUser.getTagidList());
    }

    @PostMapping("/tagging")
    @ApiOperation(value = "给用户绑定标签")
    public R tagging(@CookieValue String appid, @CookieValue String openid, @RequestBody WxUserTaggingForm form) {
        this.wxMpService.switchoverTo(appid);
        try {
            wxUserTagsService.tagging(form.getTagid(), openid);
        } catch (WxErrorException e) {
            WxError error = e.getError();
            if (50005 == error.getErrorCode()) {//未关注公众号
                return R.failed("not_subscribed");
            } else {
                return R.failed(error.getErrorMsg());
            }
        }
        return R.ok(null);
    }

    @PostMapping("/untagging")
    @ApiOperation(value = "解绑标签")
    public R untagging(@CookieValue String appid, @CookieValue String openid, @RequestBody WxUserTaggingForm form) throws WxErrorException {
        this.wxMpService.switchoverTo(appid);
        wxUserTagsService.untagging(form.getTagid(), openid);
        return R.ok(null);
    }
}
