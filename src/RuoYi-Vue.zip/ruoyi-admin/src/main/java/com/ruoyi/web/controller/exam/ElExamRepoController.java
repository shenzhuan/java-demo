package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElExamRepo;
import com.ruoyi.exam.service.IElExamRepoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 考试题库Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElExamRepo")
public class ElExamRepoController extends BaseController {
    @Autowired
    private IElExamRepoService elExamRepoService;

    /**
     * 查询考试题库列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExamRepo:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElExamRepo elExamRepo) {
        startPage();
        List<ElExamRepo> list = elExamRepoService.selectElExamRepoList(elExamRepo);
        return getDataTable(list);
    }

    /**
     * 导出考试题库列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExamRepo:export')")
    @Log(title = "考试题库", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElExamRepo elExamRepo) {
        List<ElExamRepo> list = elExamRepoService.selectElExamRepoList(elExamRepo);
        ExcelUtil<ElExamRepo> util = new ExcelUtil<ElExamRepo>(ElExamRepo.class);
        return util.exportExcel(list, "ElExamRepo");
    }

    /**
     * 获取考试题库详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExamRepo:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elExamRepoService.selectElExamRepoById(id));
    }

    /**
     * 新增考试题库
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExamRepo:add')")
    @Log(title = "考试题库", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElExamRepo elExamRepo) {
        return toAjax(elExamRepoService.insertElExamRepo(elExamRepo));
    }

    /**
     * 修改考试题库
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExamRepo:edit')")
    @Log(title = "考试题库", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElExamRepo elExamRepo) {
        return toAjax(elExamRepoService.updateElExamRepo(elExamRepo));
    }

    /**
     * 删除考试题库
     */
    @PreAuthorize("@ss.hasPermi('exam:ElExamRepo:remove')")
    @Log(title = "考试题库", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elExamRepoService.deleteElExamRepoByIds(ids));
    }
}
