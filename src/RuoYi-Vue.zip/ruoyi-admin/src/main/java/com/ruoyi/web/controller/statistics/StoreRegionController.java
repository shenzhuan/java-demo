/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:StoreRegionController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.statistics;


import com.ruoyi.statistics.service.StatisticsServiceApi;
import com.ruoyi.store.domain.TStoreInfo;
import com.ruoyi.store.service.ITStoreInfoService;
import com.ruoyi.store.vo.StoreInfoAreaStatistics;
import com.ruoyi.util.BaseResponse;
import com.ruoyi.util.PageHelper;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author 魔金 2123957932
 * @date 2019-06-25 13:25
 * <p>
 * 店铺地区统计控制器
 */
@RestController
@Api(description = "店铺地区统计接口")
public class StoreRegionController {


    /**
     * 注入统计服务
     */
    @Autowired
    private StatisticsServiceApi statisticsServiceApi;

    /**
     * 注入店铺信息服务接口
     */
    @Autowired
    private ITStoreInfoService storeInfoService;


    /**
     * 查询店铺地区统计
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return 返回店铺地区统计
     */
    @GetMapping("/storeregion/statistics")
    @ApiOperation(value = "查询店铺地区统计", notes = "查询店铺地区统计（需要认证）")
    @PreAuthorize("hasAuthority('storeregion/querystoreinfoareastatistics')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回店铺地区统计", response = StoreInfoAreaStatistics.class)
    })
    public java.util.List<StoreInfoAreaStatistics> queryStoreInfoAreaStatistics(String startTime, String endTime) {
        return statisticsServiceApi.queryStoreInfoAreaStatistics(startTime, endTime);
    }


    /**
     * 查询地区店铺信息
     *
     * @param pageHelper 分页帮助类
     * @param provinceId 省份id
     * @return 返回地区店铺信息
     */
    @GetMapping("/storeregion")
    @ApiOperation(value = "查询地区店铺信息", notes = "查询地区店铺信息（需要认证）")
    @PreAuthorize("hasAuthority('storeregion/queryareastoreinfo')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "provinceId", value = "省份id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回地区店铺信息", response = TStoreInfo.class)
    })
    public BaseResponse queryAreaStoreInfo(@ApiIgnore PageHelper<TStoreInfo> pageHelper, long provinceId) {
        return BaseResponse.build(storeInfoService.queryStoreInfoForAuditList(pageHelper, "2", null, null, null, null, provinceId));
    }


}
