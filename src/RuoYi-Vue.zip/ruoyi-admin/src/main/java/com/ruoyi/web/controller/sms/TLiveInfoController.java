/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:TLiveInfoController.java
 * Date:2021/01/09 11:40:09
 */

package com.ruoyi.web.controller.sms;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.sms.domain.TLiveInfo;
import com.ruoyi.sms.service.ITLiveInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 直播数据Controller
 *
 * @author 魔金
 * @date 2020-11-01
 */
@RestController
@RequestMapping("/sms/TLiveInfo")
public class TLiveInfoController extends BaseController {
    @Autowired
    private ITLiveInfoService tLiveInfoService;

    /**
     * 查询直播数据列表
     */
    @PreAuthorize("@ss.hasPermi('sms:TLiveInfo:list')")
    @GetMapping("/list")
    public TableDataInfo list(TLiveInfo tLiveInfo) {
        startPage();
        List<TLiveInfo> list = tLiveInfoService.selectTLiveInfoList(tLiveInfo);
        return getDataTable(list);
    }

    /**
     * 导出直播数据列表
     */
    @PreAuthorize("@ss.hasPermi('sms:TLiveInfo:export')")
    @Log(title = "直播数据", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(TLiveInfo tLiveInfo) {
        List<TLiveInfo> list = tLiveInfoService.selectTLiveInfoList(tLiveInfo);
        ExcelUtil<TLiveInfo> util = new ExcelUtil<TLiveInfo>(TLiveInfo.class);
        return util.exportExcel(list, "TLiveInfo");
    }

    /**
     * 获取直播数据详细信息
     */
    @PreAuthorize("@ss.hasPermi('sms:TLiveInfo:query')")
    @GetMapping(value = "/{roomid}")
    public AjaxResult getInfo(@PathVariable("roomid") Long roomid) {
        return AjaxResult.success(tLiveInfoService.selectTLiveInfoById(roomid));
    }

    /**
     * 新增直播数据
     */
    @PreAuthorize("@ss.hasPermi('sms:TLiveInfo:add')")
    @Log(title = "直播数据", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TLiveInfo tLiveInfo) {
        return toAjax(tLiveInfoService.insertTLiveInfo(tLiveInfo));
    }

    /**
     * 修改直播数据
     */
    @PreAuthorize("@ss.hasPermi('sms:TLiveInfo:edit')")
    @Log(title = "直播数据", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TLiveInfo tLiveInfo) {
        return toAjax(tLiveInfoService.updateTLiveInfo(tLiveInfo));
    }

    /**
     * 删除直播数据
     */
    @PreAuthorize("@ss.hasPermi('sms:TLiveInfo:remove')")
    @Log(title = "直播数据", businessType = BusinessType.DELETE)
    @DeleteMapping("/{roomids}")
    public AjaxResult remove(@PathVariable Long[] roomids) {
        return toAjax(tLiveInfoService.deleteTLiveInfoByIds(roomids));
    }
}
