/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:CouponController.java
 * Date:2020/09/13 08:43:13
 */

package com.ruoyi.web.controller.marketing;


import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.marketing.domain.Coupon;
import com.ruoyi.marketing.domain.CouponDetails;
import com.ruoyi.marketing.domain.SmsCouponSendRecord;
import com.ruoyi.marketing.service.CouponService;
import com.ruoyi.marketing.service.ISmsCouponSendRecordService;
import com.ruoyi.member.domain.UmsMember;
import com.ruoyi.member.service.IUmsMemberService;
import com.ruoyi.util.BaseResponse;
import com.ruoyi.util.CommonConstant;
import com.ruoyi.util.PageHelper;
import com.ruoyi.wx.TaskExcutor;
import com.ruoyi.wx.domain.WxUser;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import me.chanjar.weixin.common.error.WxErrorException;
import me.chanjar.weixin.mp.bean.result.WxMpUser;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by 魔金商城平台管理on 2019/7/5.
 * 优惠券控制器
 */
@Slf4j
@RestController
@Api("优惠券接口")
public class CouponController {


    /**
     * 注入优惠券service
     */
    @Autowired
    private CouponService couponService;
    @Autowired
    private IUmsMemberService memberService;
    @Autowired
    private ISmsCouponSendRecordService couponSendRecordService;

    /**
     * 分页查询优惠券
     *
     * @param pageHelper 分页帮助类
     * @param name       查询条件,优惠券名称
     * @return 优惠券集合
     */
    @GetMapping("/coupon")
    @ApiOperation(value = "查询优惠券", notes = "查询优惠券（需要认证）")
    @PreAuthorize("@ss.hasPermi('marketingcoupon')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "name", value = "优惠券名称"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "优惠券集合", response = Coupon.class)
    })
    public BaseResponse queryCoupon(@ApiIgnore PageHelper<Coupon> pageHelper, String name) {
        return BaseResponse.build(couponService.queryCoupon(pageHelper, name, CommonConstant.ADMIN_STOREID));
    }


    /**
     * 复制优惠券链接
     *
     * @param couponId 优惠券id
     * @return -1:没有查询到该优惠券, 0:优惠券已过期, 其他字符串为优惠券链接
     */
    @GetMapping("/copycoupon/{couponId}")
    @ApiOperation(value = "复制优惠券链接", notes = "复制优惠券链接（需要认证）")
    @PreAuthorize("@ss.hasPermi('marketingcoupon')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", dataType = "long", name = "couponId", value = "优惠券id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "-1:没有查询到该优惠券, 0:优惠券已过期, 其他字符串为优惠券链接", response = String.class)
    })
    public String copyCoupon(@PathVariable long couponId) {
        return couponService.copyCoupon(couponId, CommonConstant.ADMIN_STOREID);
    }

    /**
     * 导出优惠券
     *
     * @param couponId 优惠券id
     */
    @PostMapping("/exportcoupon/{couponId}")
    @ApiOperation(value = "导出优惠券", notes = "导出优惠券（需要认证）")
    @PreAuthorize("@ss.hasPermi('marketingcoupon')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", dataType = "long", name = "couponId", value = "优惠券id"),
    })
    public void exportCoupon(@PathVariable long couponId, HttpServletResponse response) throws IOException {
        /*OutputStream os = response.getOutputStream();
        Exc.exportExcel(response, String.valueOf(couponId).concat("优惠券券码.xls"), () ->
                couponService.exportCoupon(os, CommonConstant.ADMIN_STOREID, couponId)
        );*/

    }

    /**
     * 删除优惠券
     *
     * @param ids 优惠券ids数组
     * @return 删除返回码 -1失败 >=1成功
     */
    @DeleteMapping("/coupon")
    @ApiOperation(value = "删除优惠券", notes = "删除优惠券（需要认证）")
    @PreAuthorize("@ss.hasPermi('marketingcoupon')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "array", name = "ids", value = "优惠券ids数组"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "删除返回码 -1失败 >=1成功", response = Integer.class)
    })
    public int deleteCoupon(long[] ids) {
        return couponService.deleteCoupon(ids, CommonConstant.ADMIN_STOREID);
    }

    /**
     * 添加优惠券
     *
     * @param coupon 优惠券实体类
     * @return 添加返回码 -1 失败 -2 限领张数不正确 -3 限领张数不能大于总张数 >=1 成功
     */
    @PostMapping("/coupon")
    @ApiOperation(value = "添加优惠券", notes = "添加优惠券（需要认证）")
    @PreAuthorize("@ss.hasPermi('marketingcoupon')")
    @ApiResponses({
            @ApiResponse(code = 200, message = "添加返回码 -1 失败 -2 限领张数不正确 -3 限领张数不能大于总张数 >=1 成功", response = Integer.class)
    })
    public int addCoupon(@RequestBody Coupon coupon) {
        return couponService.addCoupon(coupon, CommonConstant.ADMIN_STOREID);
    }


    /**
     * 查询优惠券详情
     *
     * @param couponId 优惠券id
     * @return 优惠券详情实体类
     */
    @GetMapping("/coupon/{couponId}")
    @ApiOperation(value = "查询优惠券详情", notes = "查询优惠券详情（需要认证）")
    @PreAuthorize("@ss.hasPermi('marketingcoupon')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", dataType = "long", name = "couponId", value = "优惠券id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "优惠券详情实体", response = CouponDetails.class)
    })
    public CouponDetails queryCouponDetails(@PathVariable long couponId) {
        return couponService.queryCouponDetails(CommonConstant.ADMIN_STOREID, couponId);
    }


    @RequestMapping(value = "/sendCoupon")
    @ResponseBody
    @ApiOperation(value = "领取优惠券", notes = "领取优惠券（需要认证）", httpMethod = "POST")
    public AjaxResult receiveCoupon(@RequestBody UmsMember member) {

        Long t = System.currentTimeMillis();
        Long couponId = member.getId();
        member.setId(null);
        List<UmsMember> list = memberService.selectUmsMemberList(member);
        int start = 0, batchSize = list.size(), end = Math.min(100, batchSize);
        final String batch = list.get(0).getSelfRecommendCode().substring(5);//截取首个openid的一部分做批次号（打印日志时使用，无实际意义）
        log.info("开始处理批次：{}，批次数量：{}", batch, batchSize);
        try {
            while (start < end && end <= batchSize) {//分批处理,每次最多拉取100个用户信息
                final int finalStart = start, finalEnd = end;
                final List<UmsMember> subOpenids = list.subList(finalStart, finalEnd);
                TaskExcutor.submit(() -> {//使用线程池同步数据，否则大量粉丝数据需同步时会很慢
                    log.info("同步批次:【{}--{}-{}】，数量：{}", batch, finalStart, finalEnd, subOpenids.size());
                    SmsCouponSendRecord sendRecord = new SmsCouponSendRecord();
                    sendRecord.setCouponId(couponId);
                    sendRecord.setCreateTime(new Date());
                    StringBuilder sbing = new StringBuilder();
                    StringBuilder sbed = new StringBuilder();

                        for (UmsMember umsMember : subOpenids) {
                            sbing.append(umsMember.getId() + ",");
                        }
                        sendRecord.setSendingIds(sbing.toString());
                        int result = 0;
                        for (UmsMember umsMember : subOpenids) {
                            result = couponService.receiveCoupon(umsMember.getId(), couponId, 1);
                            if (result == 1) {
                                sbed.append(umsMember.getId() + ",");
                            } else {
                                // -1：参数不全 -2：活动已过期 -3：优惠券已领完 -4：用户领取的优惠券已达上限 -5优惠券已失效(删除状态) -6 系统繁忙，请重试
                                if (result == -2) {
                                    sendRecord.setSendedIds(sbed.toString());
                                    sendRecord.setRemark("耗时：" + (System.currentTimeMillis() - t) / 1000 + "秒;活动已过期");
                                    couponSendRecordService.insertSmsCouponSendRecord(sendRecord);
                                    break;
                                }
                                if (result == -5) {
                                    sendRecord.setSendedIds(sbed.toString());
                                    sendRecord.setRemark("耗时：" + (System.currentTimeMillis() - t) / 1000 + "秒;优惠券已失效");
                                    couponSendRecordService.insertSmsCouponSendRecord(sendRecord);
                                    break;
                                }
                                if (result == -3) {
                                    sendRecord.setSendedIds(sbed.toString());
                                    sendRecord.setRemark("耗时：" + (System.currentTimeMillis() - t) / 1000 + "秒;优惠券已领完，要发送：" + sbing.toString().split(",").length + ",实际发送用户：" + (sbed.toString().split(",").length - 1));
                                    couponSendRecordService.insertSmsCouponSendRecord(sendRecord);
                                    break;
                                }
                                if (result == -4) {
                                    sendRecord.setRemark(sendRecord.getRemark() + umsMember.getId() + "已达上限;");
                                }
                            }
                        }
                        if ((result != -5 && result != -2 && result != -3)) {
                            sendRecord.setRemark(sendRecord.getRemark() + ";耗时：" + (System.currentTimeMillis() - t) / 1000 + "秒;要发送：" + sbing.toString().split(",").length + ",实际发送用户：" + sbed.toString().split(",").length);
                            sendRecord.setRemark(sendRecord.getRemark().replaceAll("null", ""));
                            sendRecord.setSendedIds(sbed.toString());
                            couponSendRecordService.insertSmsCouponSendRecord(sendRecord);
                        }
                });
                start = end;
                end = Math.min(end + 100, list.size());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        log.info("批次：{}处理完成", batch);

        return AjaxResult.success();
    }
}
