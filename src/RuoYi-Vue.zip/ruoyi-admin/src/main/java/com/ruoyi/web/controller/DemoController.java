/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:DemoController.java
 * Date:2021/01/09 11:40:09
 */

package com.ruoyi.web.controller;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.WechatAppletDataUtils;
import com.ruoyi.common.utils.WechatParam;
import com.ruoyi.common.utils.bean.WechatSetting;
import com.ruoyi.setting.bean.WechatPaySet;
import com.ruoyi.setting.service.ILsPaySettingService;
import com.ruoyi.sms.domain.TAppletPageVisit;
import com.ruoyi.sms.domain.TAppletVisit;
import com.ruoyi.sms.domain.TAppletVisitStatic;
import com.ruoyi.sms.service.ITAppletPageVisitService;
import com.ruoyi.sms.service.ITAppletVisitService;
import com.ruoyi.sms.service.ITAppletVisitStaticService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * Created by 魔金商城 on 2020/3/18.
 * pc首页模版
 */
@Slf4j
@RestController
@Api(description = "pc首页模版接口")
@RequestMapping("/test")
public class DemoController {

    @Autowired
    private ITAppletVisitService appletVisitService;
    @Autowired
    private ITAppletPageVisitService appletPageVisitService;
    @Autowired
    private ITAppletVisitStaticService appletVisitStaticService;
    @Autowired
    private ILsPaySettingService paySettingService;

    @GetMapping("/t3")
    public void t3() {

        WechatPaySet wechatAppletPaySet = paySettingService.queryPaySet(0).getWechatAppletPaySet();
        WechatSetting wechatSetting = new WechatSetting();
        wechatSetting.setAppId(wechatAppletPaySet.getAppId());
        wechatSetting.setAppSecret(wechatAppletPaySet.getAppSecret());

        WechatParam param = new WechatParam();

        String yesterday = DateUtils.parseDateToStr("yyyyMMdd", DateUtils.addDays(new Date(), -1));
        param.setBegin_date(yesterday);
        param.setEnd_date(yesterday);

        String json = WechatAppletDataUtils.getDailyRetain(wechatSetting, param);
        TAppletVisit visit = new TAppletVisit();
        visit.setStoreId(0L);
        visit.setCreateTime(new Date());
        JSONObject object = JSONObject.parseObject(json);
        JSONArray array = JSONArray.parseArray(object.get("visit_uv_new").toString());
        JSONObject visit_uv_new = JSONObject.parseObject(array.get(0).toString());
        visit.setDate(object.get("ref_date").toString());
        visit.setVisitUvNew(visit_uv_new.getInteger("value"));

        JSONArray array1 = JSONArray.parseArray(object.get("visit_uv").toString());
        JSONObject visit_uv = JSONObject.parseObject(array1.get(0).toString());
        visit.setVisitUv(visit_uv.getInteger("value"));

        String json1 = WechatAppletDataUtils.getDailyVisitTrend(wechatSetting, param);
        JSONObject object1 = JSONObject.parseObject(json1);
        JSONArray array11 = JSONArray.parseArray(object1.get("list").toString());

        visit.setSessionCnt(array11.getJSONObject(0).getInteger("session_cnt"));
        visit.setVisitPv(array11.getJSONObject(0).getInteger("visit_pv"));
        visit.setVisitUvAdd(array11.getJSONObject(0).getInteger("visit_uv"));
        visit.setVisitUvNewAdd(array11.getJSONObject(0).getInteger("visit_uv_new"));
        visit.setStayTimeUv(array11.getJSONObject(0).getBigDecimal("stay_time_uv"));
        visit.setStayTimeSession(array11.getJSONObject(0).getBigDecimal("stay_time_session"));
        visit.setVisitDepth(array11.getJSONObject(0).getBigDecimal("visit_depth"));

        String json2 = WechatAppletDataUtils.getDailySummary(wechatSetting, param);
        JSONObject object2 = JSONObject.parseObject(json2);
        JSONArray array22 = JSONArray.parseArray(object2.get("list").toString());

        visit.setVisitTotal(array22.getJSONObject(0).getInteger("visit_total"));
        visit.setSharePv(array22.getJSONObject(0).getInteger("share_pv"));
        visit.setShareUv(array22.getJSONObject(0).getInteger("share_uv"));

        appletVisitService.insertTAppletVisit(visit);
    }

    @GetMapping("/t2")
    public void t2() {
        log.debug("getUserPortrait2......start");
        WechatPaySet wechatAppletPaySet = paySettingService.queryPaySet(0).getWechatAppletPaySet();
        WechatSetting wechatSetting = new WechatSetting();
        wechatSetting.setAppId(wechatAppletPaySet.getAppId());
        wechatSetting.setAppSecret(wechatAppletPaySet.getAppSecret());
        WechatParam param = new WechatParam();
        String yesterday = DateUtils.parseDateToStr("yyyyMMdd", DateUtils.addDays(new Date(), -1));
        param.setBegin_date(yesterday);
        param.setEnd_date(yesterday);
        String json = WechatAppletDataUtils.getUserPortrait(wechatSetting, param);
        JSONObject object = JSONObject.parseObject(json);
        JSONObject visit_uv_new = JSONObject.parseObject(object.get("visit_uv").toString());
        JSONArray platforms = JSONArray.parseArray(visit_uv_new.get("platforms").toString());
        for (int i = 0; i < platforms.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(platforms.getJSONObject(i).getLong("id"));
            pageVisit.setName(platforms.getJSONObject(i).get("name").toString());
            pageVisit.setValue(platforms.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("14");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray devices = JSONArray.parseArray(visit_uv_new.get("devices").toString());
        for (int i = 0; i < devices.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(devices.getJSONObject(i).getLong("value"));
            pageVisit.setName(devices.getJSONObject(i).get("name").toString());
            pageVisit.setValue(devices.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("15");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray ages = JSONArray.parseArray(visit_uv_new.get("ages").toString());
        for (int i = 0; i < ages.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(ages.getJSONObject(i).getLong("id"));
            pageVisit.setName(ages.getJSONObject(i).get("name").toString());
            pageVisit.setValue(ages.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("16");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray genders = JSONArray.parseArray(visit_uv_new.get("genders").toString());
        for (int i = 0; i < genders.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(genders.getJSONObject(i).getLong("id"));
            pageVisit.setName(genders.getJSONObject(i).get("name").toString());
            pageVisit.setValue(genders.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("13");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }

        JSONArray province = JSONArray.parseArray(visit_uv_new.get("province").toString());
        for (int i = 0; i < province.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(province.getJSONObject(i).getLong("id"));
            pageVisit.setName(province.getJSONObject(i).get("name").toString());
            pageVisit.setValue(province.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("11");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        JSONArray city = JSONArray.parseArray(visit_uv_new.get("city").toString());
        for (int i = 0; i < city.size(); i++) {
            TAppletVisitStatic pageVisit = new TAppletVisitStatic();
            pageVisit.setId(city.getJSONObject(i).getLong("id"));
            pageVisit.setName(city.getJSONObject(i).get("name").toString());
            pageVisit.setValue(city.getJSONObject(i).getLong("value"));
            pageVisit.setStoreId(0L);
            pageVisit.setType("12");
            pageVisit.setCreateTime(new Date());
            appletVisitStaticService.insertTAppletVisitStatic(pageVisit);
        }
        /** 新增（1省，2市，3性别，4平台 5设备 6 年龄）
         留存（11省，12市，13性别，14平台 15设备 16 年龄） */

        log.debug("getUserPortrait2......end");
    }

    @GetMapping("/t1")
    public void t1() {
        log.debug("getVisitPage......start");
        WechatPaySet wechatAppletPaySet = paySettingService.queryPaySet(0).getWechatAppletPaySet();
        WechatSetting wechatSetting = new WechatSetting();
        wechatSetting.setAppId(wechatAppletPaySet.getAppId());
        wechatSetting.setAppSecret(wechatAppletPaySet.getAppSecret());
        WechatParam param = new WechatParam();
        String yesterday = DateUtils.parseDateToStr("yyyyMMdd", DateUtils.addDays(new Date(), -1));
        param.setBegin_date(yesterday);
        param.setEnd_date(yesterday);
        String json = WechatAppletDataUtils.getVisitPage(wechatSetting, param);
        JSONObject object = JSONObject.parseObject(json);
        JSONArray array = JSONArray.parseArray(object.get("list").toString());
        for (int i = 0; i < array.size(); i++) {
            TAppletPageVisit pageVisit = new TAppletPageVisit();
            pageVisit.setPagePath(array.getJSONObject(i).get("page_path").toString());
            pageVisit.setPageVisitUv((Integer) array.getJSONObject(i).get("page_visit_uv"));
            pageVisit.setPageVisitPv((Integer) array.getJSONObject(i).get("page_visit_pv"));
            pageVisit.setPageStaytimePv(array.getJSONObject(i).getBigDecimal("page_staytime_pv"));
            pageVisit.setEntrypagePv((Integer) array.getJSONObject(i).get("entrypage_pv"));
            pageVisit.setExitpagePv((Integer) array.getJSONObject(i).get("exitpage_pv"));
            pageVisit.setPageSharePv((Integer) array.getJSONObject(i).get("page_share_pv"));
            pageVisit.setPageShareUv((Integer) array.getJSONObject(i).get("page_share_uv"));
            pageVisit.setCreateTime(new Date());
            pageVisit.setStoreId(0L);
            appletPageVisitService.insertTAppletPageVisit(pageVisit);

        }

        log.debug("getVisitPage......end");
    }


}
