package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElPaperQuAnswer;
import com.ruoyi.exam.service.IElPaperQuAnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 试卷考题备选答案Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElPaperQuAnswer")
public class ElPaperQuAnswerController extends BaseController {
    @Autowired
    private IElPaperQuAnswerService elPaperQuAnswerService;

    /**
     * 查询试卷考题备选答案列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQuAnswer:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElPaperQuAnswer elPaperQuAnswer) {
        startPage();
        List<ElPaperQuAnswer> list = elPaperQuAnswerService.selectElPaperQuAnswerList(elPaperQuAnswer);
        return getDataTable(list);
    }

    /**
     * 导出试卷考题备选答案列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQuAnswer:export')")
    @Log(title = "试卷考题备选答案", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElPaperQuAnswer elPaperQuAnswer) {
        List<ElPaperQuAnswer> list = elPaperQuAnswerService.selectElPaperQuAnswerList(elPaperQuAnswer);
        ExcelUtil<ElPaperQuAnswer> util = new ExcelUtil<ElPaperQuAnswer>(ElPaperQuAnswer.class);
        return util.exportExcel(list, "ElPaperQuAnswer");
    }

    /**
     * 获取试卷考题备选答案详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQuAnswer:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elPaperQuAnswerService.selectElPaperQuAnswerById(id));
    }

    /**
     * 新增试卷考题备选答案
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQuAnswer:add')")
    @Log(title = "试卷考题备选答案", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElPaperQuAnswer elPaperQuAnswer) {
        return toAjax(elPaperQuAnswerService.insertElPaperQuAnswer(elPaperQuAnswer));
    }

    /**
     * 修改试卷考题备选答案
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQuAnswer:edit')")
    @Log(title = "试卷考题备选答案", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElPaperQuAnswer elPaperQuAnswer) {
        return toAjax(elPaperQuAnswerService.updateElPaperQuAnswer(elPaperQuAnswer));
    }

    /**
     * 删除试卷考题备选答案
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaperQuAnswer:remove')")
    @Log(title = "试卷考题备选答案", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elPaperQuAnswerService.deleteElPaperQuAnswerByIds(ids));
    }
}
