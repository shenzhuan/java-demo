/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:TStepDataController.java
 * Date:2021/01/09 11:40:09
 */

package com.ruoyi.web.controller.sms;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.sms.domain.TStepData;
import com.ruoyi.sms.service.ITStepDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 运动步数Controller
 *
 * @author é­éåå
 * @date 2020-10-19
 */
@RestController
@RequestMapping("/sms/TStepData")
public class TStepDataController extends BaseController {
    @Autowired
    private ITStepDataService tStepDataService;

    /**
     * 查询运动步数列表
     */
    @PreAuthorize("@ss.hasPermi('sms:TStepData:list')")
    @GetMapping("/list")
    public TableDataInfo list(TStepData tStepData) {
        startPage();
        List<TStepData> list = tStepDataService.selectTStepDataList(tStepData);
        return getDataTable(list);
    }

    /**
     * 导出运动步数列表
     */
    @PreAuthorize("@ss.hasPermi('sms:TStepData:export')")
    @Log(title = "运动步数", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(TStepData tStepData) {
        List<TStepData> list = tStepDataService.selectTStepDataList(tStepData);
        ExcelUtil<TStepData> util = new ExcelUtil<TStepData>(TStepData.class);
        return util.exportExcel(list, "TStepData");
    }

    /**
     * 获取运动步数详细信息
     */
    @PreAuthorize("@ss.hasPermi('sms:TStepData:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(tStepDataService.selectTStepDataById(id));
    }

    /**
     * 新增运动步数
     */
    @PreAuthorize("@ss.hasPermi('sms:TStepData:add')")
    @Log(title = "运动步数", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TStepData tStepData) {
        return toAjax(tStepDataService.insertTStepData(tStepData));
    }

    /**
     * 修改运动步数
     */
    @PreAuthorize("@ss.hasPermi('sms:TStepData:edit')")
    @Log(title = "运动步数", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TStepData tStepData) {
        return toAjax(tStepDataService.updateTStepData(tStepData));
    }

    /**
     * 删除运动步数
     */
    @PreAuthorize("@ss.hasPermi('sms:TStepData:remove')")
    @Log(title = "运动步数", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(tStepDataService.deleteTStepDataByIds(ids));
    }
}
