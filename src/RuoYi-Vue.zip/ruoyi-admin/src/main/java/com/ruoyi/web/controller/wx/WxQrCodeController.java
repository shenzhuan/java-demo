package com.ruoyi.web.controller.wx;

import com.baomidou.mybatisplus.extension.api.R;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.wx.domain.WxQrCode;
import com.ruoyi.wx.form.WxQrCodeForm;
import com.ruoyi.wx.service.IWxQrCodeService;
import io.swagger.annotations.ApiOperation;
import me.chanjar.weixin.common.error.WxErrorException;
import me.chanjar.weixin.mp.api.WxMpService;
import me.chanjar.weixin.mp.bean.result.WxMpQrCodeTicket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 公众号带参二维码Controller
 *
 * @author é­éåå
 * @date 2021-06-26
 */
@RestController
@RequestMapping("/wx/WxQrCode")
public class WxQrCodeController extends BaseController {
    @Autowired
    private IWxQrCodeService wxQrCodeService;
    @Autowired
    private WxMpService wxMpService;
    /**
     * 查询公众号带参二维码列表
     */
    @GetMapping("/list")
    public TableDataInfo list(WxQrCode wxQrCode) {
        startPage();
        List<WxQrCode> list = wxQrCodeService.selectWxQrCodeList(wxQrCode);
        return getDataTable(list);
    }

    /**
     * 导出公众号带参二维码列表
     */
    @Log(title = "公众号带参二维码", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(WxQrCode wxQrCode) {
        List<WxQrCode> list = wxQrCodeService.selectWxQrCodeList(wxQrCode);
        ExcelUtil<WxQrCode> util = new ExcelUtil<WxQrCode>(WxQrCode.class);
        return util.exportExcel(list, "WxQrCode");
    }

    /**
     * 获取公众号带参二维码详细信息
     */

    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(wxQrCodeService.selectWxQrCodeById(id));
    }

    /**
     * 新增公众号带参二维码
     */

    @Log(title = "公众号带参二维码", businessType = BusinessType.INSERT)
    @PostMapping("/save")
    public AjaxResult add(@RequestBody WxQrCode wxQrCode) {
        return toAjax(wxQrCodeService.insertWxQrCode(wxQrCode));
    }

    /**
     * 修改公众号带参二维码
     */
    @Log(title = "公众号带参二维码", businessType = BusinessType.UPDATE)
    @PostMapping("/update")
    public AjaxResult edit(@RequestBody WxQrCode wxQrCode) {
        return toAjax(wxQrCodeService.updateWxQrCode(wxQrCode));
    }

    /**
     * 删除公众号带参二维码
     */

    @Log(title = "公众号带参二维码", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(wxQrCodeService.deleteWxQrCodeByIds(ids));
    }

    /**
     * 创建带参二维码ticket
     */
    @PostMapping("/createTicket")
    @ApiOperation(value = "创建带参二维码ticket",notes = "ticket可以换取二维码图片")
    public AjaxResult createTicket(@CookieValue String appid,@RequestBody WxQrCodeForm form) throws WxErrorException {
        wxMpService.switchoverTo(appid);
        WxMpQrCodeTicket ticket = wxQrCodeService.createQrCode(appid,form);
        return AjaxResult.success(ticket);
    }
}
