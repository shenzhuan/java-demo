package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElUserExam;
import com.ruoyi.exam.service.IElUserExamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 考试记录Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElUserExam")
public class ElUserExamController extends BaseController {
    @Autowired
    private IElUserExamService elUserExamService;

    /**
     * 查询考试记录列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserExam:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElUserExam elUserExam) {
        startPage();
        List<ElUserExam> list = elUserExamService.selectElUserExamList(elUserExam);
        return getDataTable(list);
    }

    @GetMapping("/pageing")
    public TableDataInfo pageing(ElUserExam elUserExam) {
        startPage();
        List<ElUserExam> list = elUserExamService.pageing(elUserExam);
        return getDataTable(list);
    }

    /**
     * 导出考试记录列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserExam:export')")
    @Log(title = "考试记录", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElUserExam elUserExam) {
        List<ElUserExam> list = elUserExamService.selectElUserExamList(elUserExam);
        ExcelUtil<ElUserExam> util = new ExcelUtil<ElUserExam>(ElUserExam.class);
        return util.exportExcel(list, "ElUserExam");
    }

    /**
     * 获取考试记录详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserExam:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elUserExamService.selectElUserExamById(id));
    }

    /**
     * 新增考试记录
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserExam:add')")
    @Log(title = "考试记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElUserExam elUserExam) {
        return toAjax(elUserExamService.insertElUserExam(elUserExam));
    }

    /**
     * 修改考试记录
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserExam:edit')")
    @Log(title = "考试记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElUserExam elUserExam) {
        return toAjax(elUserExamService.updateElUserExam(elUserExam));
    }

    /**
     * 删除考试记录
     */
    @PreAuthorize("@ss.hasPermi('exam:ElUserExam:remove')")
    @Log(title = "考试记录", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elUserExamService.deleteElUserExamByIds(ids));
    }
}
