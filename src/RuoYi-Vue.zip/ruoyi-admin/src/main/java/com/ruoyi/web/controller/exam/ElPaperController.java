package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElPaper;
import com.ruoyi.exam.dto.ext.PaperQuDetailDTO;
import com.ruoyi.exam.dto.request.PaperAnswerDTO;
import com.ruoyi.exam.dto.request.PaperCreateReqDTO;
import com.ruoyi.exam.dto.request.PaperQuQueryDTO;
import com.ruoyi.exam.dto.response.ExamDetailRespDTO;
import com.ruoyi.exam.dto.response.ExamResultRespDTO;
import com.ruoyi.exam.service.IElPaperService;
import com.ruoyi.exam.vo.BaseIdReqDTO;
import com.ruoyi.exam.vo.BaseIdRespDTO;
import com.ruoyi.web.utils.AdminLoginUtils;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 试卷Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElPaper")
public class ElPaperController extends BaseController {
    @Autowired
    private IElPaperService elPaperService;

    /**
     * 查询试卷列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaper:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElPaper elPaper) {
        startPage();
        List<ElPaper> list = elPaperService.selectElPaperList(elPaper);
        return getDataTable(list);
    }

    /**
     * 导出试卷列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaper:export')")
    @Log(title = "试卷", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElPaper elPaper) {
        List<ElPaper> list = elPaperService.selectElPaperList(elPaper);
        ExcelUtil<ElPaper> util = new ExcelUtil<ElPaper>(ElPaper.class);
        return util.exportExcel(list, "ElPaper");
    }

    /**
     * 获取试卷详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaper:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elPaperService.selectElPaperById(id));
    }

    /**
     * 新增试卷
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaper:add')")
    @Log(title = "试卷", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElPaper elPaper) {
        return toAjax(elPaperService.insertElPaper(elPaper));
    }

    /**
     * 修改试卷
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaper:edit')")
    @Log(title = "试卷", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElPaper elPaper) {
        return toAjax(elPaperService.updateElPaper(elPaper));
    }

    /**
     * 删除试卷
     */
    @PreAuthorize("@ss.hasPermi('exam:ElPaper:remove')")
    @Log(title = "试卷", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elPaperService.deleteElPaperByIds(ids));
    }

    /**
     * 创建试卷
     *
     * @param reqDTO
     * @return
     */
    @ApiOperation(value = "创建试卷")
    @RequestMapping(value = "/create-paper", method = {RequestMethod.POST})
    public AjaxResult save(@RequestBody PaperCreateReqDTO reqDTO) {
        //复制参数
        Long paperId = elPaperService.createPaper(AdminLoginUtils.getInstance().getManagerId(), reqDTO.getExamId());
        return AjaxResult.success(new BaseIdRespDTO(paperId));
    }

    /**
     * 批量删除
     *
     * @param reqDTO
     * @return
     */
    @ApiOperation(value = "试卷详情")
    @RequestMapping(value = "/paper-detail", method = {RequestMethod.POST})
    public AjaxResult paperDetail(@RequestBody BaseIdReqDTO reqDTO) {
        //根据ID删除
        ExamDetailRespDTO respDTO = elPaperService.paperDetail(reqDTO.getId());
        return AjaxResult.success(respDTO);
    }

    /**
     * 批量删除
     *
     * @param reqDTO
     * @return
     */
    @ApiOperation(value = "试题详情")
    @RequestMapping(value = "/qu-detail", method = {RequestMethod.POST})
    public AjaxResult quDetail(@RequestBody PaperQuQueryDTO reqDTO) {
        //根据ID删除
        PaperQuDetailDTO respDTO = elPaperService.findQuDetail(reqDTO.getPaperId(), reqDTO.getQuId());
        return AjaxResult.success(respDTO);
    }

    /**
     * 填充答案
     *
     * @param reqDTO
     * @return
     */
    @ApiOperation(value = "填充答案")
    @RequestMapping(value = "/fill-answer", method = {RequestMethod.POST})
    public AjaxResult fillAnswer(@RequestBody PaperAnswerDTO reqDTO) {
        //根据ID删除
        elPaperService.fillAnswer(reqDTO);
        return AjaxResult.success();
    }


    /**
     * 交卷操作
     *
     * @param reqDTO
     * @return
     */
    @ApiOperation(value = "交卷操作")
    @RequestMapping(value = "/hand-exam", method = {RequestMethod.POST})
    public AjaxResult handleExam(@RequestBody BaseIdReqDTO reqDTO) {
        //根据ID删除
        elPaperService.handExam(reqDTO.getId(), AdminLoginUtils.getInstance().getManagerId());
        return AjaxResult.success();
    }


    /**
     * 批量删除
     *
     * @param reqDTO
     * @return
     */
    @ApiOperation(value = "试卷详情")
    @RequestMapping(value = "/paper-result", method = {RequestMethod.POST})
    public AjaxResult paperResult(@RequestBody BaseIdReqDTO reqDTO) {
        //根据ID删除
        ExamResultRespDTO respDTO = elPaperService.paperResult(reqDTO.getId());
        return AjaxResult.success(respDTO);
    }


    /**
     * 提交阅卷
     *
     * @param reqDTO
     * @return
     */
    @ApiOperation(value = "提交阅卷")
    @RequestMapping(value = "/review-paper", method = {RequestMethod.POST})
    public AjaxResult reviewPaper(@RequestBody ExamResultRespDTO reqDTO) {
        //根据ID删除
        elPaperService.reviewPaper(reqDTO);
        return AjaxResult.success();
    }
}
