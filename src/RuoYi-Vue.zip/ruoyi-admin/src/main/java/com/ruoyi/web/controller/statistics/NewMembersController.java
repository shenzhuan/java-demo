/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:NewMembersController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.statistics;


import com.ruoyi.member.domain.UmsMember;
import com.ruoyi.member.service.IUmsMemberService;
import com.ruoyi.member.vo.CustomerSearchCondition;
import com.ruoyi.statistics.service.StatisticsServiceApi;
import com.ruoyi.store.vo.NewCustomerStatistics;
import com.ruoyi.util.BaseResponse;
import com.ruoyi.util.PageHelper;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author 魔金 2123957932
 * @date 2019-06-24 16:12
 * <p>
 * 新增会员统计控制器
 */
@RestController
@Api(description = "新增会员统计接口")
public class NewMembersController {


    /**
     * 注入会员服务接口
     */
    @Autowired
    private IUmsMemberService customerService;

    /**
     * 注入统计服务
     */
    @Autowired
    private StatisticsServiceApi statisticsServiceApi;

    /**
     * 分页查询新增会员统计（按日期分组）
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return 返回按日期分组的新增会员统计
     */
    @GetMapping("/newmembers/statistics")
    @ApiOperation(value = "分页查询新增会员统计（按日期分组）", notes = "分页查询新增会员统计（按日期分组）（需要认证）")
    @PreAuthorize("hasAuthority('newmembers/querynewcustomerstatisticswithpage')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回按日期分组的新增会员统计", response = NewCustomerStatistics.class)
    })
    public BaseResponse queryNewCustomerStatisticsWithPage(@ApiIgnore PageHelper<NewCustomerStatistics> pageHelper, String startTime, String endTime) {
        return BaseResponse.build(statisticsServiceApi.queryNewCustomerStatisticsWithPage(pageHelper, startTime, endTime));
    }


    /**
     * 查询新增会员统计（按日期分组）
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return 返回按日期分组的新增会员统计
     */
    @GetMapping("/newmembers")
    @ApiOperation(value = "查询新增会员统计（按日期分组）", notes = "查询新增会员统计（按日期分组）（需要认证）")
    @PreAuthorize("hasAuthority('newmembers/querynewcustomerstatistics')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回按日期分组的新增会员统计", response = NewCustomerStatistics.class)
    })
    public java.util.List<NewCustomerStatistics> queryNewCustomerStatistics(String startTime, String endTime) {
        return statisticsServiceApi.queryNewCustomerStatistics(startTime, endTime);
    }


    /**
     * 分页查询新增会员信息
     *
     * @param pageHelper      分页帮助类
     * @param searchCondition 搜索条件
     * @return 返回会员信息
     */
    @GetMapping("/newmembers/new")
    @ApiOperation(value = "分页查询新增会员信息", notes = "分页查询新增会员信息（需要认证）")
    @PreAuthorize("hasAuthority('newmembers/querynewcustomer')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "createTime", value = "创建时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回会员信息", response = UmsMember.class)
    })
    public BaseResponse queryNewCustomer(@ApiIgnore PageHelper<UmsMember> pageHelper, @ApiIgnore CustomerSearchCondition searchCondition) {
        return BaseResponse.build(customerService.queryCustomers(pageHelper, searchCondition));
    }


}
