/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:SmsVideoController.java
 * Date:2021/01/09 11:40:09
 */

package com.ruoyi.web.controller.sms;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.sms.domain.SmsVideo;
import com.ruoyi.sms.service.ISmsVideoService;
import com.ruoyi.util.CommonConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 视频列表Controller
 *
 * @author 魔金
 * @date 2020-11-27
 */
@RestController
@RequestMapping("/sms/SmsVideo")
public class SmsVideoController extends BaseController {
    @Autowired
    private ISmsVideoService smsVideoService;

    /**
     * 查询视频列表列表
     */
    @PreAuthorize("@ss.hasPermi('sms:SmsVideo:list')")
    @GetMapping("/list")
    public TableDataInfo list(SmsVideo smsVideo) {
        startPage();
        smsVideo.setStoreId(CommonConstant.ADMIN_STOREID);
        List<SmsVideo> list = smsVideoService.selectSmsVideoList(smsVideo);
        return getDataTable(list);
    }


    /**
     * 获取视频列表详细信息
     */
    @PreAuthorize("@ss.hasPermi('sms:SmsVideo:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(smsVideoService.selectSmsVideoById(id));
    }

    /**
     * 新增视频列表
     */
    @PreAuthorize("@ss.hasPermi('sms:SmsVideo:add')")
    @Log(title = "视频列表", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SmsVideo smsVideo) {
        smsVideo.setStoreId(CommonConstant.ADMIN_STOREID);
        return toAjax(smsVideoService.insertSmsVideo(smsVideo));
    }

    /**
     * 修改视频列表
     */
    @PreAuthorize("@ss.hasPermi('sms:SmsVideo:edit')")
    @Log(title = "视频列表", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SmsVideo smsVideo) {
        return toAjax(smsVideoService.updateSmsVideo(smsVideo));
    }

    /**
     * 删除视频列表
     */
    @PreAuthorize("@ss.hasPermi('sms:SmsVideo:remove')")
    @Log(title = "视频列表", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(smsVideoService.deleteSmsVideoByIds(ids));
    }
}
