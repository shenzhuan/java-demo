/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:TAppletVisitController.java
 * Date:2021/01/09 11:40:09
 */

package com.ruoyi.web.controller.sms;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.sms.domain.TAppletVisit;
import com.ruoyi.sms.service.ITAppletVisitService;
import com.ruoyi.util.CommonConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 【请填写功能名称】Controller
 *
 * @author é­éåå
 * @date 2021-01-08
 */
@RestController
@RequestMapping("/sms/TAppletVisit")
public class TAppletVisitController extends BaseController {
    @Autowired
    private ITAppletVisitService tAppletVisitService;

    /**
     * 查询【请填写功能名称】列表
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisit:list')")
    @GetMapping("/list")
    public TableDataInfo list(TAppletVisit tAppletVisit) {
        startPage();
        tAppletVisit.setStoreId(CommonConstant.ADMIN_STOREID);
        List<TAppletVisit> list = tAppletVisitService.selectTAppletVisitList(tAppletVisit);
        return getDataTable(list);
    }

    /**
     * 导出【请填写功能名称】列表
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisit:export')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(TAppletVisit tAppletVisit) {
        List<TAppletVisit> list = tAppletVisitService.selectTAppletVisitList(tAppletVisit);
        ExcelUtil<TAppletVisit> util = new ExcelUtil<TAppletVisit>(TAppletVisit.class);
        return util.exportExcel(list, "TAppletVisit");
    }

    /**
     * 获取【请填写功能名称】详细信息
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisit:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(tAppletVisitService.selectTAppletVisitById(id));
    }

    /**
     * 新增【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisit:add')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TAppletVisit tAppletVisit) {
        return toAjax(tAppletVisitService.insertTAppletVisit(tAppletVisit));
    }

    /**
     * 修改【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisit:edit')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TAppletVisit tAppletVisit) {
        return toAjax(tAppletVisitService.updateTAppletVisit(tAppletVisit));
    }

    /**
     * 删除【请填写功能名称】
     */
    @PreAuthorize("@ss.hasPermi('sms:TAppletVisit:remove')")
    @Log(title = "【请填写功能名称】", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(tAppletVisitService.deleteTAppletVisitByIds(ids));
    }
}
