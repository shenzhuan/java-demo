package com.ruoyi.web.controller.wx;

import com.baomidou.mybatisplus.extension.api.R;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.wx.domain.WxUser;
import com.ruoyi.wx.service.IWxUserService;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import me.chanjar.weixin.mp.api.WxMpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

/**
 * 用户Controller
 *
 * @author é­éåå
 * @date 2021-06-26
 */
@RestController
@RequestMapping("/wx/WxUser")
@RequiredArgsConstructor
public class WxUserController extends BaseController {
    private final WxMpService wxMpService;
    @Autowired
    private IWxUserService wxUserService;

    @GetMapping("/getUserInfo")
    @ApiOperation(value = "获取粉丝信息")
    public R getUserInfo(@CookieValue String appid, @CookieValue String openid) {
        this.wxMpService.switchoverTo(appid);
        WxUser wxUser = wxUserService.selectWxUserById(openid);
        return R.ok(wxUser);
    }

    /**
     * 查询用户列表
     */
    @GetMapping("/list")
    public TableDataInfo list(WxUser wxUser) {
        startPage();
        List<WxUser> list = wxUserService.selectWxUserList(wxUser);
        return getDataTable(list);
    }

    /**
     * 导出用户列表
     */
    @Log(title = "用户", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(WxUser wxUser) {
        List<WxUser> list = wxUserService.selectWxUserList(wxUser);
        ExcelUtil<WxUser> util = new ExcelUtil<WxUser>(WxUser.class);
        return util.exportExcel(list, "WxUser");
    }

    /**
     * 获取用户详细信息
     */

    @GetMapping(value = "/{openid}")
    public AjaxResult getInfo(@PathVariable("openid") String openid) {
        return AjaxResult.success(wxUserService.selectWxUserById(openid));
    }

    /**
     * 新增用户
     */

    @Log(title = "用户", businessType = BusinessType.INSERT)
    @PostMapping("/save")
    public AjaxResult add(@RequestBody WxUser wxUser) {
        return toAjax(wxUserService.insertWxUser(wxUser));
    }

    /**
     * 修改用户
     */
    @Log(title = "用户", businessType = BusinessType.UPDATE)
    @PostMapping("/update")
    public AjaxResult edit(@RequestBody WxUser wxUser) {
        return toAjax(wxUserService.updateWxUser(wxUser));
    }

    /**
     * 删除用户
     */

    @Log(title = "用户", businessType = BusinessType.DELETE)
    @DeleteMapping("/{openids}")
    public AjaxResult remove(@PathVariable String[] openids) {
        return toAjax(wxUserService.deleteWxUserByIds(openids));
    }
    /**
     * 列表
     */
    @PostMapping("/listByIds")
    @ApiOperation(value = "列表-ID查询")
    public AjaxResult listByIds(@CookieValue String appid,@RequestBody String[] openids){
        List<WxUser> users = wxUserService.listByIds(Arrays.asList(openids));
        return AjaxResult.success(users);
    }
    /**
     * 同步用户列表
     */
    @PostMapping("/syncWxUsers")
    @ApiOperation(value = "同步用户列表到数据库")
    public AjaxResult syncWxUsers(@CookieValue String appid) {
        wxUserService.syncWxUsers(appid);
        return AjaxResult.success("任务已建立");
    }

}
