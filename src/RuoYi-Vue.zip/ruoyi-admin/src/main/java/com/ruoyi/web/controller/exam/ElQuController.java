package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElQu;
import com.ruoyi.exam.service.IElQuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 问题题目Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElQu")
public class ElQuController extends BaseController {
    @Autowired
    private IElQuService elQuService;

    /**
     * 查询问题题目列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQu:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElQu elQu) {
        startPage();
        List<ElQu> list = elQuService.selectElQuList(elQu);
        return getDataTable(list);
    }

    /**
     * 导出问题题目列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQu:export')")
    @Log(title = "问题题目", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElQu elQu) {
        List<ElQu> list = elQuService.selectElQuList(elQu);
        ExcelUtil<ElQu> util = new ExcelUtil<ElQu>(ElQu.class);
        return util.exportExcel(list, "ElQu");
    }

    /**
     * 获取问题题目详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQu:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elQuService.selectElQuById(id));
    }

    /**
     * 新增问题题目
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQu:add')")
    @Log(title = "问题题目", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElQu elQu) {
        return toAjax(elQuService.save(elQu));
    }

    /**
     * 修改问题题目
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQu:edit')")
    @Log(title = "问题题目", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElQu elQu) {
        return toAjax(elQuService.save(elQu));
    }

    /**
     * 删除问题题目
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQu:remove')")
    @Log(title = "问题题目", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elQuService.deleteElQuByIds(ids));
    }
}
