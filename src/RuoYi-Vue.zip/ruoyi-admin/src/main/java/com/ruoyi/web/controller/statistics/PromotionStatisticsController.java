/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:PromotionStatisticsController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.statistics;


import com.ruoyi.order.vo.MarketingStatistics;
import com.ruoyi.statistics.service.StatisticsServiceApi;
import com.ruoyi.util.CommonConstant;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author 魔金 2123957932
 * @date 2019-06-24 13:31
 * <p>
 * 促销统计控制器
 */
@RestController
@Api(description = "促销统计接口")
public class PromotionStatisticsController {


    /**
     * 注入统计服务
     */
    @Autowired
    private StatisticsServiceApi statisticsServiceApi;


    /**
     * 查询促销统计
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return 查询促销统计
     */
    @GetMapping("/promotionstatistics")
    @ApiOperation(value = "查询促销统计", notes = "查询促销统计（需要认证）")
    @PreAuthorize("hasAuthority('promotionstatistics/querymarketingstatistics')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "查询促销统计", response = MarketingStatistics.class)
    })
    public MarketingStatistics queryMarketingStatistics(String startTime, String endTime) {
        return statisticsServiceApi.queryMarketingStatistics(startTime, endTime, CommonConstant.ADMIN_STOREID);
    }


}
