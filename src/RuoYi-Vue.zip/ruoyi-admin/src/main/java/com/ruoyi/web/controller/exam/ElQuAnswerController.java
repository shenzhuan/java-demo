package com.ruoyi.web.controller.exam;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.exam.domain.ElQuAnswer;
import com.ruoyi.exam.service.IElQuAnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 候选答案Controller
 *
 * @author é­éåå
 * @date 2021-06-05
 */
@RestController
@RequestMapping("/exam/ElQuAnswer")
public class ElQuAnswerController extends BaseController {
    @Autowired
    private IElQuAnswerService elQuAnswerService;

    /**
     * 查询候选答案列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuAnswer:list')")
    @GetMapping("/list")
    public TableDataInfo list(ElQuAnswer elQuAnswer) {
        startPage();
        List<ElQuAnswer> list = elQuAnswerService.selectElQuAnswerList(elQuAnswer);
        return getDataTable(list);
    }

    /**
     * 导出候选答案列表
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuAnswer:export')")
    @Log(title = "候选答案", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(ElQuAnswer elQuAnswer) {
        List<ElQuAnswer> list = elQuAnswerService.selectElQuAnswerList(elQuAnswer);
        ExcelUtil<ElQuAnswer> util = new ExcelUtil<ElQuAnswer>(ElQuAnswer.class);
        return util.exportExcel(list, "ElQuAnswer");
    }

    /**
     * 获取候选答案详细信息
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuAnswer:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return AjaxResult.success(elQuAnswerService.selectElQuAnswerById(id));
    }

    /**
     * 新增候选答案
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuAnswer:add')")
    @Log(title = "候选答案", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ElQuAnswer elQuAnswer) {
        return toAjax(elQuAnswerService.insertElQuAnswer(elQuAnswer));
    }

    /**
     * 修改候选答案
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuAnswer:edit')")
    @Log(title = "候选答案", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ElQuAnswer elQuAnswer) {
        return toAjax(elQuAnswerService.updateElQuAnswer(elQuAnswer));
    }

    /**
     * 删除候选答案
     */
    @PreAuthorize("@ss.hasPermi('exam:ElQuAnswer:remove')")
    @Log(title = "候选答案", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(elQuAnswerService.deleteElQuAnswerByIds(ids));
    }
}
