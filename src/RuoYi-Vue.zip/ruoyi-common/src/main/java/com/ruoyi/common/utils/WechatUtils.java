/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:WechatUtils.java
 * Date:2021/01/16 18:57:16
 */

package com.ruoyi.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ruoyi.common.md5.MD5Utils;
import com.ruoyi.common.utils.bean.*;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.net.ssl.SSLContext;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyStore;
import java.util.*;


/**
 * 微信工具类
 */
public class WechatUtils {

    /**
     * 支付异步回调成功后需返回的xml
     */
    public final static String SUCCESS_RETURN = "<xml><return_code>SUCCESS</return_code><return_msg>OK</return_msg></xml>";
    /**
     * 成功
     */
    public final static String SUCCESS = "SUCCESS";
    /**
     * 公众号支付
     */
    public final static int OFFICIAL_ACCOUNT_PAY = 1;
    /**
     * H5支付
     */
    public final static int H5_PAY = 2;
    /**
     * 扫码支付
     */
    public final static int QR_PAY = 3;
    /**
     * app支付
     */
    public final static int APP_PAY = 4;
    /**
     * 小程序支付
     */
    public final static int APPLET_PAY = 5;
    /**
     * 调试日志
     */
    private static final Logger logger = LoggerFactory.getLogger(WechatUtils.class);
    private final static String GET_LOGIN_INFO_URL = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=%s&secret=%s&code=%s&grant_type=authorization_code";
    /**
     * 获取code地址 https://api.weixin.qq.com/sns/oauth2/access_token
     */
    private final static String GET_CODE_URL =
            "https://open.weixin.qq.com/connect/oauth2/authorize?appid=%s&redirect_uri=%s&response_type=code&scope=%s&state=%s#wechat_redirect";
    /**
     * 获取access_token地址
     */
    private final static String GET_ACCESS_TOKEN_URL =
            "https://api.weixin.qq.com/sns/oauth2/access_token?appid=%s&secret=%s&code=%s&grant_type=authorization_code";
    /**
     * 获取用户信息地址
     */
    private final static String GET_USERINFO_URL =
            "https://api.weixin.qq.com/sns/userinfo?access_token=%s&openid=%s&lang=zh_CN";
    /**
     * 静默授权
     */
    private final static String SNSAPI_BASE = "snsapi_base";
    /**
     * 用户授权
     */
    private final static String SNSAPI_USERINFO = "snsapi_userinfo";
    /**
     * 微信支付统一下单地址
     */
    private final static String UNION_SUBMIT_ORDER_URL = "https://api.mch.weixin.qq.com/pay/unifiedorder";
    /**
     * 获取微信分享access_token地址（参数为 appid 和 secret）
     */
    private final static String GET_ACCESS_TOKEN_FOR_SHARE_URL =
            "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=%s&secret=%s";
    /**
     * 获取微信分享jsapi_ticket地址（参数为 access_token）
     */
    private final static String GET_JSAPI_TICKET_URL =
            "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=%s&type=jsapi";

    private WechatUtils() {
    }

    /**
     * 获取静默授权地址
     *
     * @param fromUrl       拦截前链接
     * @param wechatSetting 微信设置实体
     * @return 静默授权地址
     */
    public static String getCodeUrlBase(String fromUrl, WechatSetting wechatSetting) {
        logger.debug("getCodeUrlBase and fromUrl:{} \r\n wechatSetting:{}", fromUrl, wechatSetting);
        return String.format(GET_CODE_URL, wechatSetting.getAppId(), wechatSetting.getUrl(), SNSAPI_BASE, fromUrl);
    }

    /**
     * 获取登录信息
     *
     * @param code          用户登录凭证（有效期五分钟）。开发者需要在开发者服务器后台调用 api，使用 code 换取 openid 和 session_key 等信息
     * @param wechatSetting 微信设置
     * @return 微信小程序登录返回实体
     */
    public static WeChatAppletLoginResponse getLoginInfo(String code, WechatSetting wechatSetting) {
        logger.debug("getLoginInfo and code:{} \r\n wechatSetting:{}", code, wechatSetting);
        String json = WechatUtils.executeHttpGet(String.format(GET_LOGIN_INFO_URL, wechatSetting.getAppId(), wechatSetting.getAppSecret(), code));
        logger.debug("getLoginInfo and json:{}", json);
        WeChatAppletLoginResponse weChatAppletLoginResponse = JSON.parseObject(json, WeChatAppletLoginResponse.class);
        if (Objects.isNull(weChatAppletLoginResponse)) {
            logger.error("getLoginInfo fail : weChatAppletLoginResponse is null");
            return null;
        }
        if (weChatAppletLoginResponse.isError()) {
            logger.debug("getLoginInfo fail and errorMsg:{}", weChatAppletLoginResponse.getErrmsg());
            return null;
        }
        return weChatAppletLoginResponse;
    }

    /**
     * 获取用户授权地址
     *
     * @param fromUrl       拦截前链接
     * @param wechatSetting 微信设置实体
     * @return 用户授权地址
     */
    public static String getCodeUrlInfo(String fromUrl, WechatSetting wechatSetting) {
        logger.debug("getCodeUrlInfo and fromUrl:{}\r\n wechatSetting:{} ", fromUrl, wechatSetting);
        return String.format(GET_CODE_URL, wechatSetting.getAppId(), wechatSetting.getUrl(), SNSAPI_USERINFO, fromUrl);
    }

    /**
     * 获取网页授权access_token
     *
     * @param code          微信code
     * @param state         与code一起返回的状态码（额外参数）
     * @param wechatSetting 微信设置实体
     * @return 网页授权返回实体类
     */
    public static AccessTokenResult getAccessToken(String code, String state, WechatSetting wechatSetting) {
        AccessTokenResult res;
        logger.debug("getAccessToken and code:{}\r\n wechatSetting:{} ", code, wechatSetting);
        String accessTokenUrl = String.format(GET_ACCESS_TOKEN_URL, wechatSetting.getAppId(), wechatSetting.getAppSecret(), code);
        res = JSON.parseObject(executeHttpGet(accessTokenUrl), AccessTokenResult.class);
        if (res.isError()) {
            if (!StringUtils.isEmpty(res.getErrmsg())) {
                logger.error("getAccessToken Fail and errmsg:{}", res.getErrmsg());
            }
            return null;
        } else {
            res.setRedirectUrl(state);
            return res;
        }

    }

    public static AccessTokenResult getAccessToken(String code, WechatSetting wechatSetting) {
        AccessTokenResult res;
        logger.debug("getAccessToken and code:{}\r\n wechatSetting:{} ", code, wechatSetting);
        String accessTokenUrl = String.format(GET_ACCESS_TOKEN_URL, wechatSetting.getAppId(), wechatSetting.getAppSecret(), code);
        res = JSON.parseObject(executeHttpGet(accessTokenUrl), AccessTokenResult.class);
        if (res.isError()) {
            if (!StringUtils.isEmpty(res.getErrmsg())) {
                logger.error("getAccessToken Fail and errmsg:{}", res.getErrmsg());
            }
            return null;
        } else {
            return res;
        }

    }

    /**
     * 获取微信分享access_token
     *
     * @param wechatSetting 微信设置实体
     * @return 微信分享access_token
     */
    public static String getAccessTokenForShare(WechatSetting wechatSetting) {
        logger.debug("getAccessToken and wechatSetting:{} ", wechatSetting);
        String accessTokenForShareUrl = String.format(GET_ACCESS_TOKEN_FOR_SHARE_URL, wechatSetting.getAppId(), wechatSetting.getAppSecret());
        JSONObject res = JSON.parseObject(executeHttpGet(accessTokenForShareUrl));
        if (!StringUtils.isEmpty(res.getString("errcode"))) {
            if (!StringUtils.isEmpty(res.getString("errmsg"))) {
                logger.error("getAccessTokenForShare Fail and errmsg:{}", res.getString("errmsg"));
            }
            return null;
        } else {
            return res.getString("access_token");
        }
    }

    /**
     * 获取微信分享jsapi_ticket
     *
     * @param access_token 凭证
     * @return 微信分享jsapi_ticket
     */
    public static String getJsapiTicketForShare(String access_token) {
        logger.debug("getAccessToken and access_token:{} ", access_token);
        String jsapiTicketForShareUrl = String.format(GET_JSAPI_TICKET_URL, access_token);
        JSONObject res = JSON.parseObject(executeHttpGet(jsapiTicketForShareUrl));
        if (Integer.parseInt(res.getString("errcode")) != 0) {
            if (!StringUtils.isEmpty(res.getString("errmsg"))) {
                logger.error("getJsapiTicketForShare Fail and errmsg:{}", res.getString("errmsg"));
            }
            return null;
        } else {
            return res.getString("ticket");
        }
    }

    /**
     * 获取用户信息
     *
     * @param accessToken 网页授权接口调用凭证
     * @param openId      用户的唯一标识
     * @return 用户信息返回实体类
     */
    public static UserInfoResult getUserInfo(String accessToken, String openId) {
        logger.debug("getUserInfo and access_token:{}\r\n openid:{} ", accessToken, openId);

        String userInfoUrl = String.format(GET_USERINFO_URL, accessToken, openId);
        UserInfoResult res = JSON.parseObject(executeHttpGet(userInfoUrl), UserInfoResult.class);
        if (res.isError()) {
            if (!StringUtils.isEmpty(res.getErrmsg())) {
                logger.error("getUserInfo Fail and errmsg:{}", res.getErrmsg());
            }
            return null;
        } else {
            return res;
        }
    }

    /**
     * 获取预支付信息
     *
     * @param wechatSetting   微信设置实体
     * @param orderInfoForPay 订单信息
     * @return 预支付信息
     */
    public static PrepayResult getPrepay(WechatSetting wechatSetting, OrderInfoForPay orderInfoForPay) {
        logger.debug("getPrepay and \r\n wechatSetting:{} \r\n orderInfoForPay:{} ", wechatSetting, orderInfoForPay);
        String xml = getWxPayParm(wechatSetting, orderInfoForPay);
        String res = executeHttpPost(UNION_SUBMIT_ORDER_URL, xml);
        logger.debug("getPrepay and res:{}", res);

        //将xml字符串转换为java对象
        JaxbUtil resultBinder = new JaxbUtil(PrepayResult.class);
        PrepayResult prepayResult = resultBinder.fromXml(res);
        if (!prepayResult.isError()) {
            //公众号支付时增加返回信息
            if (wechatSetting.isOfficialAccountPay() || wechatSetting.isAppletPay()) {
                SortedMap<String, String> packageParams = new TreeMap<>();
                prepayResult.setPackage();
                prepayResult.setSign_type("MD5");
                prepayResult.setTime_stamp(getTimeStamp());
                packageParams.put("appId", prepayResult.getAppid());
                packageParams.put("timeStamp", prepayResult.getTime_stamp());
                packageParams.put("nonceStr", prepayResult.getNonce_str());
                packageParams.put("package", prepayResult.getPackage_());
                packageParams.put("signType", prepayResult.getSign_type());
                prepayResult.setPay_sign(createSign(packageParams, wechatSetting.getApiKey()));
            } else if (wechatSetting.isAppPay()) {
                // app支付获得签名
                SortedMap<String, String> packageParams = new TreeMap<>();
                prepayResult.setTime_stamp(getTimeStamp());
                packageParams.put("appid", prepayResult.getAppid());
                packageParams.put("timestamp", prepayResult.getTime_stamp());
                packageParams.put("noncestr", prepayResult.getNonce_str());
                packageParams.put("package", "Sign=WXPay");
                packageParams.put("partnerid", wechatSetting.getMerchantNum());
                packageParams.put("prepayid", prepayResult.getPrepay_id());
                prepayResult.setPay_sign(createSign(packageParams, wechatSetting.getApiKey()));
            }
            prepayResult.setResult_code(orderInfoForPay.getOrderCode());
            return prepayResult;
        } else {
            if (!StringUtils.isEmpty(prepayResult.getErr_code_des())) {
                logger.error("getPrepay Fail and returnmsg:{} \r\n errormsg:{} ", prepayResult.getReturn_msg(), prepayResult.getErr_code_des());
            }
            return null;
        }
    }

    /**
     * 获取统一下单请求参数
     *
     * @param wechatSetting   微信设置实体
     * @param orderInfoForPay 订单信息
     * @return 统一下单请求参数
     */
    private static String getWxPayParm(WechatSetting wechatSetting, OrderInfoForPay orderInfoForPay) {
        logger.debug("getWxPayParm and wechatSetting:{} \r\n orderInfoForPay:{} ", wechatSetting, orderInfoForPay);
        SortedMap<String, String> packageParams = new TreeMap<>();
        // 金额转化为分为单位
        int finalmoney = Integer.parseInt(String.format("%.2f", orderInfoForPay.getPrice()).replace(".", ""));
        //交易方式
        String tradeType = "";
        //场景信息
        String sceneInfo;
        //商品ID
        String productId;
        //公众号支付
        if (wechatSetting.isOfficialAccountPay() || wechatSetting.isAppletPay()) {
            //用户唯一标识
            packageParams.put("openid", wechatSetting.getOpenId());
            tradeType = "JSAPI";
        }
        //H5支付
        if (wechatSetting.isH5Pay()) {
            tradeType = "MWEB";
            sceneInfo = "{\"h5_info\": {\"type\":\"Wap\",\"wap_url\": \"" + wechatSetting.getSiteUrl() + "\",\"wap_name\": \"" + wechatSetting.getSiteName() + "\"}}";
            packageParams.put("scene_info", sceneInfo);
        }
        //扫码支付
        if (wechatSetting.isQRPay()) {
            tradeType = "NATIVE";
            productId = String.valueOf(orderInfoForPay.getGoodsId());
            packageParams.put("product_id", productId);
        }

        // APP支付
        if (wechatSetting.isAppPay()) {
            tradeType = "APP";
        }
        //公众账号ID
        packageParams.put("appid", wechatSetting.getAppId());
        //商户号
        packageParams.put("mch_id", wechatSetting.getMerchantNum());
        //随机字符串
        packageParams.put("nonce_str", getRandomString());
        //商品描述
        packageParams.put("body", getSubGoodName(orderInfoForPay.getGoodsName()));
        //附加数据(支付类型) 订单还是充值 店铺编号 支付方式
        // packageParams.put("attach", orderInfoForPay.getType() + "-"+orderInfoForPay.getStoreId()+"-"+wechatSetting.getType());
        packageParams.put("attach", orderInfoForPay.getType() + "");
        //商户订单号
        packageParams.put("out_trade_no", orderInfoForPay.getOrderCode() + "-" + getTimeStamp());
        //标价金额
        packageParams.put("total_fee", String.valueOf(finalmoney));
        //终端IP
        packageParams.put("spbill_create_ip", wechatSetting.getIp());//本地测试需替换为外网ip
        //通知地址
        packageParams.put("notify_url", wechatSetting.getPayCallback());
        //交易类型
        packageParams.put("trade_type", tradeType);
        //签名
        packageParams.put("sign", createSign(packageParams, wechatSetting.getApiKey()));

        return getRequestXml(packageParams);
    }


    /**
     * 截取商品名
     *
     * @param goodName 商品名
     * @return 截取后的商品名
     */
    private static String getSubGoodName(String goodName) {
        if (goodName.length() < 20) {
            return goodName;
        } else {
            return goodName.substring(0, 19) + "...";
        }
    }


    /**
     * 验证返回信息
     *
     * @param inputStream   微信回调信息
     * @param wechatSetting 微信设置
     * @return 订单支付信息
     */
    public static OrderInfoAfterPay afterPayInfo(InputStream inputStream, WechatSetting wechatSetting) {
        logger.debug("afterPayInfo and wechatSetting:{}", wechatSetting);
        OrderInfoAfterPay orderInfoAfterPay = new OrderInfoAfterPay();
        orderInfoAfterPay.setSuccess(false);
        BufferedReader br;
        br = new BufferedReader(new InputStreamReader(inputStream));
        String line;
        StringBuilder sb = new StringBuilder();
        try {
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

            try {
                br.close();
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        //将xml字符串转换为java对象
        JaxbUtil resultBinder = new JaxbUtil(WechatNotifyResult.class);
        WechatNotifyResult wechatNotifyResult = resultBinder.fromXml(sb.toString());
        //将xml字符串转换为map
        SortedMap<String, String> resultMap = new TreeMap<>(parseMapFromXmlStr(sb.toString()));
        //签名
        String sign = createSign(resultMap, wechatSetting.getApiKey());

        logger.info("wechat notify and wechatNotifyResult :{}", wechatNotifyResult);

        //验证是否失败，并验证签名
        if (!wechatNotifyResult.isError() && sign.equals(wechatNotifyResult.getSign())) {
            //验证其他信息
            if (SUCCESS.equals(wechatNotifyResult.getResult_code())
                    && SUCCESS.equals(wechatNotifyResult.getReturn_code())
                    && wechatSetting.getAppId().equals(wechatNotifyResult.getAppid())
                    && wechatSetting.getMerchantNum().equals(wechatNotifyResult.getMch_id())
            ) {
                orderInfoAfterPay.setOrderCode(wechatNotifyResult.getOut_trade_no().split("-")[0]);
                orderInfoAfterPay.setSuccess(true);
                orderInfoAfterPay.setType(wechatNotifyResult.getAttach());
                orderInfoAfterPay.setTransCode(wechatNotifyResult.getTransaction_id());
            }

        } else {
            logger.error("wechat afterPayInfo fail: returnmsg:{}\r\n errormsg:{}", wechatNotifyResult.getReturn_msg(), wechatNotifyResult.getErr_code_des());
        }
        return orderInfoAfterPay;
    }

    /**
     * 获取请求xml
     *
     * @param packageParams 请求参数
     * @return 请求xml
     */
    private static String getRequestXml(SortedMap<String, String> packageParams) {
        StringBuilder sb = new StringBuilder();
        sb.append("<xml>");
        Set es = packageParams.entrySet();
        for (Object e : es) {
            Map.Entry entry = (Map.Entry) e;
            String key = (String) entry.getKey();
            String value = (String) entry.getValue();
            if ("body".equalsIgnoreCase(key) || "sign".equalsIgnoreCase(key)) {
                sb.append("<").append(key).append(">").append("<![CDATA[").append(value).append("]]></").append(key).append(">");
            } else {
                sb.append("<").append(key).append(">").append(value).append("</").append(key).append(">");
            }
        }
        sb.append("</xml>");
        logger.debug("getRequestXml  and xml:{}", sb.toString());
        return sb.toString();
    }

    /**
     * 签名
     *
     * @param packageParams 签名参数
     * @param apiKey        商户key
     * @return 签名
     */
    private static String createSign(SortedMap<String, String> packageParams, String apiKey) {

        StringBuilder sb = new StringBuilder();
        Set es = packageParams.entrySet();
        for (Object e : es) {
            Map.Entry entry = (Map.Entry) e;
            String k = (String) entry.getKey();
            String v = (String) entry.getValue();
            if ((v != null) && (!"".equals(v)) && (!"sign".equals(k)) &&
                    (!"key".equals(k))) {
                sb.append(k).append("=").append(v).append("&");
            }
        }
        sb.append("key=").append(apiKey);
        logger.debug("createSign  and key:{}", apiKey);
        logger.debug("createSign  and stringSign:{}", sb.toString());
        String sign = MD5Utils.getInstance().createMd5(sb.toString())
                .toUpperCase();
        logger.debug("createSign  and sign:{}", sign);
        return sign;

    }

    /**
     * 执行GET方法请求数据
     *
     * @param url 请求地址
     * @return 返回数据
     */
    static String executeHttpGet(String url) {
        logger.debug("executeHttpGet and url:{}", url);
        String result = null;
        BasicHttpClientConnectionManager connManager = new BasicHttpClientConnectionManager(
                RegistryBuilder.<ConnectionSocketFactory>create()
                        .register("http", PlainConnectionSocketFactory.getSocketFactory())
                        .register("https", SSLConnectionSocketFactory.getSocketFactory())
                        .build(),
                null,
                null,
                null
        );

        HttpClient httpClient = HttpClientBuilder.create()
                .setConnectionManager(connManager)
                .build();

        HttpGet httpRequest = new HttpGet(url);

        try {
            //使用DefaultHttpClient类的execute方法发送HTTP GET请求，并返回HttpResponse对象。
            HttpResponse httpResponse = httpClient.execute(httpRequest);//其中HttpGet是HttpUriRequst的子类
            HttpEntity httpEntity = httpResponse.getEntity();
            result = EntityUtils.toString(httpEntity, "UTF-8");//取出应答字符串

        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 执行POST方法请求数据
     *
     * @param url 请求地址
     * @param xml 请求参数
     * @return 返回数据
     */
    public static String executeHttpPost(String url, String xml) {
        logger.debug("executeHttpPost and url:{}", url);
        String result = null;
        BasicHttpClientConnectionManager connManager = new BasicHttpClientConnectionManager(
                RegistryBuilder.<ConnectionSocketFactory>create()
                        .register("http", PlainConnectionSocketFactory.getSocketFactory())
                        .register("https", SSLConnectionSocketFactory.getSocketFactory())
                        .build(),
                null,
                null,
                null
        );

        HttpClient httpClient = HttpClientBuilder.create()
                .setConnectionManager(connManager)
                .build();
        HttpPost httpRequest = new HttpPost(url);

        try {
            httpRequest.setEntity(new StringEntity(xml, "UTF-8"));
            //使用DefaultHttpClient类的execute方法发送HTTP GET请求，并返回HttpResponse对象。
            HttpResponse httpResponse = httpClient.execute(httpRequest);//其中HttpGet是HttpUriRequst的子类
            HttpEntity httpEntity = httpResponse.getEntity();
            result = EntityUtils.toString(httpEntity, "UTF-8");//取出应答字符串

        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    /**
     * 获取随机字符串
     *
     * @return 随机字符串
     */
    public static String getRandomString() {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 32; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }

    /**
     * 获取时间戳
     *
     * @return 时间戳（秒数）
     */
    public static String getTimeStamp() {
        return String.valueOf(System.currentTimeMillis() / 1000L);
    }

    /**
     * 将xml字符串转换成map
     *
     * @param xml xml
     * @return Map
     */
    private static Map<String, String> parseMapFromXmlStr(String xml) {
        Map<String, String> map = new HashMap<>();
        Document doc;
        try {
            doc = DocumentHelper.parseText(xml); // 将字符串转为XML
            Element rootElt = doc.getRootElement(); // 获取根节点
            List<Element> list = rootElt.elements();//获取根节点下所有节点
            for (Element element : list) {  //遍历节点
                map.put(element.getName(), element.getText()); //节点的name为map的key，text为map的value
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    public static String doRefund(String mchId, String url, String data, String filepath) throws Exception {
        /**
         * 注意PKCS12证书 是从微信商户平台-》账户设置-》 API安全 中下载的
         */
        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        //P12文件目录 证书路径，这里需要你自己修改，linux下还是windows下的根路径
        //  String filepath = "C:\\Users\\DEL\\Desktop\\1601165214_20200723_cert\\apiclient_cert.p12";

        // 指定存放位置(有需求可以自定义)
        File file = downloadFile(filepath, "/data");
        FileInputStream instream = new FileInputStream(file);
        try {
            keyStore.load(instream, mchId.toCharArray());//这里写密码..默认是你的MCHID
        } finally {
            instream.close();
        }

        // Trust own CA and all self-signed certs
        SSLContext sslcontext = SSLContexts.custom()
                .loadKeyMaterial(keyStore, mchId.toCharArray())//这里也是写密码的
                .build();
        // Allow TLSv1 protocol only
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
                sslcontext,
                SSLConnectionSocketFactory.getDefaultHostnameVerifier());
        CloseableHttpClient httpclient = HttpClients.custom()
                .setSSLSocketFactory(sslsf)
                .build();
        try {
            HttpPost httpost = new HttpPost(url); // 设置响应头信息
            httpost.addHeader("Connection", "keep-alive");
            httpost.addHeader("Accept", "*/*");
            httpost.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            httpost.addHeader("Host", "api.mch.weixin.qq.com");
            httpost.addHeader("X-Requested-With", "XMLHttpRequest");
            httpost.addHeader("Cache-Control", "max-age=0");
            httpost.addHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0) ");
            httpost.setEntity(new StringEntity(data, "UTF-8"));
            CloseableHttpResponse response = httpclient.execute(httpost);
            try {
                HttpEntity entity = response.getEntity();

                String jsonStr = EntityUtils.toString(response.getEntity(), "UTF-8");
                EntityUtils.consume(entity);
                return jsonStr;
            } finally {
                response.close();
            }
        } finally {
            httpclient.close();
        }
    }

    /**
     * 微信退款
     *
     * @throws Exception
     */
    public static RefundResponse refundFunction(RefundRequest refundRequest, WechatSetting wechatSetting) throws Exception {
        String appid = wechatSetting.getAppId();
        String mch_id = wechatSetting.getMerchantNum();

        //获取订单金额（退款金额默认全部）
        String a = refundRequest.getMoney();
        String b = Double.valueOf(a) * 100 + "";
        int lastindex = b.indexOf(".");
        b = b.substring(0, lastindex);
        int c = Integer.parseInt(b);

        //随机字符串
        String noncestr = getRandomString();
        //退款单号
        String transNo = refundRequest.getTradeNo();

        String totalFee = c + "";
        //回调地址，换成自己的

        SortedMap<String, String> refund = new TreeMap<String, String>();
        refund.put("appid", appid);//公众账号ID
        refund.put("mch_id", mch_id);//商户号
        refund.put("nonce_str", noncestr);//随机字符串
        refund.put("transaction_id", transNo);//商户订单号和微信订单号二选一(我这里选的是商户订单号)
        refund.put("out_refund_no", transNo);//商户退款订单号
        refund.put("total_fee", totalFee);//订单金额
        refund.put("refund_desc", refundRequest.getRefundReason());//退款原因
        refund.put("refund_fee", totalFee);//退款金额
        refund.put("notify_url", wechatSetting.getPayCallback());//微信回调通知地址,可以使用自己定义也可以使用回调到指定的位置这里使用的是自定义可以在回调中添加一些功能
        String sign = createSign(refund, wechatSetting.getApiKey());
        refund.put("sign", sign);//签名

        //xml和map之间的转换
        String reuqestXml = getRequestXml(refund);

        String doRefund = doRefund(mch_id, "https://api.mch.weixin.qq.com/secapi/pay/refund", reuqestXml, wechatSetting.getFilepath());

        Map<String, Object> xmlMap = PayUtil.doXMLParse(doRefund);
        logger.debug("getRequestXml  and xml:{}", xmlMap);

        //状态码校验格式是否正确，Success是正确的
        if ("SUCCESS".equals(xmlMap.get("return_code"))) {
            if ("SUCCESS".equals(xmlMap.get("result_code"))) {
                Map<String, Object> packageParams = new HashMap<String, Object>();
                packageParams.put("result_code", xmlMap.get("result_code"));//业务返回结果
                packageParams.put("appid", xmlMap.get("appid"));//公众账号ID
                packageParams.put("mch_id", xmlMap.get("mch_id"));//商户号
                packageParams.put("nonce_str", xmlMap.get("nonce_str"));//随机字符串
                packageParams.put("sign", xmlMap.get("sign"));//签名
                packageParams.put("transaction_id", xmlMap.get("transaction_id"));//微信订单号
                packageParams.put("out_trade_no", xmlMap.get("out_trade_no"));//商户订单号
                packageParams.put("out_refund_no", xmlMap.get("out_refund_no"));//商户退款订单号
                packageParams.put("refund_id", xmlMap.get("refund_id"));//微信退款订单号
                packageParams.put("refund_fee", xmlMap.get("refund_fee"));//退款金额
                packageParams.put("total_fee", xmlMap.get("total_fee"));//标价金额
                packageParams.put("cash_fee", xmlMap.get("cash_fee"));//现金支付金额
                //退款申请成功
            } else if ("FAIL".equals(xmlMap.get("result_code"))) {
                //失败
                String err_code_des = (String) xmlMap.get("err_code_des");//返回信息
                return RefundResponse.build(err_code_des, err_code_des);
            }
        } else if ("FAIL".equals(xmlMap.get("return_code"))) {
            //失败
            String err_code_des = (String) xmlMap.get("err_code_des");//返回信息
            return RefundResponse.build(err_code_des, err_code_des);
        }
        return RefundResponse.build(10000 + "", xmlMap.get("result_code").toString());

    }

    /**
     * 说明：根据指定URL将文件下载到指定目标位置
     *
     * @param urlPath     下载路径
     * @param downloadDir 文件存放目录
     * @return 返回下载文件
     */
    @SuppressWarnings("finally")
    public static File downloadFile(String urlPath, String downloadDir) {
        File file = null;
        try {
            // 统一资源
            URL url = new URL(urlPath);
            // 连接类的父类，抽象类
            URLConnection urlConnection = url.openConnection();
            // http的连接类
            HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;
            //设置超时
            httpURLConnection.setConnectTimeout(1000 * 5);
            //设置请求方式，默认是GET
            httpURLConnection.setRequestMethod("GET");
            // 设置字符编码
            httpURLConnection.setRequestProperty("Charset", "UTF-8");
            // 打开到此 URL引用的资源的通信链接（如果尚未建立这样的连接）。
            httpURLConnection.connect();

            // 建立链接从请求中获取数据
            BufferedInputStream bin = new BufferedInputStream(httpURLConnection.getInputStream());
            // 指定文件名称(有需求可以自定义)
            String fileFullName = "2f5450b060cf27ba42b71f742d973.p12";
            // 指定存放位置(有需求可以自定义)
            String path = downloadDir + File.separatorChar + fileFullName;
            file = new File(path);
            // 校验文件夹目录是否存在，不存在就创建一个目录
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            OutputStream out = new FileOutputStream(file);
            int size = 0;
            int len = 0;
            byte[] buf = new byte[2048];
            while ((size = bin.read(buf)) != -1) {
                len += size;
                out.write(buf, 0, size);
            }
            // 关闭资源
            bin.close();
            out.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            return file;
        }
    }

    public static void main(String[] arg) {
        WechatSetting aliPaySetting = new WechatSetting();
        aliPaySetting.setAppId("wxd36292db0016c973");
        aliPaySetting.setPayCallback("https://www.wsfmall.com/api/mobile/wechatlogin");
        aliPaySetting.setAppSecret("de1f5d4297bd23bec9f8bfcc30579de9");
        aliPaySetting.setApiKey("GHTw3eowHArKTeQOA8wXKVhCKbM28rMy");
        aliPaySetting.setMerchantNum("1601165214");
        RefundRequest aliRefundTO = new RefundRequest();
        aliRefundTO.setRefundReason("ss");
        aliRefundTO.setMoney("0.01");
        aliRefundTO.setTradeNo("4200000582202007239063564051");
        try {
            refundFunction(aliRefundTO, aliPaySetting);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
