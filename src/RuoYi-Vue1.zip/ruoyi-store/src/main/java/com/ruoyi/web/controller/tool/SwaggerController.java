/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:SwaggerController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.tool;

import com.ruoyi.common.core.controller.BaseController;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * swagger 接口
 *
 * @author ruoyi
 */
@RestController
@RequestMapping("/tool/swagger")
public class SwaggerController extends BaseController {
    @PreAuthorize("@ss.hasPermi('tool:swagger:view')")
    @GetMapping()
    public String index() {
        return redirect("/swagger-ui.html");
    }
}
