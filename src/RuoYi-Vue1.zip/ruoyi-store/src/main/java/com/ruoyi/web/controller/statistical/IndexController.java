/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:IndexController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.statistical;


import com.ruoyi.order.domain.OmsLogisticsCompany;
import com.ruoyi.order.domain.OmsOrder;
import com.ruoyi.order.service.IOmsLogisticsCompanyService;
import com.ruoyi.order.service.IOmsOrderService;
import com.ruoyi.order.service.IOrderApiService;
import com.ruoyi.order.vo.QueryOrderCriteria;
import com.ruoyi.statistics.bean.IndexStatistics;
import com.ruoyi.statistics.service.StatisticsServiceApi;
import com.ruoyi.util.BaseResponse;
import com.ruoyi.util.PageHelper;
import com.ruoyi.web.utils.AdminLoginUtils;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author 魔金 2123957932
 * @date 2019-08-14 09:33
 * <p>
 * 首页控制器
 */
@RestController
@Api(description = "首页接口")
public class IndexController {


    /**
     * 注入统计服务
     */
    @Autowired
    private StatisticsServiceApi statisticsServiceApi;


    /**
     * 订单服务接口
     */
    @Autowired
    private IOmsOrderService orderService;

    /**
     * 注入订单混合api接口
     */
    @Autowired
    private IOrderApiService orderServiceApi;

    /**
     * 注入物流服务接口
     */
    @Autowired
    private IOmsLogisticsCompanyService logisticsCompanyService;


    /**
     * 查询系统首页统计
     *
     * @return 返回今日新增会员数，今日销售额，今日订单数，本周销售额，本周店铺销售量，本周新增会员数，本周店铺销售额（按日期分组），本周店铺销售量（按日期分组），本周新增会员数（按日期分组）
     */
    @GetMapping("/index/statistics")
    @ApiOperation(value = "查询系统首页统计", notes = "查询系统首页统计（需要认证）")
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回今日新增会员数，今日销售额，今日订单数，本周销售额，本周店铺销售量，本周新增会员数，本周店铺销售额（按日期分组），本周店铺销售量（按日期分组），本周新增会员数（按日期分组）", response = IndexStatistics.class)
    })
    public IndexStatistics queryIndexStatistics() {
        return statisticsServiceApi.queryIndexStatistics(AdminLoginUtils.getInstance().getStoreId());
    }


    /**
     * 首页查询订单
     *
     * @param pageHelper    分页帮助类
     * @param queryCriteria 查询条件
     * @return 返回订单信息
     */
    @GetMapping("/index/orders")
    @ApiOperation(value = "首页分页查询订单", notes = "首页分页查询订单（需要认证）")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "status", value = "订单状态 1:待付款  （用户刚下单）,2:代发货  （用户付完款 等待商城发货）,3:代收货  （商城已经发货 等待用户确认收货）, 4:已完成  （用户已经确认收货 订单结束）, 5:已关闭 （用户未付款前取消订单,退款成功,退货成功）,6:待评价,7:已评价"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回订单信息", response = OmsOrder.class)
    })
    public BaseResponse queryOrdersForIndex(@ApiIgnore PageHelper<OmsOrder> pageHelper, @ApiIgnore QueryOrderCriteria queryCriteria) {
        queryCriteria.setStoreId(AdminLoginUtils.getInstance().getStoreId());
        return BaseResponse.build(orderService.queryOrders(pageHelper, queryCriteria));
    }


    /**
     * 首页核销虚拟商品订单
     *
     * @param orderId      订单id
     * @param writeOffCode 兑换码
     * @return 0 失败   1 成功 -1 核销码错误
     */
    @PostMapping("/index/chargeoffvirtualorder/{orderId}/{writeOffCode}")
    @ApiOperation(value = "首页核销虚拟商品订单", notes = "首页核销虚拟商品订单（需要认证）")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", dataType = "long", name = "orderId", value = "订单id"),
            @ApiImplicitParam(paramType = "path", dataType = "String", name = "writeOffCode", value = "兑换码"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "0 失败   1 成功 -1 核销码错误", response = Integer.class)
    })
    public int chargeOffVirtualOrderForIndex(@PathVariable long orderId, @PathVariable String writeOffCode) {
        return orderServiceApi.writeOffVirtualOrder(orderId, AdminLoginUtils.getInstance().getStoreId(), writeOffCode, AdminLoginUtils.getInstance().getManagerName());
    }


    /**
     * 查询店铺使用的物流信息
     *
     * @return 返回订单物流模版信息
     */
    @GetMapping("/index/logisticscompanys")
    @ApiOperation(value = "查询店铺使用的物流信息", notes = "查询店铺使用的物流信息（需要认证）")
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回店铺使用的物流信息", response = OmsLogisticsCompany.class)
    })
    public java.util.List<OmsLogisticsCompany> queryLogisticsCompanys() {
        return logisticsCompanyService.queryStoreUseCompanys(AdminLoginUtils.getInstance().getStoreId());
    }

    /**
     * 首页发货
     *
     * @param id          订单id
     * @param waybillCode 运单号
     * @return 成功返回1 失败返回0 -2 订单正在申请退款 -1 订单号含有中文 -3 拼团未成功  -4 众筹还未成功 -5 拼团没成功 -6 物流公司不存在
     */
    @PostMapping("/index/deliver/{id}/{waybillCode}/{companyId}")
    @ApiOperation(value = "首页发货", notes = "首页发货（需要认证）")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", dataType = "long", name = "id", value = "订单id"),
            @ApiImplicitParam(paramType = "path", dataType = "String", name = "waybillCode", value = "运单号"),
            @ApiImplicitParam(paramType = "path", dataType = "long", name = "companyId", value = "物流公司id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "成功返回1 失败返回0 -2 订单正在申请退款 -1 订单号含有中文 -3 拼团未成功  -4 众筹还未成功 -5 拼团没成功 -6 物流公司不存在", response = Integer.class)
    })
    public int deliverOrderForIndex(@PathVariable long id, @PathVariable String waybillCode, @PathVariable long companyId) {
        return orderServiceApi.deliverOrder(id, AdminLoginUtils.getInstance().getStoreId(), waybillCode, AdminLoginUtils.getInstance().getManagerName(), companyId);
    }

}
