/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:PromotionalStatisticsController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.statistical;

import com.ruoyi.order.vo.MarketingStatistics;
import com.ruoyi.statistics.service.StatisticsServiceApi;
import com.ruoyi.web.utils.AdminLoginUtils;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author 魔金 2123957932
 * @date 2019-09-30 10:47
 * <p>
 * 促销统计控制器
 */
@RestController
@RequestMapping("/store")
@Api("促销统计接口")
public class PromotionalStatisticsController {


    /**
     * 注入统计服务
     */
    @Autowired
    private StatisticsServiceApi statisticsServiceApi;


    /**
     * 查询促销统计
     *
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return 查询促销统计
     */
    @GetMapping("/marketings")
    @ApiOperation(value = "查询促销统计", notes = "查询促销统计（需要认证）")
    @PreAuthorize("hasAuthority('marketings/querymarketingstatistics')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "查询促销统计", response = MarketingStatistics.class)
    })
    public MarketingStatistics queryMarketingStatistics(String startTime, String endTime) {
        return statisticsServiceApi.queryMarketingStatistics(startTime, endTime, AdminLoginUtils.getInstance().getStoreId());
    }


}
