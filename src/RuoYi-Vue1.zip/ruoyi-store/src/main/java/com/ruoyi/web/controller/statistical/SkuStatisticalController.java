/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:SkuStatisticalController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.statistical;


import com.ruoyi.order.vo.SkuSaleAmount;
import com.ruoyi.statistics.service.StatisticsServiceApi;
import com.ruoyi.util.BaseResponse;
import com.ruoyi.util.PageHelper;
import com.ruoyi.web.utils.AdminLoginUtils;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author 魔金 2123957932
 * @date 2019-09-25 15:11
 * <p>
 * 单品销售量统计接口
 */
@RestController
@RequestMapping("/store")
@Api("单品销售量统计控制器")
public class SkuStatisticalController {


    /**
     * 注入统计服务
     */
    @Autowired
    private StatisticsServiceApi statisticsServiceApi;

    /**
     * 分页查询单品销量
     *
     * @param pageHelper 分页帮助类
     * @param startTime  开始时间
     * @param endTime    结束时间
     * @return 单品销量集合
     */
    @GetMapping("/statistical/volume")
    @ApiOperation(value = "分页查询单品销量", notes = "分页查询单品销量(需要认证)")
    @PreAuthorize("hasAuthority('statistical/queryskusalevolume')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "单品销量集合", response = SkuSaleAmount.class)
    })
    public BaseResponse querySkuSaleVolume(@ApiIgnore PageHelper<SkuSaleAmount> pageHelper, @ApiIgnore String startTime, @ApiIgnore String endTime) {
        return BaseResponse.build(statisticsServiceApi.querySkuSaleVolume(pageHelper, startTime, endTime, AdminLoginUtils.getInstance().getStoreId()));
    }

    /**
     * 分页查询单品销售额
     *
     * @param pageHelper 分页帮助类
     * @param startTime  开始时间
     * @param endTime    结束时间
     * @return 单品销售额集合
     */
    @GetMapping("/statistical/amout")
    @ApiOperation(value = "分页查询单品销售额", notes = "分页查询单品销售额(需要认证)")
    @PreAuthorize("hasAuthority('statistical/queryskusaleamout')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "单品销售额集合", response = SkuSaleAmount.class)
    })
    public BaseResponse querySkuSaleAmout(@ApiIgnore PageHelper<SkuSaleAmount> pageHelper, @ApiIgnore String startTime, @ApiIgnore String endTime) {
        return BaseResponse.build(statisticsServiceApi.querySkuSaleAmount(pageHelper, startTime, endTime, AdminLoginUtils.getInstance().getStoreId()));
    }

}
