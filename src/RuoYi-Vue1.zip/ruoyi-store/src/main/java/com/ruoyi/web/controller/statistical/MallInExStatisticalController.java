/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:MallInExStatisticalController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.web.controller.statistical;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.member.vo.QueryCriteria;
import com.ruoyi.order.domain.OmsBillingRecords;
import com.ruoyi.order.service.IOmsBackOrderService;
import com.ruoyi.order.service.IOmsBillingRecordsService;
import com.ruoyi.order.service.IOmsOrderService;
import com.ruoyi.order.service.IOmsShoppingCartService;
import com.ruoyi.order.vo.OrderMessageCount;
import com.ruoyi.order.vo.QueryBillCriteria;
import com.ruoyi.store.service.AttentionStoreService;
import com.ruoyi.util.BaseResponse;
import com.ruoyi.util.PageHelper;
import com.ruoyi.web.utils.AdminLoginUtils;
import io.swagger.annotations.*;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;

/**
 * @author 魔金 2123957932
 * @date 2019-10-08 10:34
 * <p>
 * 商城收入支出统计控制器
 */
@RestController
@RequestMapping("/store")
@Api("商城收入支出统计接口")
public class MallInExStatisticalController {


    /**
     * 注入账单
     */
    @Autowired
    private IOmsBillingRecordsService billingRecordService;

    @Autowired
    private AttentionStoreService attentionStoreService;
    @Autowired
    private IOmsShoppingCartService shoppingCartService;
    /**
     * 退单服务接口
     */
    @Autowired
    private IOmsBackOrderService backOrderService;
    /**
     * 注入订单服务接口
     */
    @Autowired
    private IOmsOrderService orderService;

    /**
     * 订单统计
     *
     * @return 返回订单消息总数返回实体
     */
    @RequestMapping(value = "/order/count")
    @ResponseBody
    @ApiOperation(value = "订单统计", notes = "订单统计（需要认证）", httpMethod = "POST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回订单消息总数返回实体", response = OrderMessageCount.class)
    })
    public AjaxResult queryOrderMessageCount(HttpServletRequest request) {
        Long storeId = AdminLoginUtils.getInstance().getStoreId();
        int attendStoreNum = attentionStoreService.queryNumByStore(storeId);

        return AjaxResult.success(OrderMessageCount.build()
                .addToAttendStoreNum(attendStoreNum)
                .addToPayCount(orderService.toPayOrderCountByStore(storeId))
                .addToDeliverCount(orderService.toDeliverOrderCountByStore(storeId))
                .addToReceiptCount(orderService.toReceiptOrderCountByStore(storeId))
                .addToEvaluateCount(orderService.toEvaluateOrderCountByStore(storeId))
                .addBackOrderCount(backOrderService.queryInProcessBackOrderForStoreApp(storeId)));
    }

    /**
     * 分页查询店铺的收入支出记录
     *
     * @param pageHelper    分页帮助类
     * @param queryCriteria 查询条件
     * @return 返回收入支出记录
     */
    @GetMapping("/mallinex/record")
    @ApiOperation(value = "分页查询店铺的收入支出记录", notes = "分页查询店铺的收入支出记录（需要认证）")
    @PreAuthorize("hasAuthority('mallinex/queryincomeandexpensesrecords')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回收入支出记录", response = OmsBillingRecords.class)
    })
    public BaseResponse queryIncomeAndExpensesRecords(@ApiIgnore PageHelper<OmsBillingRecords> pageHelper, @ApiIgnore QueryBillCriteria queryCriteria) {
        queryCriteria.setStoreId(AdminLoginUtils.getInstance().getStoreId());
        return BaseResponse.build(billingRecordService.queryBillingRecords(pageHelper, queryCriteria));
    }


    /**
     * 查询店铺的收入和支出
     *
     * @param queryCriteria 查询条件
     * @return 返回店铺的收入和支出
     */
    @GetMapping("/mallinex")
    @ApiOperation(value = "查询店铺的收入和支出", notes = "查询店铺的收入和支出（需要认证）")
    @PreAuthorize("hasAuthority('mallinex/queryincomeandexpenses')")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "endTime", value = "结束时间"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回店铺的收入和支出", response = IncomeAndExpenses.class)
    })
    public IncomeAndExpenses queryIncomeAndExpenses(@ApiIgnore QueryCriteria queryCriteria) {
        return new IncomeAndExpenses(billingRecordService.queryStoreInCome(queryCriteria.getStartTime(), queryCriteria.getEndTime(), AdminLoginUtils.getInstance().getStoreId()),
                billingRecordService.queryStoreExpenses(queryCriteria.getStartTime(), queryCriteria.getEndTime(), AdminLoginUtils.getInstance().getStoreId()));
    }


    /**
     * 店铺收入支出
     */
    @Data
    @ApiModel(description = "店铺收入支出")
    private static class IncomeAndExpenses {

        /**
         * 收入
         */
        @ApiModelProperty(value = "收入")
        private BigDecimal inCome;

        /**
         * 支出
         */
        @ApiModelProperty(value = "支出")
        private BigDecimal expenses;

        public IncomeAndExpenses(BigDecimal inCome, BigDecimal expenses) {
            this.inCome = inCome;
            this.expenses = expenses;
        }

    }


}
