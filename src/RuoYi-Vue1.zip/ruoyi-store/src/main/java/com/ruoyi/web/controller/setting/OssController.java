/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:OssController.java
 * Date:2020/09/13 08:43:13
 */

package com.ruoyi.web.controller.setting;


import com.ruoyi.common.utils.bean.OssSetting;
import com.ruoyi.setting.service.OssService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.annotation.Resource;

/**
 * Oss相关操作接口
 * https://github.com/shenzhuan/mallplus on 2018/4/26.
 */
@Slf4j
@RestController
@Api(tags = "OssController", description = "Oss管理")
@RequestMapping("/store/oss")
public class OssController {
    @Resource
    private OssService ossService;

    /**
     * 上传图片
     *
     * @return 返回图片在minio的地址
     * @throws Exception
     */
    @PostMapping("uploadToMinio")
    @ApiOperation(value = "上传图片", notes = "上传图片（不需要认证）")
    public String uploadToMinio(MultipartHttpServletRequest request, String name) throws Exception {
        if (StringUtils.isEmpty(name)) {
            name = "image";
        }
        OssSetting ossSetting = ossService.queryOssSetting();
        int i = Integer.parseInt(ossSetting.getPrefix()); //1 minio 2 qiniu 3 oss 4 qq云
        if (i == 1) {
            return ossService.uploadToMinio(request.getFile(name), ossSetting);
        } else if (i == 2) {
            return ossService.uploadToQiNiu(request.getFile(name), name, ossSetting);
        } else if (i == 3) {
            return ossService.uploadToOSSYun(request.getFile(name), name, ossSetting);
        } else if (i == 4) {
            return ossService.uploadToQqOSSYun(request.getFile(name), name, ossSetting);
        }
        return null;
    }

}
