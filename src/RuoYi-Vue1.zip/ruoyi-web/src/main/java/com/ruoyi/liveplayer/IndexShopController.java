package com.ruoyi.liveplayer;


import com.ruoyi.appletsutil.AppletsLoginUtils;
import com.ruoyi.cms.service.ArticleListService;
import com.ruoyi.common.annotation.UnAuth;
import com.ruoyi.common.enums.StatusEnum;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.goods.domain.PmsBrand;
import com.ruoyi.goods.domain.PmsCategory;
import com.ruoyi.goods.domain.PmsGoods;
import com.ruoyi.goods.service.*;
import com.ruoyi.goods.vo.SpuDetailItem;
import com.ruoyi.goods.vo.SpuSearchCondition;
import com.ruoyi.integral.service.CustomerPointService;
import com.ruoyi.marketing.domain.PanicBuySku;
import com.ruoyi.marketing.service.CouponService;
import com.ruoyi.marketing.service.MarketingServiceApi;
import com.ruoyi.member.domain.UmsMember;
import com.ruoyi.member.service.IUmsMemberAddressService;
import com.ruoyi.member.service.IUmsMemberService;
import com.ruoyi.member.service.LoginService;
import com.ruoyi.member.vo.LoginParams;
import com.ruoyi.order.service.IOmsOrderAttrService;
import com.ruoyi.order.service.IOmsOrderService;
import com.ruoyi.order.service.IOmsShoppingCartService;
import com.ruoyi.sms.domain.SmsHomeAdvertise;
import com.ruoyi.sms.domain.SmsHomeNewProduct;
import com.ruoyi.sms.domain.SmsHomeRecommendProduct;
import com.ruoyi.sms.service.ISmsHomeAdvertiseService;
import com.ruoyi.sms.service.ISmsHomeBrandService;
import com.ruoyi.sms.service.ISmsHomeNewProductService;
import com.ruoyi.sms.service.ISmsHomeRecommendProductService;
import com.ruoyi.store.domain.TStoreInfo;
import com.ruoyi.store.service.ITStoreInfoService;
import com.ruoyi.system.domain.SysNotice;
import com.ruoyi.system.service.ISysNoticeService;
import com.ruoyi.util.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author stylefeng
 * @since 2017-05-17
 */
@Controller
@RequestMapping("web")
public class IndexShopController {
    private String PREFIX = "web/";

    @Autowired
    private ArticleListService articleService;
    @Autowired
    private IPmsBrandService tBrandService;
    @Autowired
    private IPmsTypeService tGoodsTypeService;
    @Autowired
    private IPmsGoodsService tGoodsService;
    @Autowired
    private IPmsCategoryService tGoodsClassService;
    @Autowired
    private ITStoreInfoService tStoreService;
    @Autowired
    private ISmsHomeAdvertiseService bannerService;
    @Autowired
    private CouponService couponService;

    @Autowired
    private IOmsShoppingCartService tCartService;

    @Autowired
    private IUmsMemberService tMemberService;

    @Autowired
    private IUmsMemberAddressService addressService;
    @Autowired
    private IPmsAttentionService favoriteService;
    @Autowired
    private IOmsOrderService orderService;
    @Autowired
    private IOmsOrderAttrService tGoodSorderService;

    @Resource
    private ISmsHomeNewProductService homeNewProductService;
    @Resource
    private ISmsHomeRecommendProductService homeRecommendProductService;
    @Resource
    private ISmsHomeBrandService homeBrandService;
    /**
     * 注入促销api接口
     */
    @Autowired
    private MarketingServiceApi marketingServiceApi;

    /**
     * 商品服务api接口
     */
    @Autowired
    private ISpuApiService ISpuApiService;
    /**
     * 注入会员积分服务
     */
    @Autowired
    private CustomerPointService customerPointService;
    @Autowired
    private ISysNoticeService sysNoticeService;
    /**
     * 注入会员服务接口
     */
    @Autowired
    private IUmsMemberService customerService;
    /**
     * 注入登录处理service
     */
    @Resource(name = "loginService")
    private LoginService loginService;

    /**
     * 跳转到登陆
     */
    @UnAuth
    @RequestMapping("login")
    public String login(Model model, HttpServletRequest req) {
        try {

            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Login";
    }

    @UnAuth
    @RequestMapping("doLogin")
    public String doLogin(Model model, HttpServletRequest req) {
        try {
            String username = req.getParameter("username");
            String password = req.getParameter("password");
            LoginParams loginParams = new LoginParams();
            loginParams.setPassword(password);
            loginParams.setMobile(username);
            UmsMember customer = customerService.queryCustomerByName(loginParams.getMobile(), loginParams.getStoreId());
            req.getSession().setAttribute("user", customer);
            loginService.login(loginParams);
            // index(model);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/web/index";
    }

    /**
     * 跳转到注册
     */
    @UnAuth
    @RequestMapping("reg")
    public String reg(Model model, HttpServletRequest req) {
        try {

            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "reg";
    }

    /**
     * 跳转到首页
     */
    @UnAuth
    @RequestMapping("index")
    public String index(Model model) {
        try {
            List<PmsCategory> goodsClassList = tGoodsClassService.querySpuCategoryByParentId(1, 0);
            for (PmsCategory gc : goodsClassList) {
                List<PmsCategory> childs = tGoodsClassService.querySpuCategoryByParentId(gc.getId(), 0);
                if (childs != null && childs.size() > 0) {
                    gc.setChildCateGory(childs);
                    for (PmsCategory gc1 : childs) {
                        List<PmsCategory> childs1 = tGoodsClassService.querySpuCategoryByParentId(gc1.getId(), 0);
                        if (childs != null && childs.size() > 0) {
                            gc1.setChildCateGory(childs1);
                        } else {
                            gc1.setChildCateGory(null);
                        }
                    }
                } else {
                    gc.setChildCateGory(null);
                }

            }
            model.addAttribute("goodsClassList", goodsClassList);

            PageHelper<PmsGoods> pageHelper = new PageHelper<>();
            pageHelper.setPageSize(4);
            SpuSearchCondition spuSearchCondition = new SpuSearchCondition();
            spuSearchCondition.setShelvesStatus("1");
            spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
            // 1时间倒序 2 价格倒序 3 价格升序 4 销量倒序 5 点击倒序
            spuSearchCondition.setOrderBys(4);
            model.addAttribute("commList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));

            /*spuSearchCondition.setOrderBys(5);
            pageHelper.setPageSize(6);
            model.addAttribute("hitList", tGoodsService.querySimpleSpus(pageHelper,spuSearchCondition));

            spuSearchCondition.setOrderBys(1);
            pageHelper.setPageSize(8);
            model.addAttribute("xinpinList", tGoodsService.querySimpleSpus(pageHelper,spuSearchCondition));

            com.github.pagehelper.PageHelper.startPage(1, 16, "id");
            model.addAttribute("brandList", tBrandService.selectPmsBrandList(new PmsBrand()));*/

            SmsHomeRecommendProduct qRecom = new SmsHomeRecommendProduct();
            qRecom.setStoreId(0L);
            model.addAttribute("smsHomeRecommendList", homeRecommendProductService.selectSmsHomeRecommendProductList(qRecom));

            SmsHomeNewProduct qNewPr = new SmsHomeNewProduct();
            qNewPr.setStoreId(0L);
            model.addAttribute("smsHomeNewProductList", homeNewProductService.selectSmsHomeNewProductList(qNewPr));

            SmsHomeAdvertise advertise = new SmsHomeAdvertise();
            advertise.setStatus(0);
            advertise.setStoreId(0L);
            List<SmsHomeAdvertise> homeAdvertiseList = bannerService.selectSmsHomeAdvertiseList(advertise);
            List<SmsHomeAdvertise> bannerList = new ArrayList<>();
            for (SmsHomeAdvertise homeAdvertise : homeAdvertiseList) {
                // 1 轮播图 2 新品推荐广告 3 人气推荐广告 4热门推荐广告 5 分类广告
                if (homeAdvertise.getOrderCount() == 1) {
                    bannerList.add(homeAdvertise);
                }
                if (homeAdvertise.getOrderCount() == 2) {
                    model.addAttribute("newBannerAdv", homeAdvertise);
                }
                if (homeAdvertise.getOrderCount() == 3) {
                    model.addAttribute("saleBannerAdv", homeAdvertise);
                }
                if (homeAdvertise.getOrderCount() == 3) {
                    model.addAttribute("hotBannerAdv", homeAdvertise);
                }
            }
            model.addAttribute("bannerList", bannerList);

            SysNotice sysNotice = new SysNotice();
            sysNotice.setStatus("0");
            model.addAttribute("noticeList", sysNoticeService.selectNoticeList(sysNotice));
            PageHelper<PanicBuySku> pageHelperSku = new PageHelper<>();
            pageHelperSku.setPageSize(5);
            model.addAttribute("panicBuyList", marketingServiceApi.queryStorePanicBuyListForSite(pageHelperSku, 0L).getList());
            TStoreInfo storeInfo = new TStoreInfo();
            com.github.pagehelper.PageHelper.startPage(1, 100, "id");
            List<TStoreInfo> floorList = tStoreService.selectTStoreInfoList(storeInfo);
            List<TStoreInfo> newfloorList = new ArrayList<>();
            for (TStoreInfo floorDO : floorList) {
                PmsGoods qGoods = new PmsGoods();
                qGoods.setStoreId(floorDO.getId());
                qGoods.setShelvesStatus("1");
                qGoods.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
                com.github.pagehelper.PageHelper.startPage(1, 6, "id");
                floorDO.setGoodsList(tGoodsService.selectPmsGoodsList(qGoods));
                if (floorDO.getGoodsList() != null && floorDO.getGoodsList().size() == 6) {
                    PmsBrand qBrand = new PmsBrand();
                    qBrand.setStoreId(floorDO.getId());
                    floorDO.setBrandList(tBrandService.selectPmsBrandList(qBrand));

                    if (StringUtils.isNotEmpty(floorDO.getBusRoutes())) {
                        floorDO.setCategoryList(tGoodsClassService.queryCategoryByParentId(Long.valueOf(floorDO.getBusRoutes())));
                    }
                    qRecom = new SmsHomeRecommendProduct();
                    qRecom.setStoreId(floorDO.getId());
                    floorDO.setHomeRecommendProductList(homeRecommendProductService.selectSmsHomeRecommendProductList(qRecom));

                    qNewPr = new SmsHomeNewProduct();
                    qNewPr.setStoreId(floorDO.getId());
                    floorDO.setHomeNewProductList(homeNewProductService.selectSmsHomeNewProductList(qNewPr));
                } else {
                    continue;
                }
                newfloorList.add(floorDO);

            }
            model.addAttribute("floorList", newfloorList);

            model.addAttribute("home", "1");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Index";
    }


    /**
     * 跳转到品牌下得商品
     */
    @UnAuth
    @RequestMapping("BrandGoodsList")
    public String BrandGoodsList(Model model, HttpServletRequest req) {
        try {
            PageHelper<PmsGoods> commList = getPmsGoodsPageHelper(4);
            model.addAttribute("commList", commList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "BrandGoodsList";
    }

    /**
     * 跳转到品牌列表
     */
    @UnAuth
    @RequestMapping("BrandList")
    public String BrandList(Model model, HttpServletRequest req) {
        try {
            PageHelper<PmsGoods> commList = getPmsGoodsPageHelper(4);
            model.addAttribute("commList", commList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "BrandList";
    }

    /**
     * 跳转到特卖
     */
    @UnAuth
    @RequestMapping("Sell")
    public String Sell(Model model, HttpServletRequest req) {
        try {
            PageHelper<PmsGoods> commList = getPmsGoodsPageHelper(4);
            model.addAttribute("commList", commList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Sell";
    }

    /**
     * 跳转到商品详情
     */
    @UnAuth
    @RequestMapping("/SellDetails/{id}")
    public String SellDetailsDetail(@PathVariable Long id, Model model, HttpServletRequest request, HttpServletResponse resp) {
        long customerId = AppletsLoginUtils.getInstance().getSessionCustomerId(request);
        model.addAttribute("goods", ISpuApiService.queryGoodsDetail(id, null, customerId, SpuDetailItem.COUPON, SpuDetailItem.FOLLOW, SpuDetailItem.STORE_SCORE, SpuDetailItem.MOBILE_DESC, SpuDetailItem.SAME_TYPE).orElseGet(() -> null));
        return PREFIX + "SellDetails";
    }

    /**
     * 跳转到商品详情
     */
    @UnAuth
    @RequestMapping("/goodsDetail/{id}")
    public String goodsDetail(@PathVariable Long id, Model model, HttpServletRequest request, HttpServletResponse resp) {
        long customerId = AppletsLoginUtils.getInstance().getSessionCustomerId(request);
        model.addAttribute("goods", ISpuApiService.queryGoodsDetail(id, null, customerId, SpuDetailItem.COUPON, SpuDetailItem.FOLLOW, SpuDetailItem.STORE_SCORE, SpuDetailItem.MOBILE_DESC, SpuDetailItem.SAME_TYPE, SpuDetailItem.SKU_COMMENT_List).orElseGet(() -> null));
        return PREFIX + "Product";
    }


    private PageHelper<PmsGoods> getPmsGoodsPageHelper(int i) {
        PageHelper<PmsGoods> pageHelper = new PageHelper<>();
        pageHelper.setPageSize(4);
        SpuSearchCondition spuSearchCondition = new SpuSearchCondition();
        spuSearchCondition.setShelvesStatus("1");
        spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
        spuSearchCondition.setOrderBys(i);
        return tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition);
    }

}
