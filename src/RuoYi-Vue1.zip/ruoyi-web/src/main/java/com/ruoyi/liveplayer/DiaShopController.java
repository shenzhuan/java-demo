package com.ruoyi.liveplayer;


import com.ruoyi.appletsutil.AppletsLoginUtils;
import com.ruoyi.cms.service.ArticleListService;
import com.ruoyi.common.annotation.UnAuth;
import com.ruoyi.common.enums.StatusEnum;
import com.ruoyi.goods.domain.PmsBrand;
import com.ruoyi.goods.domain.PmsCategory;
import com.ruoyi.goods.domain.PmsGoods;
import com.ruoyi.goods.service.*;
import com.ruoyi.goods.vo.SpuDetailItem;
import com.ruoyi.goods.vo.SpuSearchCondition;
import com.ruoyi.integral.domain.CustomerPoint;
import com.ruoyi.integral.service.CustomerPointService;
import com.ruoyi.marketing.domain.CouponCode;
import com.ruoyi.marketing.service.CouponService;
import com.ruoyi.member.service.IUmsMemberAddressService;
import com.ruoyi.member.service.IUmsMemberService;
import com.ruoyi.order.service.IOmsOrderAttrService;
import com.ruoyi.order.service.IOmsOrderService;
import com.ruoyi.order.service.IOmsShoppingCartService;
import com.ruoyi.sms.domain.SmsHomeAdvertise;
import com.ruoyi.sms.domain.SmsHomeNewProduct;
import com.ruoyi.sms.domain.SmsHomeRecommendProduct;
import com.ruoyi.sms.service.ISmsHomeAdvertiseService;
import com.ruoyi.sms.service.ISmsHomeBrandService;
import com.ruoyi.sms.service.ISmsHomeNewProductService;
import com.ruoyi.sms.service.ISmsHomeRecommendProductService;
import com.ruoyi.store.domain.TStoreInfo;
import com.ruoyi.store.service.ITStoreInfoService;
import com.ruoyi.util.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import springfox.documentation.annotations.ApiIgnore;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author stylefeng
 * @since 2017-05-17
 */
@Controller
@RequestMapping("diaShop")
public class DiaShopController {
    String path = "F:/zscat-b2b2c/";
    private String PREFIX = "diaShop/";
    @Autowired
    private ArticleListService articleService;
    @Autowired
    private IPmsBrandService tBrandService;
    @Autowired
    private IPmsTypeService tGoodsTypeService;
    @Autowired
    private IPmsGoodsService tGoodsService;
    @Autowired
    private IPmsCategoryService tGoodsClassService;
    @Autowired
    private ITStoreInfoService tStoreService;
    @Autowired
    private ISmsHomeAdvertiseService bannerService;
    @Autowired
    private CouponService couponService;

    @Autowired
    private IOmsShoppingCartService tCartService;

    @Autowired
    private IUmsMemberService tMemberService;

    @Autowired
    private IUmsMemberAddressService addressService;
    @Autowired
    private IPmsAttentionService favoriteService;
    @Autowired
    private IOmsOrderService orderService;
    @Autowired
    private IOmsOrderAttrService tGoodSorderService;

    @Resource
    private ISmsHomeNewProductService homeNewProductService;
    @Resource
    private ISmsHomeRecommendProductService homeRecommendProductService;
    @Resource
    private ISmsHomeBrandService homeBrandService;
    /**
     * 商品服务api接口
     */
    @Autowired
    private ISpuApiService ISpuApiService;
    /**
     * 注入会员积分服务
     */
    @Autowired
    private CustomerPointService customerPointService;


    /**
     * 跳转到首页
     */
    @UnAuth
    @RequestMapping("index")
    public String index(Model model) {
        try {
            List<PmsCategory> goodsClassList = tGoodsClassService.querySpuCategoryByParentId(1, 0);
            for (PmsCategory gc : goodsClassList) {
                List<PmsCategory> childs = tGoodsClassService.querySpuCategoryByParentId(gc.getId(), 0);
                if (childs != null && childs.size() > 0) {
                    gc.setChildCateGory(childs);
                    for (PmsCategory gc1 : childs) {
                        List<PmsCategory> childs1 = tGoodsClassService.querySpuCategoryByParentId(gc1.getId(), 0);
                        if (childs != null && childs.size() > 0) {
                            gc1.setChildCateGory(childs1);
                        } else {
                            gc1.setChildCateGory(null);
                        }
                    }
                } else {
                    gc.setChildCateGory(null);
                }

            }
            model.addAttribute("goodsClassList", goodsClassList);

            PageHelper<PmsGoods> pageHelper = new PageHelper<>();
            pageHelper.setPageSize(4);
            SpuSearchCondition spuSearchCondition = new SpuSearchCondition();
            spuSearchCondition.setShelvesStatus("1");
            spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
            spuSearchCondition.setOrderBys(4);
            model.addAttribute("commList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            spuSearchCondition.setOrderBys(5);
            pageHelper.setPageSize(6);
            model.addAttribute("hitList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            spuSearchCondition.setOrderBys(1);
            pageHelper.setPageSize(8);
            model.addAttribute("xinpinList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            com.github.pagehelper.PageHelper.startPage(1, 16, "id");
            model.addAttribute("brandList", tBrandService.selectPmsBrandList(new PmsBrand()));
            SmsHomeAdvertise advertise = new SmsHomeAdvertise();
            advertise.setStatus(0);
            model.addAttribute("bannerList", bannerService.selectSmsHomeAdvertiseList(advertise));

            TStoreInfo storeInfo = new TStoreInfo();
            com.github.pagehelper.PageHelper.startPage(1, 4, "id");
            List<TStoreInfo> floorList = tStoreService.selectTStoreInfoList(storeInfo);

            int i = 0;
            for (TStoreInfo floorDO : floorList) {
                PmsGoods qGoods = new PmsGoods();
                qGoods.setStoreId(floorDO.getId());
                floorDO.setGoodsList(tGoodsService.selectPmsGoodsList(qGoods));

                PmsBrand qBrand = new PmsBrand();
                qBrand.setStoreId(floorDO.getId());
                floorDO.setBrandList(tBrandService.selectPmsBrandList(qBrand));

                SmsHomeRecommendProduct qRecom = new SmsHomeRecommendProduct();
                qBrand.setStoreId(floorDO.getId());
                floorDO.setHomeRecommendProductList(homeRecommendProductService.selectSmsHomeRecommendProductList(qRecom));

                SmsHomeNewProduct qNewPr = new SmsHomeNewProduct();
                qNewPr.setStoreId(floorDO.getId());
                floorDO.setHomeNewProductList(homeNewProductService.selectSmsHomeNewProductList(qNewPr));

            }
            model.addAttribute("floorList", floorList);

            model.addAttribute("home", "1");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "index";
    }

    /**
     * 跳转到搜索
     */
    @UnAuth
    @RequestMapping("search")
    public String search(Model model, HttpServletRequest req) {
        try {
            Map<String, Object> param = new HashMap<>();
            String keyword = req.getParameter("keyword");
            if (keyword != null) {
                PageHelper<PmsGoods> pageHelper = new PageHelper<>();
                pageHelper.setPageSize(4);
                SpuSearchCondition spuSearchCondition = new SpuSearchCondition();
                spuSearchCondition.setShelvesStatus("1");
                spuSearchCondition.setName(keyword);
                spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
                spuSearchCondition.setOrderBys(4);
                model.addAttribute("data", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            } else {
                model.addAttribute("data", new ArrayList<>());
            }

            PageHelper<PmsGoods> pageHelper = new PageHelper<>();
            pageHelper.setPageSize(4);
            SpuSearchCondition spuSearchCondition = new SpuSearchCondition();
            spuSearchCondition.setShelvesStatus("1");
            spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
            spuSearchCondition.setOrderBys(4);
            model.addAttribute("commList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            spuSearchCondition.setOrderBys(5);
            pageHelper.setPageSize(6);
            model.addAttribute("hitList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            spuSearchCondition.setOrderBys(1);
            pageHelper.setPageSize(8);
            model.addAttribute("xinpinList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            com.github.pagehelper.PageHelper.startPage(1, 16, "id");
            model.addAttribute("brandList", tBrandService.selectPmsBrandList(new PmsBrand()));
            SmsHomeAdvertise advertise = new SmsHomeAdvertise();
            advertise.setStatus(0);
            model.addAttribute("bannerList", bannerService.selectSmsHomeAdvertiseList(advertise));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "search";
    }

    /**
     * 跳转到团购
     */
    @UnAuth
    @RequestMapping("groupList")
    public String groupList(Model model, HttpServletRequest req) {
        try {
            PageHelper<PmsGoods> commList = getPmsGoodsPageHelper(4);
            model.addAttribute("commList", commList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "groupList";
    }

    /**
     * 跳转到团购
     */
    @UnAuth
    @RequestMapping("daySee")
    public String daySee(Model model, HttpServletRequest req) {
        try {
            PageHelper<PmsGoods> pageHelper = new PageHelper<>();
            pageHelper.setPageSize(4);
            SpuSearchCondition spuSearchCondition = new SpuSearchCondition();
            spuSearchCondition.setShelvesStatus("1");

            spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
            spuSearchCondition.setOrderBys(4);
            model.addAttribute("commList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "daySee";
    }

    /**
     * 跳转到去反馈
     */
    @UnAuth
    @RequestMapping("Feedback")
    public String Feedback(Model model, HttpServletRequest req) {
        try {

        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Feedback";
    }

    /**
     * 跳转到商品详情
     */
    @UnAuth
    @RequestMapping("/goodsDetail/{id}")
    public String goodsDetail(@PathVariable Long id, Model model, HttpServletRequest request, HttpServletResponse resp) {
        long customerId = AppletsLoginUtils.getInstance().getCustomerId(request);
        model.addAttribute("goods", ISpuApiService.queryGoodsDetail(id, null, customerId, SpuDetailItem.COUPON, SpuDetailItem.FOLLOW, SpuDetailItem.STORE_SCORE, SpuDetailItem.MOBILE_DESC, SpuDetailItem.SAME_TYPE).orElseGet(() -> null));
        return PREFIX + "goodsDetail";
    }

    /**
     * 跳转到积分商城
     */
    @UnAuth
    @RequestMapping("jfindex")
    public String jifen(Model model, HttpServletRequest request, @ApiIgnore PageHelper<CustomerPoint> pageHelper, String type) {
        try {

            model.addAttribute("jfList", customerPointService.queryCustomerPoints(pageHelper, AppletsLoginUtils.getInstance().getCustomerId(request), null, type));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "jfindex";
    }

    /**
     * 跳转到商品详情
     */
    @UnAuth
    @RequestMapping("/jfDetail/{id}")
    public String jfDetail(@PathVariable Long id, Model model) {


        return PREFIX + "jfDetail";
    }

    /**
     * 跳转到优惠劵
     */
    @UnAuth
    @RequestMapping("youhuijuan")
    public String youhuijuan(Model model, HttpServletRequest request, @ApiIgnore PageHelper<CouponCode> pageHelper, String status) {
        try {
            model.addAttribute("couponList", couponService.queryCouponCodeByCustomerId(pageHelper, AppletsLoginUtils.getInstance().getCustomerId(request), status));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "youhuijuan";
    }

    /**
     * 跳转到文章详情
     */
    @UnAuth
    @RequestMapping("/articleDetail/{id}")
    public String articleDetail(@PathVariable Long id, Model model) {

        model.addAttribute("article", articleService.queryArticleById(id));
        PageHelper<PmsGoods> commList = getPmsGoodsPageHelper(4);
        model.addAttribute("commList", commList);
        return PREFIX + "article";
    }

    /**
     * 跳转到店铺详情
     */
    @UnAuth
    @RequestMapping("/store/{id}")
    public String store(@PathVariable Long id, Model model) {
        TStoreInfo store = tStoreService.selectTStoreInfoById(id);
        model.addAttribute("store", store);

        return PREFIX + "store";
    }

    /**
     * 根据品牌查询商品
     */
    @UnAuth
    @RequestMapping("/goodsByBrand/{id}")
    public String brand(@PathVariable Long id, Model model) {
        try {
            PageHelper<PmsGoods> pageHelper = new PageHelper<>();
            pageHelper.setPageSize(4);
            SpuSearchCondition spuSearchCondition = new SpuSearchCondition();
            spuSearchCondition.setShelvesStatus("1");
            spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
            spuSearchCondition.setOrderBys(4);
            model.addAttribute("commList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            spuSearchCondition.setOrderBys(5);
            pageHelper.setPageSize(6);
            model.addAttribute("hitList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            spuSearchCondition.setOrderBys(1);
            pageHelper.setPageSize(8);
            model.addAttribute("xinpinList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            com.github.pagehelper.PageHelper.startPage(1, 16, "id");
            model.addAttribute("brandList", tBrandService.selectPmsBrandList(new PmsBrand()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "goodsList";
    }

    /**
     * 根据品牌查询商品
     */
    @UnAuth
    @RequestMapping("/goodsByClass/{id}")
    public String goodsByClass(@PathVariable Long id, Model model) {
        try {
            PageHelper<PmsGoods> pageHelper = new PageHelper<>();
            pageHelper.setPageSize(4);
            SpuSearchCondition spuSearchCondition = new SpuSearchCondition();
            spuSearchCondition.setShelvesStatus("1");
            spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
            spuSearchCondition.setOrderBys(4);
            model.addAttribute("commList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            spuSearchCondition.setOrderBys(5);
            pageHelper.setPageSize(6);
            model.addAttribute("hitList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            spuSearchCondition.setOrderBys(1);
            pageHelper.setPageSize(8);
            model.addAttribute("xinpinList", tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
            com.github.pagehelper.PageHelper.startPage(1, 16, "id");
            model.addAttribute("brandList", tBrandService.selectPmsBrandList(new PmsBrand()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "goodsList";
    }


    /**
     * 跳转到登录页面
     *
     * @return
     */
    @UnAuth
    @RequestMapping(value = "login", method = RequestMethod.GET)
    public String toLogin(HttpServletRequest request) {
        if (AppletsLoginUtils.getInstance().getCustomer(request) != null) {
            return "redirect:/diaShop/index";
        }
        return PREFIX + "login";
    }


    /**
     * 跳转到登录页面
     *
     * @return
     */
    @UnAuth
    @RequestMapping(value = "reg", method = RequestMethod.GET)
    public String reg(HttpServletRequest request) {
        if (AppletsLoginUtils.getInstance().getCustomer(request) != null) {
            return "redirect:/diaShop/index";
        }
        return PREFIX + "zhuce";
    }


    /**
     * 用户退出
     *
     * @return 跳转到登录页面
     */
    @UnAuth
    @RequestMapping("logout")
    public String logout(HttpServletRequest request) {

        return "redirect:/diaShop/index";
    }

    @UnAuth
    @RequestMapping(value = "/fileUpload", method = RequestMethod.POST)
    @ResponseBody
    public String uploadFileHandlerStore(@RequestParam("file") MultipartFile file,
                                         HttpServletRequest request) throws IOException {
        return fileUpload(file, request, "upload/store/");
    }

    @UnAuth
    @RequestMapping(value = "/fileUpload1", method = RequestMethod.POST)
    @ResponseBody
    public String uploadFileHandlerGoods(@RequestParam("file") MultipartFile file,
                                         HttpServletRequest request) throws IOException {
        return fileUpload(file, request, "upload/project");
    }

    private String fileUpload(@RequestParam("file") MultipartFile file, HttpServletRequest request, String path) throws IOException {
        if (!file.isEmpty()) {
            InputStream in = null;
            OutputStream out = null;
            try {
                // String filePath = request.getSession().getServletContext().getRealPath("/") +path1 ;
                String pictureSaveFilePath = request.getRealPath(path);
                String filePath = pictureSaveFilePath;
                File dir = new File(filePath);
                if (!dir.exists())
                    dir.mkdirs();
                File serverFile = new File(dir.getAbsolutePath() + File.separator + file.getOriginalFilename());
                in = file.getInputStream();
                out = new FileOutputStream(serverFile);
                byte[] b = new byte[1024];
                int len = 0;
                while ((len = in.read(b)) > 0) {
                    out.write(b, 0, len);
                }
                System.out.println("file:" + serverFile);
                out.close();
                in.close();
                return file.getOriginalFilename();

            } catch (Exception e) {
                return file.getOriginalFilename();
            } finally {
                if (out != null) {
                    out.close();
                    out = null;
                }

                if (in != null) {
                    in.close();
                    in = null;
                }
            }
        } else {
            return file.getOriginalFilename();
        }
    }

    /**
     * 通过菜单类别
     *
     * @param
     * @return
     * @throws Exception
     */
    @UnAuth
    @RequestMapping("/goodsList")
    public ModelAndView goodsList(HttpServletRequest request, HttpServletResponse resp) throws Exception {
        ModelAndView mav = new ModelAndView();

        PageHelper<PmsGoods> commList = getPmsGoodsPageHelper(4);
        mav.addObject("commList", commList);
        mav.setViewName("web/goodsList");
        return mav;
    }

    private PageHelper<PmsGoods> getPmsGoodsPageHelper(int i) {
        PageHelper<PmsGoods> pageHelper = new PageHelper<>();
        pageHelper.setPageSize(4);
        SpuSearchCondition spuSearchCondition = new SpuSearchCondition();
        spuSearchCondition.setShelvesStatus("1");
        spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
        spuSearchCondition.setOrderBys(i);
        return tGoodsService.querySimpleSpus(pageHelper, spuSearchCondition);
    }

    /**
     * 通过菜单类别
     *
     * @param
     * @return
     * @throws Exception
     */
    @UnAuth
    @RequestMapping("/brandList")
    public ModelAndView brandList(HttpServletRequest request, HttpServletResponse resp) throws Exception {
        ModelAndView mav = new ModelAndView();
        Map<String, Object> params1 = new HashMap<>();
        mav.addObject("brandList", tBrandService.selectPmsBrandList(new PmsBrand()));
        PageHelper<PmsGoods> commList = getPmsGoodsPageHelper(5);
        mav.addObject("sellList", commList);
        mav.setViewName("diaShop/brandList");
        return mav;
    }
}
