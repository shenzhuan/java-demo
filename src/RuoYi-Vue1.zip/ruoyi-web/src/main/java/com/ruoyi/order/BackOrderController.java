/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:BackOrderController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.order;


import com.ruoyi.appletsutil.AppletsLoginUtils;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.order.domain.OmsBackOrder;
import com.ruoyi.order.domain.OmsOrder;
import com.ruoyi.order.service.IBackOrderApiService;
import com.ruoyi.order.service.IOmsBackOrderService;
import com.ruoyi.order.vo.ApplyReturnParams;
import com.ruoyi.order.vo.BackOrderItem;
import com.ruoyi.order.vo.QueryOrderCriteria;
import com.ruoyi.util.CommonConstant;
import com.ruoyi.util.PageHelper;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletRequest;

/**
 * 退单控制器
 */
@RestController
@Api(description = "退单接口")
public class BackOrderController {


    /**
     * 注入退单混合api
     */
    @Autowired
    private IBackOrderApiService IBackOrderApiService;

    /**
     * 注入退单服务接口
     */
    @Autowired
    private IOmsBackOrderService backOrderService;


    /**
     * 申请退款
     *
     * @param orderId 订单id
     * @param reason  退款原因
     * @param desc    描述
     * @return -1 订单状态错误  成功>0  失败= 0
     */
    @RequestMapping(value = "applyrefund")
    @ResponseBody
    @ApiOperation(value = "申请退款", notes = "申请退款（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "orderId", value = "订单id"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "reason", value = "退款原因"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "desc", value = "描述"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "-1 订单状态错误  成功>0  失败= 0", response = Integer.class)
    })
    @Log(title = "申请退款", businessType = BusinessType.INSERT)
    public AjaxResult applyRefund(HttpServletRequest request, long orderId, String reason, String desc) {
        return AjaxResult.success(IBackOrderApiService.applyRefundOrder(AppletsLoginUtils.getInstance().getCustomerId(request), orderId, reason, desc));
    }


    /**
     * 查询订单详情(退货用)
     *
     * @param orderId 订单id
     * @return 返回订单详情
     */
    @RequestMapping(value = "queryorderforreturn")
    @ResponseBody
    @ApiOperation(value = "查询订单详情(退货用)", notes = "查询订单详情(退货用)（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "orderId", value = "订单id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回订单详情", response = OmsOrder.class)
    })
    @Log(title = "查询订单详情(退货用)", businessType = BusinessType.SELECT)
    public AjaxResult queryOrderForReturn(HttpServletRequest request, long orderId) {
        return AjaxResult.success(IBackOrderApiService.queryOrderForReturn(AppletsLoginUtils.getInstance().getCustomerId(request), orderId));
    }


    /**
     * 申请退货
     *
     * @param applyReturnParams 申请退货请求
     * @return -1  0 失败  成功1
     */
    @RequestMapping(value = "applyreturn")
    @ResponseBody
    @ApiOperation(value = "申请退货", notes = "申请退货（需要认证）", httpMethod = "POST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "-1  0 失败  成功1", response = Integer.class)
    })
    @Log(title = "申请退货", businessType = BusinessType.INSERT)
    public AjaxResult applyReturnOrder(HttpServletRequest request, @RequestBody ApplyReturnParams applyReturnParams) {
        applyReturnParams.setCustomerId(AppletsLoginUtils.getInstance().getCustomerId(request));
        return AjaxResult.success(IBackOrderApiService.applyReturnOrder(applyReturnParams));
    }


    /**
     * 分页查询用户退单信息
     *
     * @param pageHelper    分页帮助类
     * @param queryCriteria 查询条件
     * @return 返回用户退单信息
     */
    @RequestMapping(value = "backorderlist")
    @ResponseBody
    @ApiOperation(value = "分页查询用户退单信息", notes = "分页查询用户退单信息（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回用户退单信息", response = OmsBackOrder.class)
    })
    @Log(title = "分页查询用户退单信息", businessType = BusinessType.SELECT)
    public AjaxResult queryCustomerBackOrders(HttpServletRequest request, @ApiIgnore PageHelper<OmsBackOrder> pageHelper, @ApiIgnore QueryOrderCriteria queryCriteria) {
        queryCriteria.setCustomerId(AppletsLoginUtils.getInstance().getCustomerId(request));
        return AjaxResult.success(backOrderService.queryBackOrderForSite(pageHelper, queryCriteria));
    }

    /**
     * 填写物流信息
     *
     * @param id               退单id
     * @param logisCompanyName 物流公司名称
     * @param waybillCode      物流单号
     * @return 成功=1 订单号含有中文-2 其他失败
     */
    @RequestMapping(value = "fillthelogistics")
    @ResponseBody
    @ApiOperation(value = "填写物流信息", notes = "填写物流信息（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "id", value = "退单id"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "logisCompanyName", value = "物流公司名称"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "waybillCode", value = "物流单号"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "成功=1 订单号含有中文-2 其他失败", response = Integer.class)
    })
    @Log(title = "填写物流信息", businessType = BusinessType.INSERT)
    public AjaxResult fillTheLogistics(HttpServletRequest request, long id, String logisCompanyName, String waybillCode) {
        return AjaxResult.success(backOrderService.fillTheLogistics(AppletsLoginUtils.getInstance().getCustomerId(request), id, logisCompanyName, waybillCode));
    }


    /**
     * 查询退单详情
     *
     * @param id 退单id
     * @return 返回退单详情
     */
    @RequestMapping(value = "querybackdetail")
    @ResponseBody
    @ApiOperation(value = "查询退单详情", notes = "查询退单详情（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "id", value = "退单id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回退单详情", response = OmsBackOrder.class)
    })
    @Log(title = "查询退单详情", businessType = BusinessType.SELECT)
    public AjaxResult queryBackDetail(HttpServletRequest request, long id) {
        return AjaxResult.success(backOrderService.queryBackOrderById(id, CommonConstant.QUERY_WITH_NO_STORE, AppletsLoginUtils.getInstance().getCustomerId(request), BackOrderItem.LOG, BackOrderItem.SKUS));
    }

    /**
     * 删除订单
     *
     * @param id 退单id
     */
    @RequestMapping(value = "/deleteBackOrder")
    @ResponseBody
    @Log(title = "删除订单", businessType = BusinessType.DELETE)
    public AjaxResult deleteBackOrder(HttpServletRequest request, long id) {
        return AjaxResult.success(backOrderService.deleteOmsBackOrderById(id));
    }
}
