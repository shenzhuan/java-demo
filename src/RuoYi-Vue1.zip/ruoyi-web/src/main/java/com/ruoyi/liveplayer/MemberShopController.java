package com.ruoyi.liveplayer;


import com.ruoyi.appletsutil.AppletsLoginUtils;
import com.ruoyi.cms.service.ArticleListService;
import com.ruoyi.common.annotation.UnAuth;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.goods.domain.PmsAttention;
import com.ruoyi.goods.service.*;
import com.ruoyi.integral.service.CustomerPointService;
import com.ruoyi.marketing.service.CouponService;
import com.ruoyi.member.service.IUmsMemberAddressService;
import com.ruoyi.member.service.IUmsMemberService;
import com.ruoyi.order.domain.OmsOrder;
import com.ruoyi.order.domain.OmsShoppingCart;
import com.ruoyi.order.service.*;
import com.ruoyi.order.vo.OrderItem;
import com.ruoyi.order.vo.OrderSettlementRequest;
import com.ruoyi.order.vo.QueryOrderCriteria;
import com.ruoyi.order.vo.SubmitOrderParams;
import com.ruoyi.sms.service.ISmsHomeAdvertiseService;
import com.ruoyi.sms.service.ISmsHomeBrandService;
import com.ruoyi.sms.service.ISmsHomeNewProductService;
import com.ruoyi.sms.service.ISmsHomeRecommendProductService;
import com.ruoyi.store.service.ITStoreInfoService;
import com.ruoyi.util.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import springfox.documentation.annotations.ApiIgnore;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author stylefeng
 * @since 2017-05-17
 */
@Controller
@RequestMapping("web")
public class MemberShopController extends BaseController {
    String path = "F:/zscat-b2b2c/";
    private String PREFIX = "web/";
    @Autowired
    private ArticleListService articleService;
    @Autowired
    private IPmsBrandService tBrandService;
    @Autowired
    private IPmsTypeService tGoodsTypeService;
    @Autowired
    private IPmsGoodsService tGoodsService;
    @Autowired
    private IPmsCategoryService tGoodsClassService;
    @Autowired
    private ITStoreInfoService tStoreService;
    @Autowired
    private ISmsHomeAdvertiseService bannerService;
    @Autowired
    private CouponService couponService;

    @Autowired
    private IOmsShoppingCartService tCartService;

    @Autowired
    private IUmsMemberService tMemberService;

    @Autowired
    private IUmsMemberAddressService addressService;
    @Autowired
    private IPmsAttentionService favoriteService;
    @Autowired
    private IOmsOrderService orderService;
    @Autowired
    private IOmsOrderAttrService tGoodSorderService;

    @Resource
    private ISmsHomeNewProductService homeNewProductService;
    @Resource
    private ISmsHomeRecommendProductService homeRecommendProductService;
    @Resource
    private ISmsHomeBrandService homeBrandService;
    /**
     * 商品服务api接口
     */
    @Autowired
    private ISpuApiService ISpuApiService;
    /**
     * 注入会员积分服务
     */
    @Autowired
    private CustomerPointService customerPointService;
    /**
     * 注入购物车混合api接口
     */
    @Autowired
    private ShoppingCartServiceApi shoppingCartServiceApi;
    /**
     * 注入结算服务接口
     */
    @Autowired
    private SettlementService settlementService;

    /**
     * 注入订单服务接口
     */
    @Autowired
    private IOrderApiService IOrderApiService;

    @RequestMapping(value = "/addCart", method = RequestMethod.POST)
    public @ResponseBody
    AjaxResult addCart(@RequestParam Map<String, Object> params, HttpServletRequest req) throws Exception {
        OmsShoppingCart shoppingCart = new OmsShoppingCart();
        shoppingCart.setSkuId(params.get("skuId").toString());
        shoppingCart.setSpuId((Long) params.get("spuId"));
        shoppingCart.setNum(1);
        return AjaxResult.success(shoppingCartServiceApi.addShoppingCart(shoppingCart.setDefaultValuesForAdd(AppletsLoginUtils.getInstance().getSessionCustomerId(req))));
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("BuyCar")
    public String BuyCar(Model model, HttpServletRequest req
            , @RequestParam(value = "storeId", required = false, defaultValue = "-1") long storeId) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("cartList", shoppingCartServiceApi.queryShoppingCarts(AppletsLoginUtils.getInstance().getSessionCustomerId(req), storeId));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "BuyCar";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("BuyCar_Two")
    public String BuyCar_Two(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            OmsShoppingCart cart = new OmsShoppingCart();
            cart.setCustomerId(AppletsLoginUtils.getInstance().getSessionCustomerId(req));
            List<OmsShoppingCart> cartList = tCartService.selectOmsShoppingCartList(cart);
            OrderSettlementRequest orderSettlementRequest = new OrderSettlementRequest();
            List<Long> ids = cartList.stream()
                    .map(OmsShoppingCart::getId)
                    .collect(Collectors.toList());
            Long[] idss = new Long[ids.size()];
            for (int i = 0; i < ids.size(); i++) {
                idss[i] = ids.get(i);
            }
            orderSettlementRequest.setIds(idss);
            orderSettlementRequest.setIsGroup(0);
            orderSettlementRequest.setGroupId("0");
            model.addAttribute("settlementList", settlementService.orderSettlement(orderSettlementRequest.addCustomerId(AppletsLoginUtils.getInstance().getSessionCustomerId(req))));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "BuyCar_Two";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("BuyCar_Three")
    public String BuyCar_Three(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            SubmitOrderParams submitOrderParams = new SubmitOrderParams();
            submitOrderParams.setCustomerId(AppletsLoginUtils.getInstance().getSessionCustomerId(req));
            submitOrderParams.setAddressId(227L);
            OmsShoppingCart cart = new OmsShoppingCart();
            cart.setCustomerId(AppletsLoginUtils.getInstance().getSessionCustomerId(req));
            List<OmsShoppingCart> cartList = tCartService.selectOmsShoppingCartList(cart);
            List<Long> ids = cartList.stream()
                    .map(OmsShoppingCart::getId)
                    .collect(Collectors.toList());
            Long[] idss = new Long[ids.size()];
            for (int i = 0; i < ids.size(); i++) {
                idss[i] = ids.get(i);
            }
            submitOrderParams.setIds(idss);
            submitOrderParams.setIsGroup(0);
            submitOrderParams.setGroupId("0");
            // 订单返回实体
            model.addAttribute("submitOrderResponse", IOrderApiService.submitOrder(submitOrderParams));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "BuyCar_Three";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member")
    public String Member(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Address")
    public String Member_Address(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("addressList", addressService.queryCustomerAllAddress(AppletsLoginUtils.getInstance().getSessionCustomerId(req)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Address";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Cash")
    public String Member_Cash(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Cash";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Collect")
    public String Member_Collect(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            PageHelper<PmsAttention> pageHelper = new PageHelper<>();
            model.addAttribute("collectList", favoriteService.queryAttentionsForCustomerCentre(pageHelper, AppletsLoginUtils.getInstance().getSessionCustomerId(req)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Collect";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Commission")
    public String Member_Commission(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Commission";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Links")
    public String Member_Links(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Links";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Member")
    public String Member_Member(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Member";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Member_List")
    public String Member_Member_List(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Member_List";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Money")
    public String Member_Money(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Money";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Money_Charge")
    public String Member_Money_Charge(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Money_Charge";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Money_Pay")
    public String Member_Money_Pay(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Money_Pay";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Msg")
    public String Member_Msg(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Msg";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Order")
    public String Member_Order(Model model, HttpServletRequest req, @ApiIgnore PageHelper<OmsOrder> pageHelper, @ApiIgnore QueryOrderCriteria queryCriteria) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            queryCriteria.setCustomerId(AppletsLoginUtils.getInstance().getSessionCustomerId(req));

            model.addAttribute("orderList", orderService.queryOrdersForSite(pageHelper, queryCriteria, OrderItem.BACK_PROGRESS, OrderItem.SKUS,
                    OrderItem.CANREFUND, OrderItem.CANRETRUN));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Order";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Packet")
    public String Member_Packet(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Packet";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Results")
    public String Member_Results(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Results";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_Safe")
    public String Member_Safe(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_Safe";
    }

    /**
     * 跳转到会员中心
     */
    @UnAuth
    @RequestMapping("Member_User")
    public String Member_User(Model model, HttpServletRequest req) {
        try {
            if (AppletsLoginUtils.getInstance().getSessionCustomerId(req) == 0) {
                return PREFIX + "Login";
            }
            model.addAttribute("commList", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return PREFIX + "Member_User";
    }
}
