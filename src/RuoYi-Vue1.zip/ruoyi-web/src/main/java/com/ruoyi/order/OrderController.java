/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:OrderController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.order;


import com.ruoyi.appletsutil.AppletsLoginUtils;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.annotation.UnAuth;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.goods.service.IPmsAttentionService;
import com.ruoyi.marketing.service.CouponService;
import com.ruoyi.member.service.IUmsPreDepositRecordService;
import com.ruoyi.member.service.IUmsWithdrawService;
import com.ruoyi.order.domain.OmsOrder;
import com.ruoyi.order.service.*;
import com.ruoyi.order.vo.*;
import com.ruoyi.store.service.AttentionStoreService;
import com.ruoyi.util.CommonConstant;
import com.ruoyi.util.PageHelper;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * 订单控制器
 */
@Slf4j
@RestController
@Api(description = "订单接口")
public class OrderController {

    /**
     * 自动注入预存款service
     */
    @Autowired
    private IUmsPreDepositRecordService predepositRecordService;

    /**
     * 注入订单服务接口
     */
    @Autowired
    private IOrderApiService IOrderApiService;

    /**
     * 注入订单服务接口
     */
    @Autowired
    private IOmsOrderService orderService;

    /**
     * 退单服务接口
     */
    @Autowired
    private IOmsBackOrderService backOrderService;
    /**
     * 注入购物车服务接口
     */
    @Autowired
    private IOmsShoppingCartService shoppingCartService;
    /**
     * 注入商品关注服务接口
     */
    @Autowired
    private IPmsAttentionService attentionService;
    @Autowired
    private AttentionStoreService attentionStoreService;
    /**
     * 注入提现记录服务
     */
    @Autowired
    private IOmsCommissionRecordsService commissionRecordService;
    /**
     * 注入提现记录服务
     */
    @Autowired
    private IUmsWithdrawService withdrawRecordService;

    @Autowired
    private CouponService couponService;

    /**
     * 提交订单
     *
     * @param submitOrderParams 提交订单参数
     * @return 返回订单提交响应实体
     */
    @RequestMapping(value = "/submitorder")
    @ResponseBody
    @ApiOperation(value = "提交订单", notes = "提交订单（需要认证）", httpMethod = "POST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回订单提交响应实体", response = SubmitOrderResponse.class)
    })
    @Log(title = "提交订单", businessType = BusinessType.INSERT)
    public AjaxResult submitOrder(@RequestBody SubmitOrderParams submitOrderParams, HttpServletRequest request) {
        Long t = System.currentTimeMillis();
        log.debug("提交订单......start");
        submitOrderParams.setCustomerId(AppletsLoginUtils.getInstance().getCustomerId(request));
        // 订单返回实体
        SubmitOrderResponse submitOrderResponse;
        try {
            submitOrderResponse = IOrderApiService.submitOrder(submitOrderParams);
        } catch (ServiceException e) {
            return AjaxResult.error(e.getErrorCode());
        }
        log.debug("提交订单......end" + (System.currentTimeMillis() - t) + "ms");

        return AjaxResult.success(submitOrderResponse);
    }

    /**
     * 查询用户订单信息
     *
     * @param pageHelper    分页帮助类
     * @param queryCriteria 查询条件
     * @return 返回用户订单信息
     */
    @RequestMapping("querycustomerorders")
    @ResponseBody
    @ApiOperation(value = "查询用户订单信息", notes = "查询用户订单信息（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "status", value = "订单状态"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回用户订单信息", response = OmsOrder.class)
    })
    @Log(title = "查询用户订单信息", businessType = BusinessType.SELECT)
    public AjaxResult queryCustomerOrders(HttpServletRequest request, @ApiIgnore PageHelper<OmsOrder> pageHelper, @ApiIgnore QueryOrderCriteria queryCriteria) {
        queryCriteria.setCustomerId(AppletsLoginUtils.getInstance().getCustomerId(request));
        return AjaxResult.success(orderService.queryOrdersForSite(pageHelper, queryCriteria, OrderItem.BACK_PROGRESS, OrderItem.SKUS, OrderItem.CANREFUND, OrderItem.CANRETRUN));
    }


    /**
     * 取消订单
     *
     * @param orderId 订单id
     * @param reason  取消原因
     * @return 订单取消原因\n1:现在不想买\n2:商品价格较贵\n3:价格波动\n4:商品缺货\n5:重复下单\n6:收货人信息有误\n7:发票信息有误/发票未开\n8:送货时间过长\n9:其他原因\n0:系统取消
     */
    @RequestMapping(value = "/cancelorder")
    @ResponseBody
    @ApiOperation(value = "取消订单", notes = "取消订单（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "orderId", value = "订单id"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "reason", value = "取消原因"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "订单取消原因\\n1:现在不想买\\n2:商品价格较贵\\n3:价格波动\\n4:商品缺货\\n5:重复下单\\n6:收货人信息有误\\n7:发票信息有误/发票未开\\n8:送货时间过长\\n9:其他原因\\n0:系统取消", response = Integer.class)
    })
    @Log(title = "取消订单", businessType = BusinessType.INSERT)
    public AjaxResult cancelOrder(HttpServletRequest request, long orderId, String reason) {
        return AjaxResult.success(IOrderApiService.cancleOrder(CancelOrderParams.buildCustomerSource(AppletsLoginUtils.getInstance().getCustomerId(request), orderId, reason)));
    }

    /**
     * 删除订单
     *
     * @param orderId 订单id
     * @return 订单取消原因\n1:现在不想买\n2:商品价格较贵\n3:价格波动\n4:商品缺货\n5:重复下单\n6:收货人信息有误\n7:发票信息有误/发票未开\n8:送货时间过长\n9:其他原因\n0:系统取消
     */
    @RequestMapping(value = "/deleteorder")
    @ResponseBody
    @ApiOperation(value = "删除订单", notes = "删除订单（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "orderId", value = "订单id"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "reason", value = "取消原因"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "订单取消原因\\n1:现在不想买\\n2:商品价格较贵\\n3:价格波动\\n4:商品缺货\\n5:重复下单\\n6:收货人信息有误\\n7:发票信息有误/发票未开\\n8:送货时间过长\\n9:其他原因\\n0:系统取消", response = Integer.class)
    })
    @Log(title = "删除订单", businessType = BusinessType.DELETE)
    public AjaxResult deleteorder(HttpServletRequest request, long orderId) {
        return AjaxResult.success(IOrderApiService.deleteOrder(CancelOrderParams.buildCustomerSource(AppletsLoginUtils.getInstance().getCustomerId(request), orderId, "")));
    }

    /**
     * 确认收货订单
     *
     * @param orderId 订单id
     * @return 成功返回>0 失败返回0
     */
    @RequestMapping(value = "/receiptorder")
    @ResponseBody
    @ApiOperation(value = "确认收货订单", notes = "确认收货订单（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "orderId", value = "订单id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "成功返回>0 失败返回0", response = Integer.class)
    })
    @Log(title = "确认收货订单", businessType = BusinessType.UPDATE)
    public AjaxResult confirmReceipt(HttpServletRequest request, long orderId) {
        return AjaxResult.success(IOrderApiService.confirmReceipt(orderId, AppletsLoginUtils.getInstance().getCustomerId(request)));
    }


    /**
     * 订单统计
     *
     * @return 返回订单消息总数返回实体
     */
    @RequestMapping(value = "/order/count")
    @ResponseBody
    @ApiOperation(value = "订单统计", notes = "订单统计（需要认证）", httpMethod = "POST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回订单消息总数返回实体", response = OrderMessageCount.class)
    })
    @Log(title = "订单统计", businessType = BusinessType.SELECT)
    public AjaxResult queryOrderMessageCount(HttpServletRequest request, @RequestParam(value = "storeId", required = false, defaultValue = "-1") long storeId) {
        Map map = new HashMap();
        String commissonMoney = "0";
        int attendStoreNum = 0;

        int attendGoodsNum = 0;
        long customerId = AppletsLoginUtils.getInstance().getCustomerId(request);
        if (customerId == 0) {

        } else {
            map.put("type", "0");
            map.put("customerId", customerId);
            commissonMoney = commissionRecordService.queryCommissionMoney(map); // 累计收入佣金
            attendGoodsNum = attentionService.queryAttentionCount(customerId);
            attendStoreNum = attentionStoreService.queryCustomerAttentionStoreCount(customerId);
        }

        map.put("status", "3");
        String withdrawMoney = withdrawRecordService.queryWithdrawMoney(map);// 累计提现记录
        return AjaxResult.success(OrderMessageCount.build().addToCommissonMoney(commissonMoney).addToWithdrawMoney(withdrawMoney).addToBlance(predepositRecordService.queryCutomerAllPredeposit(AppletsLoginUtils.getInstance().getCustomerId(request))).addToCartNum(shoppingCartService.queryShoppingCartCount(AppletsLoginUtils.getInstance().getCustomerId(request), storeId).getAllNum())
                .addToAttendGoodsNum(attendGoodsNum).addToAttendStoreNum(attendStoreNum)
                .addToCouponNum(couponService.queryCustomerCouponCount(AppletsLoginUtils.getInstance().getCustomerId(request))).addToPayCount(orderService.toPayOrderCount(AppletsLoginUtils.getInstance().getCustomerId(request)))
                .addToDeliverCount(orderService.toDeliverOrderCount(AppletsLoginUtils.getInstance().getCustomerId(request)))
                .addToReceiptCount(orderService.toReceiptOrderCount(AppletsLoginUtils.getInstance().getCustomerId(request)))
                .addToEvaluateCount(orderService.toEvaluateOrderCount(AppletsLoginUtils.getInstance().getCustomerId(request))).addBackOrderCount(backOrderService.queryInProcessBackOrder(AppletsLoginUtils.getInstance().getCustomerId(request))));
    }

    /**
     * 查看物流
     *
     * @param orderId 订单id
     * @return H5查询物流的url
     */
    @RequestMapping("/getchecklogisticsurl")
    @ResponseBody
    @ApiOperation(value = "查看物流", notes = "查看物流（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "orderId", value = "订单id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "H5查询物流的url", response = String.class)
    })
    @Log(title = "查看物流", businessType = BusinessType.SELECT)
    public AjaxResult getCheckLogisticsUrl(HttpServletRequest request, long orderId) {
        return AjaxResult.success(orderService.getCheckLogisticsUrl(orderId, AppletsLoginUtils.getInstance().getCustomerId(request), ""));
    }

    /**
     * 查询订单详情
     *
     * @param orderId 订单id
     * @return 返回订单详情
     */
    @RequestMapping(value = "/orderdetail")
    @ResponseBody
    @ApiOperation(value = "查询订单详情", notes = "查询订单详情（需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "orderId", value = "订单id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回订单详情", response = OmsOrder.class)
    })
    @Log(title = "查询订单详情", businessType = BusinessType.SELECT)
    public AjaxResult queryOrderDetail(HttpServletRequest request, long orderId) {
        return AjaxResult.success(IOrderApiService.queryOrderDetailById(orderId, AppletsLoginUtils.getInstance().getCustomerId(request), CommonConstant.QUERY_WITH_NO_STORE, OrderItem.CANREFUND, OrderItem.BACK_PROGRESS, OrderItem.CANRETRUN, OrderItem.SKUS, OrderItem.ATTR, OrderItem.STORE_INFO));
    }

    /**
     * 查询订单集合
     *
     * @param orderCode 订单code
     * @return 返回订单集合
     */
    @ResponseBody
    @GetMapping(value = "/ordersByCode")
    @ApiOperation(value = "查询订单集合", notes = "查询订单集合（需要认证）")
    @Log(title = "查询订单集合", businessType = BusinessType.SELECT)
    public AjaxResult queryOrdersByOrderCode(String orderCode, HttpServletRequest request) {
        return AjaxResult.success(orderService.queryOrderByOrderCode(orderCode, AppletsLoginUtils.getInstance().getCustomerId(request)));
    }

    /**
     * 查询订单集合
     *
     * @param orderCode 订单code
     * @return 返回订单集合
     */
    @ResponseBody
    @GetMapping(value = "/orderByOrderCode")
    @ApiOperation(value = "查询订单", notes = "查询订单集合（需要认证）")
    @Log(title = "查询订单", businessType = BusinessType.SELECT)
    public AjaxResult orderByOrderCode(String orderCode, HttpServletRequest request) {
        return AjaxResult.success(orderService.selectOmsOrderByOrderCode(orderCode, OrderItem.CANREFUND, OrderItem.CANRETRUN, OrderItem.SKUS, OrderItem.ATTR, OrderItem.STORE_INFO));
    }

    /**
     * 再次购买
     *
     * @param orderId 订单id
     * @return 1 成功  0 失败 -1 库存不足  -2 单品不存在 -3 参数错误 -4 单品已下架 -5 超出商品抢购限购数量 -6 预售商品不能加入购物车 -7 订单不存在
     */
    @GetMapping(value = "/buyagain")
    @ApiOperation(value = "再次购买", notes = "再次购买（需要认证）")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", dataType = "long", name = "orderId", value = "订单id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "1 成功  0 失败 -1 库存不足  -2 单品不存在 -3 参数错误 -4 单品已下架 -5 超出商品抢购限购数量 -6 预售商品不能加入购物车 -7 订单不存在",
                    response = Integer.class)
    })
    @Log(title = "再次购买", businessType = BusinessType.INSERT)
    public AjaxResult buyAgain(long orderId, HttpServletRequest request) {
        int result;
        try {
            result = IOrderApiService.buyAgain(orderId, AppletsLoginUtils.getInstance().getCustomerId(request));
        } catch (ServiceException e) {
            result = Integer.parseInt(e.getErrorCode());
        }
        return AjaxResult.success(result);
    }

    /**
     * 查询拼团订单
     *
     * @param pageHelper    分页帮助类
     * @param queryCriteria 查询参数实体
     * @return 拼团订单集合
     */
    @ApiOperation(value = "查询拼团订单列表", notes = "查询拼团订单列表（不需要认证）", httpMethod = "POST")
    @RequestMapping(value = "/spudetail/grouporders")
    @ResponseBody
    @UnAuth
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "marketingId", value = "促销id"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "skuId", value = "单品id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "拼团订单集合", response = GroupOrder.class)
    })
    @Log(title = "查询拼团订单", businessType = BusinessType.SELECT)
    public AjaxResult queryGroupOrdersForSpuDetail(@ApiIgnore PageHelper<GroupOrder> pageHelper, @ApiIgnore GroupOrder.QueryCriteria queryCriteria) {
        return AjaxResult.success(orderService.queryGroupOrders(queryCriteria.buildForSpuDetail(), pageHelper, true, false));
    }

    /**
     * 查询拼团订单
     *
     * @param pageHelper    分页帮助类
     * @param queryCriteria 查询参数实体
     * @return 拼团订单集合
     */
    @ApiOperation(value = "查询所有拼团订单列表", notes = "查询拼团订单列表（不需要认证）", httpMethod = "POST")
    @RequestMapping(value = "/spudetail/groupAllorders")
    @ResponseBody
    @UnAuth
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "marketingId", value = "促销id"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "skuId", value = "单品id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "拼团订单集合", response = GroupOrder.class)
    })
    @Log(title = "查询所有拼团订单列表", businessType = BusinessType.SELECT)
    public AjaxResult queryGroupAllOrdersForSpuDetail(@ApiIgnore PageHelper<GroupOrder> pageHelper, @ApiIgnore GroupOrder.QueryCriteria queryCriteria) {
        return AjaxResult.success(orderService.queryGroupOrders(queryCriteria, pageHelper, true, false));
    }

    /**
     * 校验是否已在团中
     *
     * @param groupId 拼团id
     * @return 1:不在 -1在 -2缺少参数
     */
    @ApiOperation(value = "判断会员是否在指定的团中", notes = "判断会员是否在指定的团中（需要认证）", httpMethod = "POST")
    @RequestMapping(value = "/checkisingroup")
    @ResponseBody
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "String", name = "groupId", value = "拼团id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "1:不在 -1在 -2缺少参数", response = Integer.class)
    })
    @Log(title = "判断会员是否在指定的团中", businessType = BusinessType.SELECT)
    public AjaxResult checkIsInGroup(HttpServletRequest request, String groupId) {
        return AjaxResult.success(org.springframework.util.StringUtils.isEmpty(groupId) ? -2 : ObjectUtils.isEmpty(orderService.queryByGroupIdAndCustomerId(groupId, AppletsLoginUtils.getInstance().getCustomerId(request))) ? 1 : -1);
    }

    /**
     * 根据订单号查询物流信息
     *
     * @param orderId 订单号
     * @return 物流信息
     */
    @ApiOperation(value = "物流信息查询")
    @RequestMapping(value = "/express", method = RequestMethod.GET)
    @Log(title = "物流信息查询", businessType = BusinessType.SELECT)
    public AjaxResult getExpressInfo(Long orderId) {
        return AjaxResult.success(orderService.expressOrder(orderId));
    }
    /*{
        "status": "0",*//* status 0:正常查询 201:快递单号错误 203:快递公司不存在 204:快递公司识别失败 205:没有信息 207:该单号被限制，错误单号 *//*
            "msg": "ok",
            "result": {
        "number": "780098068058",
                "type": "zto",
                "list": [{
            "time": "2018-03-09 11:59:26",
                    "status": "【石家庄市】快件已在【长安三部】 签收,签收人: 本人,感谢使用中通快递,期待再次为您服务!"
        }, {
            "time": "2018-03-09 09:03:10",
                    "status": "【石家庄市】 快件已到达 【长安三部】（0311-85344265）,业务员 容晓光（13081105270） 正在第1次派件, 请保持电话畅通,并耐心等待"
        }, {
            "time": "2018-03-08 23:43:44",
                    "status": "【石家庄市】 快件离开 【石家庄】 发往 【长安三部】"
        }, {
            "time": "2018-03-08 21:00:44",
                    "status": "【石家庄市】 快件到达 【石家庄】"
        }, {
            "time": "2018-03-07 01:38:45",
                    "status": "【广州市】 快件离开 【广州中心】 发往 【石家庄】"
        }, {
            "time": "2018-03-07 01:36:53",
                    "status": "【广州市】 快件到达 【广州中心】"
        }, {
            "time": "2018-03-07 00:40:57",
                    "status": "【广州市】 快件离开 【广州花都】 发往 【石家庄中转】"
        }, {
            "time": "2018-03-07 00:01:55",
                    "status": "【广州市】 【广州花都】（020-37738523） 的 马溪 （18998345739） 已揽收"
        }],
        "deliverystatus": "3", *//* 0：快递收件(揽件)1.在途中 2.正在派件 3.已签收 4.派送失败 5.疑难件 6.退件签收  *//*
                "issign": "1",                      *//*  1.是否签收                  *//*
                "expName": "中通快递",              *//*  快递公司名称                *//*
                "expSite": "www.zto.com",           *//*  快递公司官网                *//*
                "expPhone": "95311",                *//*  快递公司电话                *//*
                "courier": "容晓光",                *//*  快递员 或 快递站(没有则为空)*//*
                "courierPhone":"13081105270",       *//*  快递员电话 (没有则为空)     *//*
                "updateTime":"2019-08-27 13:56:19", *//*  快递轨迹信息最新时间        *//*
                "takeTime":"2天20小时14分",         *//*  发货到收货消耗时长 (截止最新轨迹)  *//*
                "logo":"https://img3.fegine.com/express/zto.jpg" *//* 快递公司LOGO *//*
    }*/
}
