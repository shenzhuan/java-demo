/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:HtmlController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.goods;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ruoyi.common.annotation.UnAuth;
import com.ruoyi.common.utils.ThreadTask;
import com.ruoyi.common.utils.http.HttpUtils;
import com.ruoyi.setting.service.BaseInfoSetService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

/**
 * Created by 魔金商城 on 17/7/14.
 * 生成html的控制器
 */
@Api(description = "生成html接口")
@RestController
public class HtmlController {


    /**
     * 协议模版
     */
    private static final String PROTOCOL_TEMPLATE = "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"><title></title><style>p { line-height:1.4!important } h3,h4,h5 { font-size:16px!important }</style></head><body>template</body></html>";


    /**
     * 注入基本信息服务接口
     */
    @Autowired
    private BaseInfoSetService baseInfoSetService;

    public static void main(String[] args) {
        ThreadTask.getInstance().addTask(() -> {
            for (int j = 0; j < 10000; j++) {
                String url = "https://wxapi.yixiang.co/api/product/hot";
                String rspStr = HttpUtils.sendGet(url, "page=1&limit=201");
                JSONObject obj = JSONObject.parseObject(rspStr);
                System.out.println(obj);
                JSONArray region = obj.getJSONArray("data");
                for (int i = 0; i < region.size(); i++) {
                    try {
                        String uu = "https://wxapi.yixiang.co/api/product/detail/" + region.getJSONObject(i).getLong("id");
                        String rspStr1 = HttpUtils.sendGet(uu, "?latitude=&longitude=");
                        System.out.println(rspStr1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ThreadTask.getInstance().addTask(() -> {
            for (int j = 0; j < 10000; j++) {
                String url = "https://wxapi.yixiang.co/api/product/hot";
                String rspStr = HttpUtils.sendGet(url, "page=1&limit=201");
                JSONObject obj = JSONObject.parseObject(rspStr);
                System.out.println(obj);
                JSONArray region = obj.getJSONArray("data");
                for (int i = 0; i < region.size(); i++) {
                    try {
                        String uu = "https://wxapi.yixiang.co/api/product/detail/" + region.getJSONObject(i).getLong("id");
                        String rspStr1 = HttpUtils.sendGet(uu, "?latitude=&longitude=");
                        System.out.println(rspStr1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ThreadTask.getInstance().addTask(() -> {
            for (int j = 0; j < 10000; j++) {
                String url = "https://wxapi.yixiang.co/api/product/hot";
                String rspStr = HttpUtils.sendGet(url, "page=1&limit=201");
                JSONObject obj = JSONObject.parseObject(rspStr);
                System.out.println(obj);
                JSONArray region = obj.getJSONArray("data");
                for (int i = 0; i < region.size(); i++) {
                    try {
                        String uu = "https://wxapi.yixiang.co/api/product/detail/" + region.getJSONObject(i).getLong("id");
                        String rspStr1 = HttpUtils.sendGet(uu, "?latitude=&longitude=");
                        System.out.println(rspStr1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ThreadTask.getInstance().addTask(() -> {
            for (int j = 0; j < 1000; j++) {
                String url = "https://wxapi.yixiang.co/api/product/hot";
                String rspStr = HttpUtils.sendGet(url, "page=1&limit=201");
                JSONObject obj = JSONObject.parseObject(rspStr);
                System.out.println(obj);
                JSONArray region = obj.getJSONArray("data");
                for (int i = 0; i < region.size(); i++) {
                    try {
                        String uu = "https://wxapi.yixiang.co/api/product/detail/" + region.getJSONObject(i).getLong("id");
                        String rspStr1 = HttpUtils.sendGet(uu, "?latitude=&longitude=");
                        System.out.println(rspStr1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ThreadTask.getInstance().addTask(() -> {
            for (int j = 0; j < 1000; j++) {
                String url = "https://wxapi.yixiang.co/api/product/hot";
                String rspStr = HttpUtils.sendGet(url, "page=1&limit=201");
                JSONObject obj = JSONObject.parseObject(rspStr);
                System.out.println(obj);
                JSONArray region = obj.getJSONArray("data");
                for (int i = 0; i < region.size(); i++) {
                    try {
                        String uu = "https://wxapi.yixiang.co/api/product/detail/" + region.getJSONObject(i).getLong("id");
                        String rspStr1 = HttpUtils.sendGet(uu, "?latitude=&longitude=");
                        System.out.println(rspStr1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ThreadTask.getInstance().addTask(() -> {
            for (int j = 0; j < 1000; j++) {
                String url = "https://wxapi.yixiang.co/api/product/hot";
                String rspStr = HttpUtils.sendGet(url, "page=1&limit=201");
                JSONObject obj = JSONObject.parseObject(rspStr);
                System.out.println(obj);
                JSONArray region = obj.getJSONArray("data");
                for (int i = 0; i < region.size(); i++) {
                    try {
                        String uu = "https://wxapi.yixiang.co/api/product/detail/" + region.getJSONObject(i).getLong("id");
                        String rspStr1 = HttpUtils.sendGet(uu, "?latitude=&longitude=");
                        System.out.println(rspStr1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ThreadTask.getInstance().addTask(() -> {
            for (int j = 0; j < 1000; j++) {
                String url = "https://wxapi.yixiang.co/api/product/hot";
                String rspStr = HttpUtils.sendGet(url, "page=1&limit=201");
                JSONObject obj = JSONObject.parseObject(rspStr);
                System.out.println(obj);
                JSONArray region = obj.getJSONArray("data");
                for (int i = 0; i < region.size(); i++) {
                    try {
                        String uu = "https://wxapi.yixiang.co/api/product/detail/" + region.getJSONObject(i).getLong("id");
                        String rspStr1 = HttpUtils.sendGet(uu, "?latitude=&longitude=");
                        System.out.println(rspStr1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ThreadTask.getInstance().addTask(() -> {
            for (int j = 0; j < 1000; j++) {
                String url = "https://wxapi.yixiang.co/api/product/hot";
                String rspStr = HttpUtils.sendGet(url, "page=1&limit=201");
                JSONObject obj = JSONObject.parseObject(rspStr);
                System.out.println(obj);
                JSONArray region = obj.getJSONArray("data");
                for (int i = 0; i < region.size(); i++) {
                    try {
                        String uu = "https://wxapi.yixiang.co/api/product/detail/" + region.getJSONObject(i).getLong("id");
                        String rspStr1 = HttpUtils.sendGet(uu, "?latitude=&longitude=");
                        System.out.println(rspStr1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        ThreadTask.getInstance().addTask(() -> {
            for (int j = 0; j < 1000; j++) {
                String url = "https://wxapi.yixiang.co/api/product/hot";
                String rspStr = HttpUtils.sendGet(url, "page=1&limit=201");
                JSONObject obj = JSONObject.parseObject(rspStr);
                System.out.println(obj);
                JSONArray region = obj.getJSONArray("data");
                for (int i = 0; i < region.size(); i++) {
                    try {
                        String uu = "https://wxapi.yixiang.co/api/product/detail/" + region.getJSONObject(i).getLong("id");
                        String rspStr1 = HttpUtils.sendGet(uu, "?latitude=&longitude=");
                        System.out.println(rspStr1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    public static void main1(String[] args) {
        for (int j = 0; j < 10000; j++) {
            String url = "https://ceres.zkthink.com/api/classify/getClaasifyProducts";
            String rspStr = HttpUtils.sendGet(url, "classifyId=770&type=1&volume=1&productName=&page=1&pageSize=200");
            JSONObject obj = JSONObject.parseObject(rspStr);
            System.out.println(obj);
            JSONObject obj1 = JSONObject.parseObject(obj.getString("data"));
            System.out.println(obj1.getString("list"));
            JSONArray region = obj1.getJSONArray("list");
            for (int i = 0; i < region.size(); i++) {
                try {
                    String uu = "https://ceres.zkthink.com/api/product/getProducts";
                    String rspStr1 = HttpUtils.sendGet(uu, "skuId=" + region.getJSONObject(i).getLong("skuId") + "&productId=" + region.getJSONObject(i).getLong("productId"));
                    System.out.println(rspStr1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 获取开店协议
     *
     * @throws Exception 异常
     */
    @ApiOperation(value = "获取开店协议", notes = "获取开店协议（不需要认证）")
    @RequestMapping(value = "/registerprotocol", method = RequestMethod.GET)
    @UnAuth
    public void openProtocol(HttpServletResponse response) throws Exception {
        response.setContentType("text/html; charset=UTF-8");
        response.getWriter().print(createHtml(PROTOCOL_TEMPLATE, baseInfoSetService.queryBaseInfoSet().getSiteRegisterProtocol()));
    }

    /**
     * 生成html
     *
     * @param html 要替换的内容
     * @return 返回html
     */
    private String createHtml(String template, String html) {
        return template.replaceAll("template", html);
    }

}
