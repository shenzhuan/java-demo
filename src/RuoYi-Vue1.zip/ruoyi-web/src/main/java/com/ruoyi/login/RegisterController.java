/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:RegisterController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.login;


import com.ruoyi.appletsutil.AppletsLoginUtils;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.annotation.UnAuth;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.redis.RedisCache;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.member.domain.UmsMember;
import com.ruoyi.member.service.IUmsMemberService;
import com.ruoyi.member.service.RegisterService;
import com.ruoyi.member.service.RegisterServiceApi;
import com.ruoyi.member.vo.AppletLoginInfo;
import com.ruoyi.util.CommonConstant;
import io.swagger.annotations.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * 注册控制器
 */
@Slf4j
@RestController
@Api(description = "注册接口")
public class RegisterController {

    /**
     * 注入用户服务
     */
    @Autowired
    private IUmsMemberService customerService;

    /**
     * 注入注册服务
     */
    @Autowired
    private RegisterService registerService;

    /**
     * 注入注册聚合服务
     */
    @Autowired
    private RegisterServiceApi registerServiceApi;

    /**
     * 注入redis 服务接口
     */
    @Autowired
    private RedisCache redisService;

    public static void main(String[] args) {

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); //设置格式
        String timeText = format.format(1589904000000L);
        System.out.println(timeText);
        System.out.println(format.format(1531152000000L));
    }

    /**
     * 校验手机号码是否存在
     *
     * @param mobile 手机号码
     * @return 存在返回>0  不存在返回0
     */
    @ResponseBody
    @RequestMapping("/checkmobileexist")
    @UnAuth
    @ApiOperation(value = "校验手机号码是否存在", notes = "校验手机号码是否存在（不需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "mobile", value = "手机号码"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "存在返回>0  不存在返回0", response = Integer.class)
    })
    @Log(title = "校验手机号码是否存在", businessType = BusinessType.SELECT)
    public AjaxResult checkMobileExist(String mobile, long storeId) {
        return AjaxResult.success(customerService.isMobileExist(mobile, storeId));
    }

    /**
     * 发送短信验证码
     * r
     *
     * @param mobile 手机号码
     * @return 0 成功 1 失败 -1 手机号码已经存在
     */
    @UnAuth
    @RequestMapping(value = "/sendmobilecode")
    @ResponseBody
    @ApiOperation(value = "发送短信验证码", notes = "发送短信验证码（不需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "mobile", value = "手机号码"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "0 成功 1 失败 -1 手机号码已经存在", response = Integer.class)
    })
    @Log(title = "发送短信验证码", businessType = BusinessType.SELECT)
    public AjaxResult sendSmsCode(@RequestParam(value = "storeId", required = false, defaultValue = "0") long storeId, String mobile) {
        redisService.putToRedis(String.format("%s_%s", CommonConstant.APPLET_REGISTER_CODE_KEY, mobile), "1234", 5, TimeUnit.MINUTES);
        return AjaxResult.success("1234");
        //   return AjaxResult.success(registerServiceApi.sendRegisterSmsCode(mobile,storeId, code -> redisService.putToRedis(String.format("%s_%s", CommonConstant.APPLET_REGISTER_CODE_KEY, mobile), code, 5, TimeUnit.MINUTES)));
    }

    @UnAuth
    @ResponseBody
    @RequestMapping("/bingInviter")
    @ApiOperation(value = "设置邀请码", notes = "设置邀请码）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "code", value = "用户登录凭证"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "登录信息", response = AppletLoginInfo.class)
    })
    @Log(title = "设置邀请码", businessType = BusinessType.SELECT)
    public AjaxResult bingInviter(String code, HttpServletRequest request, long storeId) {
        if (StringUtils.isEmpty(code)) {
            return AjaxResult.error("请填写邀请码！");
        }
        // 推荐人
        UmsMember recommonded = customerService.queryCustomerByRecommondCode(code, storeId);

        // 如果推荐人不存在  则返回错误
        if (Objects.isNull(recommonded)) {
            log.error("addCustomer fail due to recommoned is not exist...and code:{}", code);
            return AjaxResult.error("邀请人不存在！");
        }
        UmsMember customer = AppletsLoginUtils.getInstance().getCustomer(request);
        if (customer == null) {
            return AjaxResult.error("请先登录！");
        }
        if (-1 != customer.getRecommended()) {
            log.error("bindCustomerRecommendCode fail :already has recommendCode");
            return AjaxResult.error("已经绑定过推荐码！");
        }
        if (customer.getId().equals(recommonded.getId())) {
            log.error("bindCustomerRecommendCode fail : recommendCustomer  is self  ");
            return AjaxResult.error("推荐人不能是自己！");
        }
        // 设置推荐人的会员id
        customer.setRecommended(recommonded.getId());
        customer.setInterest(recommonded.getNickname());
        // 设置会员的二级推荐人/ 推荐人的推荐人
        customer.setSRecommended(recommonded.getRecommended());

        return AjaxResult.success(customerService.updateUmsMember(customer));
    }

    /**
     * 用户注册
     *
     * @return -1 手机验证码错误 -2 参数错误 0 失败  成功>0  -3 手机号码已存在 -10 推荐人不存在
     */
    @UnAuth
    @RequestMapping("/register")
    @ResponseBody
    @ApiOperation(value = "用户注册", notes = "用户注册（不需要认证）", httpMethod = "POST")

    @ApiResponses({
            @ApiResponse(code = 200, message = "-1 手机验证码错误 -2 参数错误 0 失败  成功>0  -3 手机号码已存在 -10 推荐人不存在", response = Integer.class)
    })
    @Log(title = "用户注册", businessType = BusinessType.SELECT)
    public AjaxResult register(@RequestBody RegisterData registerData) {
        int res = 0;
        try {
            res = registerServiceApi.registerCustomer(registerData.getStoreId(), registerData.getMobile(), registerData.getPassword(), registerData.getCode(),
                    redisService.getValue(String.format("%s_%s", CommonConstant.APPLET_REGISTER_CODE_KEY, registerData.getMobile())), registerData.getRecommendCode());

        } catch (Exception e) {
            e.printStackTrace();
            return AjaxResult.error(res);
        }
        return AjaxResult.success(res);
    }

    /**
     * 绑定账号
     *
     * @param registerData 登录参数
     */
    @RequestMapping("/bindMobile")
    @ResponseBody
    @UnAuth
    @ApiOperation(value = "绑定账号", notes = "绑定账号（不需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "username", value = "用户名"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "password", value = "密码"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回码  -1 用户名或密码错误  -2 账号冻结  -3 账号锁定 1 成功  -4 验证码错误", response = Integer.class)
    })
    @Log(title = "绑定账号", businessType = BusinessType.SELECT)
    public AjaxResult bindMobile(@RequestBody RegisterData registerData, HttpServletRequest request) {
        int res = 0;
        try {
            res = registerServiceApi.bindMobile(AppletsLoginUtils.getInstance().getCustomerId(request), registerData.getMobile(), registerData.getPassword(), registerData.getCode(),
                    redisService.getValue(String.format("%s_%s", CommonConstant.APPLET_REGISTER_CODE_KEY, registerData.getMobile())), registerData.getRecommendCode(), registerData.getStoreId());

        } catch (Exception e) {
            e.printStackTrace();
            return AjaxResult.error(res);
        }
        return AjaxResult.success(res);
    }

    /**
     * 用户注册实体
     */
    @Data
    @ApiModel(description = "用户注册实体")
    private static class RegisterData {

        /**
         * 手机号码
         */
        @ApiModelProperty(value = "手机号码")
        private String mobile;

        /**
         * 密码
         */
        @ApiModelProperty(value = "密码")
        private String password;

        /**
         * 手机验证码
         */
        @ApiModelProperty(value = "手机验证码")
        private String code;

        /**
         * 推荐码
         */
        @ApiModelProperty(value = "推荐码")
        private String recommendCode;

        private long storeId;

    }
}

