/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:VideoController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.marketing;


import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.sms.domain.SmsVideo;
import com.ruoyi.sms.service.ISmsVideoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 视频促销控制器
 *
 * @author 魔金商城 created on 2020/6/2
 */
@RestController
@Api(description = "视频促销接口")
public class VideoController extends BaseController {

    /**
     * 注入视频服务接口
     */
    @Autowired
    private ISmsVideoService videoService;


    /**
     * 分页查询视频活动列表
     */
    @GetMapping("/videoList")
    @ApiOperation(value = "分页查询视频活动列表", notes = "分页查询视频活动列表")
    @Log(title = "分页查询视频活动列表", businessType = BusinessType.SELECT)
    public AjaxResult list(SmsVideo smsVideo) {
        startPage();
        List<SmsVideo> list = videoService.selectSmsVideoList(smsVideo);
        return AjaxResult.success(getDataTable(list));
    }


}
