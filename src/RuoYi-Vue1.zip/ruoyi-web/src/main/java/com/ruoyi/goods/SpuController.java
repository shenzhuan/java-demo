/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:SpuController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.goods;

import com.github.pagehelper.util.StringUtil;
import com.ruoyi.appletsutil.AppletsLoginUtils;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.annotation.UnAuth;
import com.ruoyi.common.constant.KeysConstant;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.redis.RedisCache;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.enums.StatusEnum;
import com.ruoyi.common.utils.WeChatAppletUtils;
import com.ruoyi.common.utils.bean.WeChatAppletCodeRequest;
import com.ruoyi.common.utils.bean.WechatSetting;
import com.ruoyi.goods.domain.*;
import com.ruoyi.goods.service.*;
import com.ruoyi.goods.vo.*;
import com.ruoyi.order.service.RecommendSkuService;
import com.ruoyi.req.ShareQRReq;
import com.ruoyi.setting.bean.WechatPaySet;
import com.ruoyi.setting.service.ILsPaySettingService;
import com.ruoyi.util.PageHelper;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 商品控制器
 */
@RestController
@Api(description = "商品接口")
@Slf4j
public class SpuController {

    @Value("${ruoyi.profile}")
    protected String filePath;
    /**
     * 注入评论服务接口
     */
    @Autowired
    private IPmsCommentService commentService;
    /**
     * 商品服务api接口
     */
    @Autowired
    private ISpuApiService ISpuApiService;
    /**
     * 注入规格服务接口
     */
    @Autowired
    private IPmsSpecService specService;
    /**
     * 注入单品服务接口
     */
    @Autowired
    private IPmsSkuService skuService;
    /**
     * 注入redis服务
     */
    @Autowired
    private RedisCache redisService;
    @Autowired
    private IPmsGoodsService pmsGoodsService;
    /**
     * 注入分类服务接口
     */
    @Autowired
    private IPmsCategoryService categoryService;
    /**
     * 注入推荐单品服务
     */
    @Autowired
    private RecommendSkuService recommendSkuService;
    @Autowired
    private IPmsBrandService pmsBrandService;
    @Autowired
    private IPmsTypeService typeService;
    @Autowired
    private ILsPaySettingService paySettingService;

    /**
     * 获取小程序码
     */
    @RequestMapping(value = ShareQRReq.URI)
    @Log(title = "获取小程序码", businessType = BusinessType.SELECT)
    public AjaxResult shareQR(@RequestParam(value = "page", required = true) String page,
                              @RequestParam(value = "scene", required = true) String scene) {

        if (StringUtil.isEmpty(page)) page = "";
        if (StringUtil.isEmpty(scene)) scene = "";

        String key = String.format(KeysConstant.SHARE_CODE_QR, page, scene);
        String shareQR = redisService.getValue(key);

        if (StringUtil.isEmpty(shareQR)) {
            // 数据库拿
            //  shareQR = userQrService.getUrl(userId, page, scene);
            if (StringUtil.isEmpty(shareQR)) {
                WechatPaySet wechatAppletPaySet = paySettingService.queryPaySet(0).getWechatAppletPaySet();
                WechatSetting wechatSetting = new WechatSetting();
                wechatSetting.setAppId(wechatAppletPaySet.getAppId());
                wechatSetting.setAppSecret(wechatAppletPaySet.getAppSecret());
                // 向微信获取新二维码
                shareQR = WeChatAppletUtils.getWxacodeUrl(page, scene, wechatSetting, filePath, 0);
                //  userQrService.asyncSave(userId, page, scene, shareQR);
            }
            if (StringUtil.isNotEmpty(shareQR)) {
                redisService.putToRedis(key, shareQR);
            }
        }
        Map<String, Object> resMap = new HashMap<>();
        resMap.put("shareQR", shareQR);
        return AjaxResult.success(resMap);
    }

    /**
     * 根据分类id查询所有子分类信息
     *
     * @param parentId 父级id
     * @return 返回该父级下的所有分类信息
     */
    @UnAuth
    @GetMapping("/queryCategoryByParentId")
    @Log(title = "根据分类id查询所有子分类信息", businessType = BusinessType.SELECT)
    public AjaxResult queryCategoryByParentId(long parentId) {
        return AjaxResult.success(categoryService.queryCategoryByParentId(parentId));
    }

    /**
     * 查询一级分类
     *
     * @return 返回分类集合
     */
    @GetMapping("/queryAllFirstCategory")
    @ApiOperation(value = "查询一级分类", notes = "查询一级分类（不需要认证）")
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回分类集合", response = PmsCategory.class)
    })
    @UnAuth
    @Log(title = "查询一级分类", businessType = BusinessType.SELECT)
    public AjaxResult queryAllFirstCategory() {
        return AjaxResult.success(categoryService.queryCategoryByParentId(0L));
    }

    /**
     * 查询一级二级分类
     *
     * @return 返回分类集合
     */
    @GetMapping("/queryAllFirstAndSecondCategory")
    @ApiOperation(value = "查询一级二级分类", notes = "查询一级二级分类（不需要认证）")
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回分类集合", response = PmsCategory.class)
    })
    @UnAuth
    @Log(title = "查询一级二级分类", businessType = BusinessType.SELECT)
    public AjaxResult queryAllFirstAndSecondCategory() {
        return AjaxResult.success(categoryService.queryAllFirstAndSecondCategory());
    }

    /**
     * 查询一级二级三级分类
     *
     * @return 返回分类集合
     */
    @GetMapping("/queryAllThreeCategory")
    @ApiOperation(value = "查询一级二级分类", notes = "查询一级二级分类（不需要认证）")
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回分类集合", response = PmsCategory.class)
    })
    @UnAuth
    @Log(title = "查询一级二级三级分类", businessType = BusinessType.SELECT)
    public AjaxResult queryAllThreeCategory() {
        Long t = System.currentTimeMillis();
        try {
            log.debug("查询一级二级三级分类......start");
            return AjaxResult.success(categoryService.queryAllThreeCategory());
        } catch (Exception e) {
            log.debug("查询一级二级三级分类......end" + (System.currentTimeMillis() - t) + "ms");
            return AjaxResult.error(e.getMessage());
        } finally {
            log.debug("查询一级二级三级分类......end" + (System.currentTimeMillis() - t) + "ms");
        }
    }

    /**
     * 查询一级二级三级分类
     *
     * @return 返回分类集合
     */
    @GetMapping("/queryAllThreeCategoryByStoreId")
    @ApiOperation(value = "查询一级二级分类", notes = "查询一级二级分类（不需要认证）")
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回分类集合", response = PmsCategory.class)
    })
    @UnAuth
    @Log(title = "查询一级二级三级分类", businessType = BusinessType.SELECT)
    public AjaxResult queryAllThreeCategoryByStoreId(@RequestParam(value = "storeId", required = false, defaultValue = "-1") long storeId) {
        Long t = System.currentTimeMillis();
        try {
            log.debug("查询一级二级三级分类......start");
            return AjaxResult.success(categoryService.queryAllThreeCategory(storeId));
        } catch (Exception e) {
            log.debug("查询一级二级三级分类......end" + (System.currentTimeMillis() - t) + "ms");
            return AjaxResult.error(e.getMessage());
        } finally {
            log.debug("查询一级二级三级分类......end" + (System.currentTimeMillis() - t) + "ms");
        }
    }

    /**
     * 分页查询商品列表
     *
     * @param pageHelper 分页帮助类
     * @return 返回用户积分商城订单列表
     */
    @UnAuth
    @RequestMapping(value = "/goodsList")
    
    @Log(title = "分页查询商品列表", businessType = BusinessType.SELECT)
    public AjaxResult querySimpleSpusUpdate(@ApiIgnore PageHelper<PmsGoods> pageHelper, @ApiIgnore SpuSearchCondition spuSearchCondition) {

        // spuSearchCondition.setIsVirtual(0);
        spuSearchCondition.setShelvesStatus("1");
        spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
        return AjaxResult.success(pmsGoodsService.querySimpleSpus(pageHelper, spuSearchCondition));
    }

    @RequestMapping(value = "/brandList")
    @UnAuth
    @Log(title = "品牌列表", businessType = BusinessType.SELECT)
    public AjaxResult brandList(PmsBrand brand) {
        return AjaxResult.success(pmsBrandService.selectPmsBrandList(brand));
    }

    @RequestMapping(value = "/cateList")
    
    @UnAuth
    @Log(title = "分类类别", businessType = BusinessType.SELECT)
    public AjaxResult cateList(PmsBrand brand) {
        return AjaxResult.success(pmsBrandService.selectPmsBrandList(brand));
    }

    @RequestMapping(value = "/typeList")
    
    @UnAuth
    @Log(title = "类别列表", businessType = BusinessType.SELECT)
    public AjaxResult typeList(PmsType type) {
        return AjaxResult.success(typeService.selectPmsTypeList(type));
    }

    /**
     * 查询推荐的商品
     *
     * @param num 个数
     * @return 返回推荐的商品
     */
    @UnAuth
    @GetMapping("/recommendskus")
    @ApiOperation(value = "查询推荐的商品", notes = "查询推荐的商品（不需要认证）")
    @Log(title = "查询推荐的商品", businessType = BusinessType.SELECT)
    public AjaxResult queryRecommendSkus(int num, @RequestParam(value = "storeId", required = false, defaultValue = "-1") long storeId) {
        return AjaxResult.success(recommendSkuService.queryRecommendSkus(num, storeId));
    }

    /**
     * 查询商品详情
     *
     * @param skuId 单品id
     * @return 返回商品详情
     */
    @RequestMapping(value = "/queryspudetail")
    @UnAuth
    
    @ApiOperation(value = "查询商品详情", notes = "查询商品详情（不需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "skuId", value = "单品id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回商品详情", response = SpuDetail.class)
    })
    @Log(title = "查询商品详情", businessType = BusinessType.SELECT)
    public AjaxResult querySpuDetail(HttpServletRequest request, @RequestParam(value = "skuId", required = false) String skuId) {
        try {
            long customerId = AppletsLoginUtils.getInstance().getCustomerId(request);
            return AjaxResult.success(ISpuApiService.querySpuDetail(skuId, customerId, SpuDetailItem.COUPON, SpuDetailItem.FOLLOW, SpuDetailItem.STORE_SCORE, SpuDetailItem.MOBILE_DESC).orElseGet(() -> null));
        } catch (Exception e) {
            e.printStackTrace();
            return AjaxResult.error(e.getMessage());
        }
    }

    /**
     * 查询商品详情
     *
     * @param goodsId 上品id
     * @return 返回商品详情
     */
    @RequestMapping(value = "/queryGoodsDetail")
    @UnAuth
    
    @Log(title = "查询商品详情", businessType = BusinessType.SELECT)
    public AjaxResult queryGoodsDetail(HttpServletRequest request, Long goodsId, @RequestParam(value = "skuId", required = false) String skuId) {
        Long t = System.currentTimeMillis();
        try {
            log.debug("查询商品详情......start");
            long customerId = AppletsLoginUtils.getInstance().getCustomerId(request);
            return AjaxResult.success(ISpuApiService.queryGoodsDetail(goodsId, skuId, customerId, SpuDetailItem.COUPON, SpuDetailItem.FOLLOW, SpuDetailItem.STORE_SCORE, SpuDetailItem.MOBILE_DESC).orElseGet(() -> null));
        } catch (Exception e) {
            log.debug("查询商品详情......end" + (System.currentTimeMillis() - t) + "ms");
            e.printStackTrace();
            return AjaxResult.error(e.getMessage());
        } finally {
            log.debug("查询商品详情......end" + (System.currentTimeMillis() - t) + "ms");
        }
    }

    /**
     * 查询商品详情
     *
     * @param goodsId 上品id
     * @return 返回商品详情
     */
    @RequestMapping(value = "/querySimpleGoodsDetail")
    @UnAuth
    
    @Log(title = "查询商品详情", businessType = BusinessType.SELECT)
    public AjaxResult querySimpleGoodsDetail(HttpServletRequest request, Long goodsId, @RequestParam(value = "skuId", required = false) String skuId) {
        try {
            long customerId = AppletsLoginUtils.getInstance().getCustomerId(request);
            return AjaxResult.success(ISpuApiService.querySimpleGoodsDetail(goodsId, skuId, customerId, SpuDetailItem.COUPON, SpuDetailItem.FOLLOW, SpuDetailItem.STORE_SCORE, SpuDetailItem.MOBILE_DESC).orElseGet(() -> null));
        } catch (Exception e) {
            e.printStackTrace();
            return AjaxResult.error(e.getMessage());
        }
    }

    /**
     * 查询商品的规格信息
     *
     * @param spuId 商品id
     * @return 返回商品的规格信息
     */
    @RequestMapping(value = "queryspuspecs")
    @UnAuth
    
    @ApiOperation(value = "查询商品的规格信息", notes = "查询商品的规格信息（不需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "spuId", value = "商品id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回商品的规格信息", response = PmsSpec.class)
    })
    @Log(title = "查询商品的规格信息", businessType = BusinessType.SELECT)
    public AjaxResult querySpuSpecs(long spuId) {
        return AjaxResult.success(specService.querySpuSpecs(spuId));
    }

    /**
     * 查询商品下所有单品的规格信息
     *
     * @param spuId 商品id
     * @return 返回商品下面所有单品的规格信息
     */
    @RequestMapping(value = "queryskuspecs")
    @UnAuth
    
    @ApiOperation(value = "查询商品下所有单品的规格信息", notes = "查询商品下所有单品的规格信息（不需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "spuId", value = "商品id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回商品下面所有单品的规格信息", response = PmsSku.class)
    })
    @Log(title = "查询商品下所有单品的规格信息", businessType = BusinessType.SELECT)
    public AjaxResult querySkuSpecs(long spuId) {
        return AjaxResult.success(skuService.queryAllSkuSpecs(spuId));
    }

    /**
     * 查询单品评论
     *
     * @param pageHelper 分类帮助类
     * @param type       评论类型 -1 全部 1 好评 2 中评 3 差评
     * @return 返回评论信息
     */
    @UnAuth
    @RequestMapping(value = "/queryskucomments")
    
    @ApiOperation(value = "查询单品评论", notes = "查询单品评论（不需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageNum", value = "当前页"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "pageSize", value = "每页显示的记录数"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "spuId", value = "单品id"),
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "type", value = "评论类型 -1 全部 1 好评 2 中评 3 差评"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回评论信息", response = PmsComment.class)
    })
    @Log(title = "查询单品评论", businessType = BusinessType.SELECT)
    public AjaxResult querySkuComments(@ApiIgnore PageHelper<PmsComment> pageHelper, @ApiIgnore String spuId, @ApiIgnore String type) {
        return AjaxResult.success(commentService.querySkuComments(pageHelper, spuId, type));
    }


    /**
     * 查询商品的评论概括
     *
     * @return 返回商品的评论概括
     */
    @UnAuth
    @RequestMapping(value = "/querycommentsummarize")
    
    @ApiOperation(value = "查询商品的评论概括", notes = "查询商品的评论概括（不需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "skuId", value = "单品id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回商品的评论概括", response = CommentSummarize.class)
    })
    @Log(title = "查询商品的评论概括", businessType = BusinessType.SELECT)
    public AjaxResult queryCommentSummarize(String spuId) {
        return AjaxResult.success(commentService.queryCommentSummarize(spuId));
    }


    /**
     * 查询商品组合
     *
     * @param skuId 单品id
     * @return 返回商品组合信息
     */
    @UnAuth
    @RequestMapping("/querycombination")
    
    @ApiOperation(value = "查询商品组合", notes = "查询商品组合（不需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "skuId", value = "单品id"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "返回商品组合信息", response = CombinationDetail.class)
    })
    @Log(title = "查询商品组合", businessType = BusinessType.SELECT)
    public AjaxResult queryCombination(HttpServletRequest request, String skuId) {
        return AjaxResult.success(ISpuApiService.queryGoodsCombinationBySkuId(skuId, AppletsLoginUtils.getInstance().getCustomerId(request)));
    }

    /**
     * 计算运费
     *
     * @param skuId   商品id
     * @param storeId 店铺id
     * @param cityId  城市id
     * @param num     商品数量
     * @return 运费
     */
    @UnAuth
    @RequestMapping("/calculatefreight")
    
    @ApiOperation(value = "计算运费", notes = "计算运费（不需要认证）", httpMethod = "POST")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "form", dataType = "string", name = "skuId", value = "单品id"),
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "storeId", value = "店铺id"),
            @ApiImplicitParam(paramType = "form", dataType = "long", name = "cityId", value = "城市id"),
            @ApiImplicitParam(paramType = "form", dataType = "int", name = "num", value = "商品数量", defaultValue = "1"),
    })
    @ApiResponses({
            @ApiResponse(code = 200, message = "运费", response = BigDecimal.class)
    })
    @Log(title = "计算运费", businessType = BusinessType.SELECT)
    public AjaxResult calculateFreight(String skuId, long storeId, long cityId, int num) {
        return AjaxResult.success(ISpuApiService.calculateFreight(skuId, storeId, cityId, num));
    }

    /**
     * 获取分享微信小程序码
     *
     * @param weChatAppletCodeRequest 生成微信小程序码请求实体类
     * @return 分享微信小程序码
     */
    @UnAuth
    @RequestMapping("/getwechatappletcode")
    
    @ApiOperation(value = "获取分享微信小程序码", notes = "获取分享微信小程序码（不需要认证）", httpMethod = "POST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "分享微信小程序码", response = String.class)
    })
    @Log(title = "获取分享微信小程序码", businessType = BusinessType.SELECT)
    public AjaxResult getWeChatAppletCode(@RequestBody WeChatAppletCodeRequest weChatAppletCodeRequest) {
        return AjaxResult.success(ISpuApiService.getWeChatAppletCode(weChatAppletCodeRequest));
    }


}
