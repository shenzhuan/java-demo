/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:LivePlayerController.java
 * Date:2020/11/27 16:26:27
 */

package com.ruoyi.liveplayer;


import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.annotation.UnAuth;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.sms.service.LivePlayerService;
import com.ruoyi.sms.vo.LivePlayerRequest;
import com.ruoyi.sms.vo.RoomInfo;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 小程序直播列表控制器
 *
 * @author Caizize mojin on 2020/4/27
 */
@Controller
public class LivePlayerController {

    @Autowired
    private LivePlayerService livePlayerService;


    /**
     * 获取小程序直播房间列表
     *
     * @param livePlayerRequest 小程序直播房间列表请求实体
     * @return 小程序直播房间列表
     */
    @UnAuth
    @RequestMapping("/queryliveplayerroomlist")
    @ResponseBody
    @ApiOperation(value = "获取小程序直播房间列表", notes = "获取小程序直播房间列表（不需要认证）", httpMethod = "POST")
    @ApiResponses({
            @ApiResponse(code = 200, message = "小程序直播房间列表", response = RoomInfo.class)
    })
    @Log(title = "获取小程序直播房间列表", businessType = BusinessType.SELECT)
    public AjaxResult queryLivePlayerRoomList(LivePlayerRequest livePlayerRequest) {
        return livePlayerService.queryLivePlayerList(livePlayerRequest);
    }

}
