/*
 * Copyright (c) 2021
 * User:魔金多商户商城
 * File:IndexController.java
 * Date:2020/09/13 08:43:13
 */

package com.ruoyi.index;


import com.github.pagehelper.PageInfo;
import com.ruoyi.appletsutil.AppletsLoginUtils;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.annotation.UnAuth;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.enums.StatusEnum;
import com.ruoyi.goods.domain.PmsGoods;
import com.ruoyi.goods.domain.PmsType;
import com.ruoyi.goods.domain.PmsViewGoods;
import com.ruoyi.goods.service.IPmsGoodsService;
import com.ruoyi.goods.service.IPmsTypeService;
import com.ruoyi.goods.service.IPmsViewGoodsService;
import com.ruoyi.goods.vo.SpuSearchCondition;
import com.ruoyi.luence.LuenceService;
import com.ruoyi.luence.PageQuery;
import com.ruoyi.member.domain.UmsSimilarity;
import com.ruoyi.member.service.IUmsSimilarityService;
import com.ruoyi.recommend.RecommendUtils;
import com.ruoyi.sms.domain.*;
import com.ruoyi.sms.service.*;
import com.ruoyi.system.domain.SysNotice;
import com.ruoyi.system.service.ISysNoticeService;
import com.ruoyi.util.CommonConstant;
import com.ruoyi.util.PageHelper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

/**
 * @Auther: shenzhuan
 * @Date: 2019/4/2 15:02
 * @Description:
 */
@Slf4j
@RestController
@Api(tags = "IndexController", description = "home")
public class IndexController extends BaseController {


    @Resource
    private ISmsHomeNewProductService homeNewProductService;
    @Resource
    private ISmsHomeRecommendProductService homeRecommendProductService;
    @Resource
    private ISmsHomeBrandService homeBrandService;
    @Resource
    private ISmsHomeRecommendSubjectService homeRecommendSubjectService;
    @Resource
    private ISmsHomeAdvertiseService homeAdvertiseService;
    @Resource
    private ISysNoticeService sysNoticeService;
    @Resource
    private IPmsTypeService typeService;
    @Autowired
    private IPmsGoodsService pmsGoodsService;

    @Autowired
    private IPmsViewGoodsService viewGoodsService;
    @Autowired
    private IUmsSimilarityService similarityService;

    @Resource
    private LuenceService luenceService;

    /**
     * luence商品搜索
     *
     * @return
     * @throws IOException
     */
    @UnAuth
    @GetMapping("/searchProduct")
    @Log(title = "luence商品搜索", businessType = BusinessType.SELECT)
    private AjaxResult searchProduct(@RequestParam(value = "pageSize", required = false, defaultValue = "4") Integer pageSize,
                                     @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum, String name) throws IOException {
        PageInfo pageInfo = new PageInfo();
        pageNum++;
        pageInfo.setPageNum(pageNum);
        pageInfo.setPageSize(pageSize);
        PageQuery pageQuery = new PageQuery();
        pageQuery.setPageInfo(pageInfo);
        //  pageQuery.setParams(goods);
        PageQuery<PmsGoods> pageResult = luenceService.searchProduct(pageQuery, name);
        return AjaxResult.success(pageResult);
    }

    /**
     * 找出获取被推荐的商品列表(从商品点击量最大的商品)
     */
    @UnAuth
    @GetMapping("/getRecProductByGoodsList")
    @Log(title = "找出获取被推荐的商品列表(从商品点击量最大的商品)", businessType = BusinessType.SELECT)
    public AjaxResult getRecProductByGoodsList(HttpServletRequest request,
                                               @RequestParam(value = "pageSize", required = false, defaultValue = "4") Integer pageSize,
                                               @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum) {
        Long t = System.currentTimeMillis();
        log.debug("查询结算信息......start");
        long customerId = AppletsLoginUtils.getInstance().getCustomerId(request);
        PageHelper<PmsGoods> pageHelper = new PageHelper<>();
        SpuSearchCondition spuSearchCondition = new SpuSearchCondition();
        spuSearchCondition.setShelvesStatus("1");
        pageHelper.setPageNum(pageNum);
        spuSearchCondition.setStatus(StatusEnum.AuditType.SUCESS.code() + "");
        if (customerId == 0) {
            List<PmsGoods> list = pmsGoodsService.querySimpleSpus(pageHelper, spuSearchCondition).getList();
            return AjaxResult.success(list);
        }
        // 1.查询出某个用户与其他用户的相似度列表
        UmsSimilarity umsSimilarity = new UmsSimilarity();
        umsSimilarity.setUserId(customerId);
        List<UmsSimilarity> userSimilarityList = similarityService.selectUmsSimilarityList(umsSimilarity);

        // 2.获取所有的用户的浏览记录
        PmsViewGoods category = new PmsViewGoods();
        List<PmsViewGoods> userActiveList = viewGoodsService.selectPmsViewGoodsList(category);
        // 3.找出与id为1L的用户浏览行为最相似的前2个用户
        List<Long> userIds = RecommendUtils.getSimilarityBetweenUsersByGoods(customerId, userSimilarityList, 10);
        // 4.获取应该推荐给用户的商品
        List<Long> ids = RecommendUtils.getRecommendateGoods(customerId, userIds, userActiveList, pageNum);

        if (ids != null && ids.size() > 0) {
            return AjaxResult.success(pmsGoodsService.querySpuByIdsForExport(ids, CommonConstant.NO_CUSTOMER_ID));
        } else {
            // 3.找出与id为1L的用户浏览行为最相似的前2个用户
            userIds = RecommendUtils.getSimilarityBetweenUsersByGoods(customerId, userSimilarityList, 40);
            // 4.获取应该推荐给用户的商品
            ids = RecommendUtils.getRecommendateGoods(customerId, userIds, userActiveList, pageNum);
            if (ids != null && ids.size() > 0) {
                return AjaxResult.success(pmsGoodsService.querySpuByIdsForExport(ids, CommonConstant.NO_CUSTOMER_ID));
            }
        }

        return AjaxResult.success(pmsGoodsService.querySimpleSpus(pageHelper, spuSearchCondition).getList());
    }

    /**
     * 查询商品列表
     */
    @UnAuth
    @GetMapping("/list")
    @Log(title = "查询首页商品类别", businessType = BusinessType.SELECT)
    public AjaxResult list(PmsGoods pmsGoods) {
        List<PmsGoods> list = pmsGoodsService.querySpus(pmsGoods);
        return AjaxResult.success(list);
    }

    @UnAuth
    @ApiOperation(value = "查询首页商品属性分类")
    @GetMapping(value = "/type/list")
    @Log(title = "查询首页商品属性分类", businessType = BusinessType.SELECT)
    public Object getTypeList(PmsType type,
                              @RequestParam(value = "pageSize", required = false, defaultValue = "4") Integer pageSize,
                              @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum) {
        // startPage();
        return AjaxResult.success(typeService.selectPmsTypeList(type));
    }

    @UnAuth
    @ApiOperation(value = "查询首页通知")
    @GetMapping(value = "/notice/list")
    @Log(title = "查询首页通知", businessType = BusinessType.SELECT)
    public Object getNoticeList(SysNotice notice,
                                @RequestParam(value = "pageSize", required = false, defaultValue = "4") Integer pageSize,
                                @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum) {
        startPage();
        notice.setStatus("1");
        return AjaxResult.success(sysNoticeService.selectNoticeList(notice));
    }

    @UnAuth
    @GetMapping(value = "/notice/detail")
    @ApiOperation(value = "查询公告详情信息")
    @Log(title = "查询公告详情信息", businessType = BusinessType.SELECT)
    public Object giftDetail(@RequestParam(value = "id", required = false, defaultValue = "0") Long id) {
        SysNotice goods = sysNoticeService.selectNoticeById(id);
        return AjaxResult.success(goods);
    }

    @UnAuth
    @GetMapping(value = "/homeNewProduct/list")
    @Log(title = "homeNewProduct", businessType = BusinessType.SELECT)
    public Object productCategoryList(SmsHomeNewProduct homeNewProduct,
                                      @RequestParam(value = "pageSize", required = false, defaultValue = "4") Integer pageSize,
                                      @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum) {
        startPage();
        return AjaxResult.success(homeNewProductService.selectSmsHomeNewProductList(homeNewProduct));
    }

    @UnAuth
    @GetMapping(value = "/homeBrand/list")
    @Log(title = "homeBrand", businessType = BusinessType.SELECT)
    public Object productCategoryList(SmsHomeBrand homeNewProduct,
                                      @RequestParam(value = "pageSize", required = false, defaultValue = "4") Integer pageSize,
                                      @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum) {
        startPage();
        return AjaxResult.success(homeBrandService.selectSmsHomeBrandList(homeNewProduct));
    }

    @UnAuth
    @GetMapping(value = "/homeRecommendProduct/list")
    @Log(title = "homeRecommendProduct", businessType = BusinessType.SELECT)
    public Object productCategoryList(SmsHomeRecommendProduct homeNewProduct,
                                      @RequestParam(value = "pageSize", required = false, defaultValue = "4") Integer pageSize,
                                      @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum) {
        startPage();
        return AjaxResult.success(homeRecommendProductService.selectSmsHomeRecommendProductList(homeNewProduct));
    }

    @UnAuth
    @GetMapping(value = "/homeRecommendSubject/list")
    @Log(title = "homeRecommendSubject", businessType = BusinessType.SELECT)
    public Object productCategoryList(SmsHomeRecommendSubject homeNewProduct,
                                      @RequestParam(value = "pageSize", required = false, defaultValue = "4") Integer pageSize,
                                      @RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum) {
        startPage();
        return AjaxResult.success(homeRecommendSubjectService.selectSmsHomeRecommendSubjectList(homeNewProduct));
    }

    /**
     * banner
     *
     * @return
     */
    @UnAuth
    @GetMapping("/bannerList")
    @Log(title = "bannerList", businessType = BusinessType.SELECT)
    public Object bannerList(SmsHomeAdvertise advertise, @RequestParam(value = "type", required = false) Integer type,
                             @RequestParam(value = "storeId", required = false) Integer storeId) {
        advertise.setStatus(0);
        return AjaxResult.success(homeAdvertiseService.selectSmsHomeAdvertiseList(advertise));
    }
    /**
     * 找出获取被推荐的商品列表(从被推荐的二级类目点击量最大的商品)
     */
   /* @ResponseBody
    @GetMapping("/getRecommendateProduct")
    public AjaxResult getRecProductByCategory2List(HttpServletRequest request) {
        long customerId = AppletsLoginUtils.getInstance().getCustomerId(request);
        PmsGoods pmsGoods = new PmsGoods();
        if (customerId==0){
            List<PmsGoods> list = pmsGoodsService.querySpus(pmsGoods);
            return AjaxResult.success(list);
        }
        // 1.查询出某个用户与其他用户的相似度列表
        UmsSimilarity umsSimilarity = new UmsSimilarity();
        umsSimilarity.setUserId(customerId);
        List<UmsSimilarity> userSimilarityList = similarityService.selectUmsSimilarityList(umsSimilarity);

        // 2.获取所有的用户的浏览记录
        PmsViewCategory category= new PmsViewCategory();
        List<PmsViewCategory> userActiveList = viewCategoryService.selectPmsViewCategoryList(category);
        // 3.找出与id为1L的用户浏览行为最相似的前2个用户
        List<Long> userIds = RecommendUtils.getSimilarityBetweenUsers(customerId, userSimilarityList, 8);
        // 4.获取应该推荐给1L用户的二级类目
        List<Long> recommendateCategory2 = RecommendUtils.getRecommendateCategory2(customerId, userIds, userActiveList);

        // 5.找出二级类目中的所有商品
        List<PmsGoods> recommendateProducts = new ArrayList<PmsGoods>();
        for (Long category2Id : recommendateCategory2) {
            pmsGoods.setSecondCateId(category2Id);
            List<PmsGoods> productList = pmsGoodsService.selectPmsGoodsList(pmsGoods);
            // 找出当前二级类目中点击量最大的商品
            PmsGoods maxHitsProduct = RecommendUtils.findMaxHitsPmsGoods(productList);
            recommendateProducts.add(maxHitsProduct);
        }
        return AjaxResult.success(recommendateProducts);
    }*/
}
